import { Toaster } from "@/components/ui/toaster";
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClientInstance } from '@/lib/query-client';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import GetStarted from './pages/GetStarted';
import SignUp from './pages/SignUp';
import Questionnaire from './pages/Questionnaire';
import StudentDashboard from './pages/StudentDashboard';
import TutorDashboard from './pages/TutorDashboard';
import BrowseTutors from './pages/BrowseTutors';
import TutorProfile from './pages/TutorProfile';

import TutorStudents from './pages/TutorStudents';
import MyPayments from './pages/MyPayments';
import MyHomework from './pages/MyHomework';
import MyTutors from './pages/MyTutors';
import FindStudents from './pages/FindStudents';
import AssignHomework from './pages/AssignHomework';
import Chat from './pages/Chat';
import AuthRedirect from './pages/AuthRedirect';
import CreateProgram from './pages/CreateProgram';
import About from './pages/About';
import Contact from './pages/Contact';
import Toolbox from './pages/Toolbox';
import Admin from './pages/Admin';
import PrivacyPolicy from './pages/PrivacyPolicy';
import ShaderBackground from "@/components/ui/shader-background";
import ThemeToggle from "@/components/ThemeToggle";
// Add page imports here

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div data-source-location="src/App.jsx:42:6" data-dynamic-content="false" className="fixed inset-0 flex items-center justify-center">
        <div data-source-location="src/App.jsx:43:8" data-dynamic-content="false" className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>);

  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError data-source-location="src/App.jsx:51:13" data-dynamic-content="false" />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes data-source-location="src/App.jsx:61:4" data-dynamic-content="true">
      <Route data-source-location="src/App.jsx:62:6" data-dynamic-content="true" path="/" element={<Home data-source-location="src/App.jsx:62:31" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:63:6" data-dynamic-content="true" path="/get-started" element={<GetStarted data-source-location="src/App.jsx:63:42" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:64:6" data-dynamic-content="true" path="/sign-up" element={<SignUp data-source-location="src/App.jsx:64:38" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:65:6" data-dynamic-content="true" path="/questionnaire" element={<Questionnaire data-source-location="src/App.jsx:65:44" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:66:6" data-dynamic-content="true" path="/student-dashboard" element={<StudentDashboard data-source-location="src/App.jsx:66:48" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:67:6" data-dynamic-content="true" path="/tutor-dashboard" element={<TutorDashboard data-source-location="src/App.jsx:67:46" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:68:6" data-dynamic-content="true" path="/browse-tutors" element={<BrowseTutors data-source-location="src/App.jsx:68:44" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:69:6" data-dynamic-content="true" path="/tutor/:id" element={<TutorProfile data-source-location="src/App.jsx:69:40" data-dynamic-content="false" />} />

      <Route data-source-location="src/App.jsx:71:6" data-dynamic-content="true" path="/tutor-students" element={<TutorStudents data-source-location="src/App.jsx:71:45" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:72:6" data-dynamic-content="true" path="/my-payments" element={<MyPayments data-source-location="src/App.jsx:72:42" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:73:6" data-dynamic-content="true" path="/my-homework" element={<MyHomework data-source-location="src/App.jsx:73:42" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:74:6" data-dynamic-content="true" path="/my-tutors" element={<MyTutors data-source-location="src/App.jsx:74:40" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:75:6" data-dynamic-content="true" path="/find-students" element={<FindStudents data-source-location="src/App.jsx:75:44" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:76:6" data-dynamic-content="true" path="/assign-homework" element={<AssignHomework data-source-location="src/App.jsx:76:46" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:77:6" data-dynamic-content="true" path="/chat" element={<Chat data-source-location="src/App.jsx:77:35" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:78:6" data-dynamic-content="true" path="/auth-redirect" element={<AuthRedirect data-source-location="src/App.jsx:78:44" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:79:6" data-dynamic-content="true" path="/create-program" element={<CreateProgram data-source-location="src/App.jsx:79:45" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:80:6" data-dynamic-content="true" path="/about" element={<About data-source-location="src/App.jsx:80:36" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:81:6" data-dynamic-content="true" path="/contact" element={<Contact data-source-location="src/App.jsx:81:38" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:82:6" data-dynamic-content="true" path="/toolbox" element={<Toolbox data-source-location="src/App.jsx:82:38" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:83:6" data-dynamic-content="true" path="/admin" element={<Admin data-source-location="src/App.jsx:83:36" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:84:6" data-dynamic-content="true" path="/privacy-policy" element={<PrivacyPolicy data-source-location="src/App.jsx:84:45" data-dynamic-content="false" />} />
      <Route data-source-location="src/App.jsx:85:6" data-dynamic-content="true" path="*" element={<PageNotFound data-source-location="src/App.jsx:85:31" data-dynamic-content="false" />} />
    </Routes>);

};


function App() {

  return (
    <AuthProvider data-source-location="src/App.jsx:94:4" data-dynamic-content="true">
      <QueryClientProvider data-source-location="src/App.jsx:95:6" data-dynamic-content="true" client={queryClientInstance}>
        <Router data-source-location="src/App.jsx:96:8" data-dynamic-content="false">
          <ScrollToTop data-source-location="src/App.jsx:97:10" data-dynamic-content="false" />
          <ShaderBackground data-source-location="src/App.jsx:98:10" data-dynamic-content="false" />
          <ThemeToggle data-source-location="src/App.jsx:99:10" data-dynamic-content="false" />
          <AuthenticatedApp data-source-location="src/App.jsx:100:10" data-dynamic-content="false" />
        </Router>
        <Toaster data-source-location="src/App.jsx:102:8" data-dynamic-content="false" />
      </QueryClientProvider>
    </AuthProvider>);

}

export default App;