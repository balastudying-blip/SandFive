import React from 'react';
import ReactDOM from 'react-dom/client';
import App from '@/App.jsx';
import '@/index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <App data-source-location="src/main.jsx:7:2" data-dynamic-content="false" />
);