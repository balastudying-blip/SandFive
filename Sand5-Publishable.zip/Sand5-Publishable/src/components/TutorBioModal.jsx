import { X } from "lucide-react";

// Shows the key parts of a tutor's profile: price, interests, grade levels taught, strengths, bio
export default function TutorBioModal({ tutor, onClose }) {
  const pricing = tutor.pricing || {};
  const interests = tutor.interests || [];
  const tutorGrade = tutor.tutorGrade || (tutor.grade ? [tutor.grade] : []);
  const strengths = tutor.strengths || [];

  return (
    <div data-source-location="src/components/TutorBioModal.jsx:11:4" data-dynamic-content="true" className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div data-source-location="src/components/TutorBioModal.jsx:12:6" data-dynamic-content="true" className="bg-card border border-border rounded-2xl shadow-xl w-full max-w-md max-h-[85vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div data-source-location="src/components/TutorBioModal.jsx:13:8" data-dynamic-content="true" className="flex items-center justify-between px-5 py-4 border-b border-border">
          <div data-source-location="src/components/TutorBioModal.jsx:14:10" data-dynamic-content="true" className="flex items-center gap-3">
            <div data-source-location="src/components/TutorBioModal.jsx:15:12" data-dynamic-content="true" className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold font-heading">
              {tutor.name.split(" ").map((n) => n[0]).join("")}
            </div>
            <div data-source-location="src/components/TutorBioModal.jsx:18:12" data-dynamic-content="true">
              <h3 data-source-location="src/components/TutorBioModal.jsx:19:14" data-dynamic-content="true" className="font-heading font-bold text-foreground" data-collection-item-field="name" data-collection-item-id={tutor?.id || tutor?._id}>{tutor.name}</h3>
              <p data-source-location="src/components/TutorBioModal.jsx:20:14" data-dynamic-content="false" className="text-xs text-muted-foreground">Tutor Profile</p>
            </div>
          </div>
          <button data-source-location="src/components/TutorBioModal.jsx:23:10" data-dynamic-content="true" onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
            <X data-source-location="src/components/TutorBioModal.jsx:24:12" data-dynamic-content="false" className="w-5 h-5" />
          </button>
        </div>

        <div data-source-location="src/components/TutorBioModal.jsx:28:8" data-dynamic-content="true" className="px-5 py-4 space-y-4" data-collection-item-field="bio" data-collection-item-id={tutor?.id || tutor?._id}>
          {/* Price */}
          <div data-source-location="src/components/TutorBioModal.jsx:30:10" data-dynamic-content="true">
            <p data-source-location="src/components/TutorBioModal.jsx:31:12" data-dynamic-content="false" className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide mb-1">Hourly Rate</p>
            {pricing.flexible ?
            <p data-source-location="src/components/TutorBioModal.jsx:33:14" data-dynamic-content="true" className="text-lg font-heading font-bold text-primary">{pricing.flexibleNote || "Flexible pricing"}</p> :
            pricing.price ?
            <p data-source-location="src/components/TutorBioModal.jsx:35:14" data-dynamic-content="true" className="text-lg font-heading font-bold text-primary" data-collection-item-field="price" data-collection-item-id={pricing?.id || pricing?._id}>${pricing.price}<span data-source-location="src/components/TutorBioModal.jsx:35:89" data-dynamic-content="false" className="text-sm text-muted-foreground font-normal">/hr</span></p> :

            <p data-source-location="src/components/TutorBioModal.jsx:37:14" data-dynamic-content="false" className="text-sm text-muted-foreground">Not specified</p>
            }
          </div>

          {/* Grade levels taught */}
          {tutorGrade.length > 0 &&
          <div data-source-location="src/components/TutorBioModal.jsx:43:12" data-dynamic-content="true">
              <p data-source-location="src/components/TutorBioModal.jsx:44:14" data-dynamic-content="false" className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Grade Levels Taught</p>
              <div data-source-location="src/components/TutorBioModal.jsx:45:14" data-dynamic-content="true" className="flex flex-wrap gap-1.5">
                {tutorGrade.map((g) => <span data-source-location="src/components/TutorBioModal.jsx:46:37" data-dynamic-content="true" key={g} className="px-2 py-0.5 bg-primary text-primary-foreground text-xs font-medium rounded-md" data-collection-item-field="g">{g}</span>)}
              </div>
            </div>
          }

          {/* Strengths */}
          {strengths.length > 0 &&
          <div data-source-location="src/components/TutorBioModal.jsx:53:12" data-dynamic-content="true">
              <p data-source-location="src/components/TutorBioModal.jsx:54:14" data-dynamic-content="false" className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Strengths</p>
              <div data-source-location="src/components/TutorBioModal.jsx:55:14" data-dynamic-content="true" className="flex flex-wrap gap-1.5">
                {strengths.map((s) => <span data-source-location="src/components/TutorBioModal.jsx:56:36" data-dynamic-content="true" key={s} className="px-2 py-0.5 bg-secondary text-secondary-foreground text-xs font-medium rounded-md" data-collection-item-field="s">{s}</span>)}
              </div>
            </div>
          }

          {/* Interests */}
          {interests.length > 0 &&
          <div data-source-location="src/components/TutorBioModal.jsx:63:12" data-dynamic-content="true">
              <p data-source-location="src/components/TutorBioModal.jsx:64:14" data-dynamic-content="false" className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Interests</p>
              <div data-source-location="src/components/TutorBioModal.jsx:65:14" data-dynamic-content="true" className="flex flex-wrap gap-1.5">
                {interests.map((i) => <span data-source-location="src/components/TutorBioModal.jsx:66:36" data-dynamic-content="true" key={i} className="px-2 py-0.5 bg-accent text-accent-foreground text-xs font-medium rounded-md" data-collection-item-field="i">{i}</span>)}
              </div>
            </div>
          }

          {/* Bio */}
          {tutor.bio &&
          <div data-source-location="src/components/TutorBioModal.jsx:73:12" data-dynamic-content="true">
              <p data-source-location="src/components/TutorBioModal.jsx:74:14" data-dynamic-content="false" className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide mb-1">Bio</p>
              <p data-source-location="src/components/TutorBioModal.jsx:75:14" data-dynamic-content="true" className="text-sm text-foreground leading-relaxed" data-collection-item-field="bio" data-collection-item-id={tutor?.id || tutor?._id}>{tutor.bio}</p>
            </div>
          }
        </div>
      </div>
    </div>);

}