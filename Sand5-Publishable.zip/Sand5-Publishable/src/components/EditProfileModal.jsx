import { useState } from "react";
import { X, Save, Check } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { propagateNameChange } from "@/lib/loadConnections";

// Options exactly matching the Questionnaire
const GRADE_OPTIONS = ["6th", "7th", "8th", "9th", "10th", "11th", "12th", "College"];
const IMPROVE_OPTIONS = ["Grades", "Understanding", "Test performance", "Confidence"];
const LEARN_STYLE_OPTIONS = ["Step-by-step help", "Practice problems", "Examples first", "Mixed approach"];
const TUTOR_GRADE_OPTIONS = ["Pre-K", "Kindergarten", "1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th", "9th", "10th", "11th", "12th", "College & Up"];
const TUTORED_OPTIONS = ["Yes", "No"];
const TEACH_STYLE_OPTIONS = ["Explain concepts", "Work through problems", "Mixed approach"];
const STRENGTH_OPTIONS = ["Explaining ideas", "Helping struggling students", "Test prep", "Advanced content"];

// Fields exactly from the Questionnaire (minus avatar and pricing which are handled separately)
const STUDENT_FIELDS = [
{ key: "name", label: "Full Name", type: "text" },
{ key: "bio", label: "Bio", type: "textarea" },
{ key: "interests", label: "Interests", type: "tags" },
{ key: "grade", label: "Grade", type: "select", options: GRADE_OPTIONS },
{ key: "subjects", label: "Subjects", type: "tags" },
{ key: "improve", label: "What are you trying to improve?", type: "multiselect", options: IMPROVE_OPTIONS },
{ key: "learnStyle", label: "How do you prefer to learn?", type: "select", options: LEARN_STYLE_OPTIONS }];


const TUTOR_FIELDS = [
{ key: "name", label: "Full Name", type: "text" },
{ key: "bio", label: "Bio", type: "textarea" },
{ key: "interests", label: "Interests", type: "tags" },
{ key: "grade", label: "Your Grade", type: "select", options: GRADE_OPTIONS },
{ key: "tutorGrade", label: "Grades You Teach", type: "multiselect", options: TUTOR_GRADE_OPTIONS },
{ key: "tutorSubjects", label: "Subjects You Teach", type: "tags" },
{ key: "tutored", label: "Have You Tutored Before?", type: "select", options: TUTORED_OPTIONS },
{ key: "teachStyle", label: "How Do You Prefer to Teach?", type: "select", options: TEACH_STYLE_OPTIONS },
{ key: "strengths", label: "Your Strengths", type: "multiselect", options: STRENGTH_OPTIONS }];


const ENTITY_MAP = {
  name: "full_name",
  grade: "grade",
  bio: "bio",
  learnStyle: "learn_style",
  improve: "improve",
  subjects: "subjects",
  interests: "interests",
  teachStyle: "teach_style",
  strengths: "strengths",
  tutorSubjects: "tutor_subjects",
  tutorGrade: "tutor_grade",
  tutored: "tutored"
};

export default function EditProfileModal({ data, role, onClose, id }) {
  const fields = role === "tutor" ? TUTOR_FIELDS : STUDENT_FIELDS;
  const [form, setForm] = useState(() => {
    const initial = {};
    fields.forEach((f) => {
      const val = data[f.key];
      if (f.type === "tags" || f.type === "multiselect") {
        initial[f.key] = Array.isArray(val) ? val.join(", ") : val || "";
      } else {
        initial[f.key] = val || "";
      }
    });
    return initial;
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));

  const toggleMulti = (key, option) => {
    setForm((prev) => {
      const current = prev[key] ? prev[key].split(",").map((s) => s.trim()).filter(Boolean) : [];
      const updated = current.includes(option) ? current.filter((o) => o !== option) : [...current, option];
      return { ...prev, [key]: updated.join(", ") };
    });
  };

  const parseList = (val) => val.split(",").map((s) => s.trim()).filter(Boolean);

  const handleSave = async () => {
    setSaving(true);
    setError("");
    try {
      const update = {};
      fields.forEach((f) => {
        const entityKey = ENTITY_MAP[f.key];
        if (f.type === "tags" || f.type === "multiselect") {
          update[entityKey] = parseList(form[f.key]);
        } else {
          update[entityKey] = form[f.key];
        }
      });

      const oldName = data.name;
      const newName = form.name;
      if (oldName && newName && oldName !== newName) {
        await propagateNameChange(oldName, newName);
      }
      const me = await base44.auth.me();
      const profiles = await base44.entities.Profile.filter({ email: me.email });
      if (profiles.length > 0) {
        await base44.entities.Profile.update(profiles[0].id, update);
      }

      const stored = JSON.parse(sessionStorage.getItem("onboardingData") || "{}");
      const updatedData = { ...stored };
      fields.forEach((f) => {
        if (f.type === "tags" || f.type === "multiselect") {
          updatedData[f.key] = parseList(form[f.key]);
        } else {
          updatedData[f.key] = form[f.key];
        }
      });
      sessionStorage.setItem("onboardingData", JSON.stringify(updatedData));

      onClose();
      window.location.reload();
    } catch (e) {
      setError("Failed to save. Please try again.");
      setSaving(false);
    }
  };

  const isMultiSelected = (key, option) => {
    const current = form[key] ? form[key].split(",").map((s) => s.trim()).filter(Boolean) : [];
    return current.includes(option);
  };

  return (
    <div data-source-location="src/components/EditProfileModal.jsx:132:4" data-dynamic-content="true" className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div data-source-location="src/components/EditProfileModal.jsx:133:6" data-dynamic-content="true" className="bg-card border border-border rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div data-source-location="src/components/EditProfileModal.jsx:134:8" data-dynamic-content="true" className="flex items-center justify-between px-5 py-4 border-b border-border sticky top-0 bg-card z-10">
          <h3 data-source-location="src/components/EditProfileModal.jsx:135:10" data-dynamic-content="false" className="font-heading font-bold text-foreground text-lg">Edit Profile</h3>
          <button data-source-location="src/components/EditProfileModal.jsx:136:10" data-dynamic-content="true" onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
            <X data-source-location="src/components/EditProfileModal.jsx:137:12" data-dynamic-content="false" className="w-5 h-5" />
          </button>
        </div>

        <div data-source-location="src/components/EditProfileModal.jsx:141:8" data-dynamic-content="true" className="px-5 py-4 space-y-4">
          {fields.map((f) =>
          <div data-source-location="src/components/EditProfileModal.jsx:143:12" data-dynamic-content="true" key={f.key}>
              <label data-source-location="src/components/EditProfileModal.jsx:144:14" data-dynamic-content="true" className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5 block" data-collection-item-field="label" data-collection-item-id={f?.id || f?._id}>{f.label}</label>

              {f.type === "textarea" &&
            <textarea data-source-location="src/components/EditProfileModal.jsx:147:16" data-dynamic-content="true"
            value={form[f.key]}
            onChange={(e) => handleChange(f.key, e.target.value)}
            rows={3}
            className="w-full rounded-lg border border-input bg-transparent px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring resize-none" />

            }

              {f.type === "text" &&
            <input data-source-location="src/components/EditProfileModal.jsx:156:16" data-dynamic-content="true"
            type="text"
            value={form[f.key]}
            onChange={(e) => handleChange(f.key, e.target.value)}
            className="w-full rounded-lg border border-input bg-transparent px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" />

            }

              {f.type === "tags" &&
            <input data-source-location="src/components/EditProfileModal.jsx:165:16" data-dynamic-content="true"
            type="text"
            value={form[f.key]}
            onChange={(e) => handleChange(f.key, e.target.value)}
            placeholder="Comma-separated..."
            className="w-full rounded-lg border border-input bg-transparent px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" />

            }

              {f.type === "select" &&
            <div data-source-location="src/components/EditProfileModal.jsx:175:16" data-dynamic-content="true" className="flex flex-wrap gap-1.5" data-collection-item-field="options" data-collection-item-id={f?.id || f?._id}>
                  {f.options.map((opt) => {
                const selected = form[f.key] === opt;
                return (
                  <button data-source-location="src/components/EditProfileModal.jsx:179:22" data-dynamic-content="true" key={opt} type="button" onClick={() => handleChange(f.key, selected ? "" : opt)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${selected ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:bg-muted"}`} data-collection-item-field="opt">
                        {opt}
                      </button>);

              })}
                </div>
            }

              {f.type === "multiselect" &&
            <div data-source-location="src/components/EditProfileModal.jsx:189:16" data-dynamic-content="true" className="flex flex-wrap gap-1.5" data-collection-item-field="options" data-collection-item-id={f?.id || f?._id}>
                  {f.options.map((opt) => {
                const selected = isMultiSelected(f.key, opt);
                return (
                  <button data-source-location="src/components/EditProfileModal.jsx:193:22" data-dynamic-content="true" key={opt} type="button" onClick={() => toggleMulti(f.key, opt)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1 ${selected ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:bg-muted"}`} data-collection-item-field="opt">
                        {selected && <Check data-source-location="src/components/EditProfileModal.jsx:195:37" data-dynamic-content="false" className="w-3 h-3" />} {opt}
                      </button>);

              })}
                </div>
            }
            </div>
          )}

          {role === "tutor" &&
          <p data-source-location="src/components/EditProfileModal.jsx:205:12" data-dynamic-content="false" className="text-xs text-muted-foreground italic">Pricing is set during onboarding and cannot be edited here.</p>
          }

          {error && <p data-source-location="src/components/EditProfileModal.jsx:208:20" data-dynamic-content="true" className="text-sm text-destructive" data-collection-item-field="error" data-collection-item-id={id}>{error}</p>}
        </div>

        <div data-source-location="src/components/EditProfileModal.jsx:211:8" data-dynamic-content="true" className="px-5 py-4 border-t border-border flex justify-end gap-2 sticky bottom-0 bg-card">
          <button data-source-location="src/components/EditProfileModal.jsx:212:10" data-dynamic-content="true" onClick={onClose} className="px-4 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:bg-muted transition-colors">
            Cancel
          </button>
          <button data-source-location="src/components/EditProfileModal.jsx:215:10" data-dynamic-content="true"
          onClick={handleSave}
          disabled={saving}
          className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition-colors disabled:opacity-50">
            
            <Save data-source-location="src/components/EditProfileModal.jsx:220:12" data-dynamic-content="false" className="w-4 h-4" /> {saving ? "Saving..." : "Save"}
          </button>
        </div>
      </div>
    </div>);

}