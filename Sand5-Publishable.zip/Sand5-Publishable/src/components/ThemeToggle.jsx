import { useState, useEffect } from "react";
import { Sun, Moon } from "lucide-react";

export default function ThemeToggle() {
  const [isDark, setIsDark] = useState(() => {
    const saved = localStorage.getItem("theme");
    if (saved) return saved === "dark";
    return true;
  });

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      root.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [isDark]);

  return (
    <button data-source-location="src/components/ThemeToggle.jsx:23:4" data-dynamic-content="true"
    onClick={() => setIsDark(!isDark)}
    className="fixed bottom-5 right-5 z-50 p-2.5 rounded-full bg-card/80 backdrop-blur-md border border-border shadow-lg hover:bg-accent transition-colors"
    aria-label="Toggle theme">
      
      {isDark ? <Sun data-source-location="src/components/ThemeToggle.jsx:28:16" data-dynamic-content="false" className="w-5 h-5 text-foreground" /> : <Moon data-source-location="src/components/ThemeToggle.jsx:28:62" data-dynamic-content="false" className="w-5 h-5 text-foreground" />}
    </button>);

}