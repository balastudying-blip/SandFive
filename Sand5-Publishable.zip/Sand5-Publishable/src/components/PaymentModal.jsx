import { useState } from "react";
import { CreditCard, Check, X, Shield, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";

const PAYPAL_HANDLE = "JayakrishnaArvapalli";

function paypalLink(amount) {
  const a = Number(amount || 0).toFixed(2);
  return `https://www.paypal.com/paypalme/${PAYPAL_HANDLE}/${a}`;
}

export default function PaymentModal({ payee, payerName, amount, subject, savedCard, onCardSaved, onClose, "data-collection-item-id": __dataCollectionItemId }) {
  const [done, setDone] = useState(false);
  const [customAmount, setCustomAmount] = useState("");
  const [processing, setProcessing] = useState(false);

  const hasFixedAmount = amount != null && amount > 0;
  const finalAmount = hasFixedAmount ? amount : parseFloat(customAmount) || 0;

  const handlePay = async (e) => {
    e.preventDefault();
    if (finalAmount <= 0) return;
    setProcessing(true);
    try {
      window.open(paypalLink(finalAmount), "_blank");
      await base44.entities.Payment.create({
        payer_name: payerName,
        payee_name: payee.name,
        amount: finalAmount,
        subject: subject,
        status: "completed"
      });
      setDone(true);
    } catch (err) {
      setDone(true);
    }
    setProcessing(false);
  };

  return (
    <div data-source-location="src/components/PaymentModal.jsx:42:4" data-dynamic-content="true" className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose} data-collection-item-id={__dataCollectionItemId}>
      <div data-source-location="src/components/PaymentModal.jsx:43:6" data-dynamic-content="true" className="bg-card rounded-2xl border border-border p-6 max-w-sm w-full shadow-2xl" onClick={(e) => e.stopPropagation()}>
        {done ?
        <div data-source-location="src/components/PaymentModal.jsx:45:10" data-dynamic-content="true" className="text-center py-6">
            <div data-source-location="src/components/PaymentModal.jsx:46:12" data-dynamic-content="false" className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check data-source-location="src/components/PaymentModal.jsx:47:14" data-dynamic-content="false" className="w-7 h-7 text-primary" />
            </div>
            <h3 data-source-location="src/components/PaymentModal.jsx:49:12" data-dynamic-content="false" className="text-lg font-heading font-bold text-foreground mb-1">Payment Sent</h3>
            <p data-source-location="src/components/PaymentModal.jsx:50:12" data-dynamic-content="true" className="text-sm text-muted-foreground mb-4" data-collection-item-field="finalAmount" data-collection-item-id={__dataCollectionItemId}>${finalAmount} to {payee.name} via PayPal</p>
            <Button data-source-location="src/components/PaymentModal.jsx:51:12" data-dynamic-content="true" onClick={onClose} className="bg-primary text-primary-foreground w-full">Done</Button>
          </div> :

        <>
            <div data-source-location="src/components/PaymentModal.jsx:55:12" data-dynamic-content="true" className="flex items-center justify-between mb-4">
              <div data-source-location="src/components/PaymentModal.jsx:56:14" data-dynamic-content="true" className="flex items-center gap-2">
                <div data-source-location="src/components/PaymentModal.jsx:57:16" data-dynamic-content="false" className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                  <CreditCard data-source-location="src/components/PaymentModal.jsx:58:18" data-dynamic-content="false" className="w-4 h-4 text-primary" />
                </div>
                <div data-source-location="src/components/PaymentModal.jsx:60:16" data-dynamic-content="true">
                  <h3 data-source-location="src/components/PaymentModal.jsx:61:18" data-dynamic-content="true" className="text-base font-heading font-bold text-foreground" data-collection-item-field="name" data-collection-item-id={payee?.id || payee?._id}>Pay {payee.name}</h3>
                  <p data-source-location="src/components/PaymentModal.jsx:62:18" data-dynamic-content="true" className="text-xs text-muted-foreground" data-collection-item-field="subject" data-collection-item-id={__dataCollectionItemId}>{subject}{hasFixedAmount ? ` · $${amount}` : ""}</p>
                </div>
              </div>
              <button data-source-location="src/components/PaymentModal.jsx:65:14" data-dynamic-content="true" onClick={onClose} className="text-muted-foreground hover:text-foreground">
                <X data-source-location="src/components/PaymentModal.jsx:66:16" data-dynamic-content="false" className="w-4 h-4" />
              </button>
            </div>

            {!hasFixedAmount &&
          <div data-source-location="src/components/PaymentModal.jsx:71:14" data-dynamic-content="true" className="mb-4">
                <label data-source-location="src/components/PaymentModal.jsx:72:16" data-dynamic-content="false" className="text-xs font-medium text-muted-foreground block mb-1">Amount ($)</label>
                <input data-source-location="src/components/PaymentModal.jsx:73:16" data-dynamic-content="true" type="number" value={customAmount} onChange={(e) => setCustomAmount(e.target.value)}
            placeholder="Enter agreed amount" min="1" step="0.01"
            className="w-full h-9 px-3 rounded-md border border-input bg-transparent text-sm text-foreground" />
              </div>
          }

            {finalAmount > 0 &&
          <form data-source-location="src/components/PaymentModal.jsx:80:14" data-dynamic-content="true" onSubmit={handlePay}>
                <Button data-source-location="src/components/PaymentModal.jsx:81:16" data-dynamic-content="true" type="submit" disabled={processing} className="w-full bg-primary text-primary-foreground flex items-center justify-center gap-2">
                  {processing ?
              <span data-source-location="src/components/PaymentModal.jsx:83:20" data-dynamic-content="false" className="flex items-center gap-2">
                      <span data-source-location="src/components/PaymentModal.jsx:84:22" data-dynamic-content="false" className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                      Opening PayPal...
                    </span> :

              <span data-source-location="src/components/PaymentModal.jsx:88:20" data-dynamic-content="true" className="flex items-center gap-2" data-collection-item-field="finalAmount" data-collection-item-id={__dataCollectionItemId}><ExternalLink data-source-location="src/components/PaymentModal.jsx:88:62" data-dynamic-content="false" className="w-4 h-4" /> Pay ${finalAmount} with PayPal</span>
              }
                </Button>
                <p data-source-location="src/components/PaymentModal.jsx:91:16" data-dynamic-content="false" className="text-xs text-muted-foreground text-center mt-3 flex items-center justify-center gap-1">
                  <Shield data-source-location="src/components/PaymentModal.jsx:92:18" data-dynamic-content="false" className="w-3 h-3" /> Secured by PayPal · @JayakrishnaArvapalli
                </p>
              </form>
          }
          </>
        }
      </div>
    </div>);

}