export default function Logo({ height = 16, className = "", blend = true, "data-collection-item-id": __dataCollectionItemId }) {
  return (
    <img data-source-location="src/components/Logo.jsx:3:4" data-dynamic-content="true"
    src="https://media.base44.com/images/public/6a209098fbba791339b64f5c/32f802abe_ACTUALLOGO.png"
    alt="S&5"
    style={{ height: `${height}px`, width: "auto" }}
    className={`object-contain ${className}`} data-collection-item-id={__dataCollectionItemId} />);


}