import { useState, useEffect } from "react";
import { Star, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";

function Stars({ rating, size = 16 }) {
  return (
    <div data-source-location="src/components/ReviewsModal.jsx:8:4" data-dynamic-content="true" className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i, __arrIdx__) =>
      <Star data-source-location="src/components/ReviewsModal.jsx:10:8" data-dynamic-content="true" key={i}
      className={i <= rating ? "fill-amber-400 text-amber-400" : "text-muted-foreground/30"}
      style={{ width: size, height: size }} data-arr-index={__arrIdx__} />
      )}
    </div>);

}

export default function ReviewsModal({ tutorName, allowReview = false, onClose, id }) {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [myRating, setMyRating] = useState(5);
  const [myComment, setMyComment] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const data = await base44.entities.Review.filter({ tutor_name: tutorName });
        setReviews(data);
      } catch (e) {
        console.error("Failed to load reviews:", e);
      } finally {
        setLoading(false);
      }
    })();
  }, [tutorName]);

  const handleSubmit = async () => {
    const studentName = JSON.parse(sessionStorage.getItem("onboardingData") || "{}").name || "Anonymous";
    setSubmitting(true);
    try {
      await base44.entities.Review.create({
        tutor_name: tutorName,
        reviewer_name: studentName,
        rating: myRating,
        comment: myComment.trim() || ""
      });
      const data = await base44.entities.Review.filter({ tutor_name: tutorName });
      setReviews(data);
      setMyComment("");
      setMyRating(5);
    } catch (e) {
      console.error("Failed to submit review:", e);
    } finally {
      setSubmitting(false);
    }
  };

  const avgRating = reviews.length > 0 ?
  (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1) :
  null;

  return (
    <div data-source-location="src/components/ReviewsModal.jsx:64:4" data-dynamic-content="true" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={onClose}>
      <div data-source-location="src/components/ReviewsModal.jsx:65:6" data-dynamic-content="true" className="bg-card rounded-2xl border border-border w-full max-w-lg max-h-[80vh] overflow-hidden flex flex-col" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div data-source-location="src/components/ReviewsModal.jsx:67:8" data-dynamic-content="true" className="flex items-center justify-between px-5 py-4 border-b border-border">
          <div data-source-location="src/components/ReviewsModal.jsx:68:10" data-dynamic-content="true">
            <h2 data-source-location="src/components/ReviewsModal.jsx:69:12" data-dynamic-content="true" className="font-heading font-bold text-foreground text-lg" data-collection-item-field="tutorName" data-collection-item-id={id}>{tutorName}'s Reviews</h2>
            {avgRating ?
            <div data-source-location="src/components/ReviewsModal.jsx:71:14" data-dynamic-content="true" className="flex items-center gap-2 mt-1">
                <Stars data-source-location="src/components/ReviewsModal.jsx:72:16" data-dynamic-content="true" rating={Math.round(parseFloat(avgRating))} />
                <span data-source-location="src/components/ReviewsModal.jsx:73:16" data-dynamic-content="true" className="text-sm text-muted-foreground font-medium" data-collection-item-field="avgRating" data-collection-item-id={id}>{avgRating} out of 5 ⭐ ({reviews.length} review{reviews.length !== 1 ? "s" : ""})</span>
              </div> :

            !loading && <p data-source-location="src/components/ReviewsModal.jsx:76:26" data-dynamic-content="false" className="text-sm text-muted-foreground mt-1">No reviews yet</p>
            }
          </div>
          <button data-source-location="src/components/ReviewsModal.jsx:79:10" data-dynamic-content="true" onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
            <X data-source-location="src/components/ReviewsModal.jsx:80:12" data-dynamic-content="false" className="w-5 h-5" />
          </button>
        </div>

        {/* Reviews list */}
        <div data-source-location="src/components/ReviewsModal.jsx:85:8" data-dynamic-content="true" className="flex-1 overflow-y-auto px-5 py-4 space-y-3" data-collection-id="Review">
          {loading ?
          <p data-source-location="src/components/ReviewsModal.jsx:87:12" data-dynamic-content="false" className="text-center text-muted-foreground py-8">Loading reviews...</p> :
          reviews.length === 0 ?
          <div data-source-location="src/components/ReviewsModal.jsx:89:12" data-dynamic-content="false" className="text-center py-8">
              <Star data-source-location="src/components/ReviewsModal.jsx:90:14" data-dynamic-content="false" className="w-10 h-10 text-muted-foreground/20 mx-auto mb-2" />
              <p data-source-location="src/components/ReviewsModal.jsx:91:14" data-dynamic-content="false" className="text-muted-foreground">No reviews yet. Be the first to review!</p>
            </div> :

          reviews.map((r, i) =>
          <div data-source-location="src/components/ReviewsModal.jsx:95:14" data-dynamic-content="true" key={r.id || i} className="bg-muted/50 rounded-xl p-3 border border-border" data-collection-item-field="comment" data-collection-item-id={r?.id || r?._id}>
                <div data-source-location="src/components/ReviewsModal.jsx:96:16" data-dynamic-content="true" className="flex items-center justify-between mb-1">
                  <span data-source-location="src/components/ReviewsModal.jsx:97:18" data-dynamic-content="true" className="font-semibold text-foreground text-sm" data-collection-item-field="reviewer_name" data-collection-item-id={r?.id || r?._id}>{r.reviewer_name}</span>
                  <Stars data-source-location="src/components/ReviewsModal.jsx:98:18" data-dynamic-content="true" rating={r.rating} size={14} />
                </div>
                {r.comment && <p data-source-location="src/components/ReviewsModal.jsx:100:30" data-dynamic-content="true" className="text-sm text-muted-foreground leading-relaxed" data-collection-item-field="comment" data-collection-item-id={r?.id || r?._id}>{r.comment}</p>}
              </div>
          )
          }
        </div>

        {/* Leave review form */}
        {allowReview &&
        <div data-source-location="src/components/ReviewsModal.jsx:108:10" data-dynamic-content="true" className="border-t border-border px-5 py-4">
            <p data-source-location="src/components/ReviewsModal.jsx:109:12" data-dynamic-content="false" className="text-sm font-semibold text-foreground mb-2">Leave a Review</p>
            <div data-source-location="src/components/ReviewsModal.jsx:110:12" data-dynamic-content="true" className="flex items-center gap-2 mb-2">
              {[1, 2, 3, 4, 5].map((i, __arrIdx__) =>
            <button data-source-location="src/components/ReviewsModal.jsx:112:16" data-dynamic-content="true" key={i} onClick={() => setMyRating(i)} className="transition-transform hover:scale-110" data-arr-index={__arrIdx__}>
                  <Star data-source-location="src/components/ReviewsModal.jsx:113:18" data-dynamic-content="true" className={`w-6 h-6 ${i <= myRating ? "fill-amber-400 text-amber-400" : "text-muted-foreground/30"}`} data-arr-index={__arrIdx__} />
                </button>
            )}
              <span data-source-location="src/components/ReviewsModal.jsx:116:14" data-dynamic-content="true" className="text-sm text-muted-foreground ml-1" data-collection-item-field="myRating" data-collection-item-id={id}>{myRating} out of 5</span>
            </div>
            <textarea data-source-location="src/components/ReviewsModal.jsx:118:12" data-dynamic-content="true" value={myComment} onChange={(e) => setMyComment(e.target.value)}
          placeholder="Share your experience..."
          rows={2}
          className="w-full border border-border rounded-xl px-3 py-2 text-sm bg-background focus:outline-none focus:border-primary resize-none mb-2" />
            <Button data-source-location="src/components/ReviewsModal.jsx:122:12" data-dynamic-content="true" onClick={handleSubmit} disabled={submitting}
          className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
              {submitting ? "Submitting..." : "Submit Review"}
            </Button>
          </div>
        }
      </div>
    </div>);

}