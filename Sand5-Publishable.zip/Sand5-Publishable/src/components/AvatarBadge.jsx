// Shared mini avatar renderer used in dashboards

export default function AvatarBadge({ avatar, size = 64, "data-collection-item-id": __dataCollectionItemId }) {
  const imgUrl = avatar?.dataUrl || avatar?.url;
  if (imgUrl)
  return <img data-source-location="src/components/AvatarBadge.jsx:6:11" data-dynamic-content="true" src={imgUrl} alt="Avatar" style={{ width: size, height: size }} className="rounded-full object-cover border-2 border-border shadow" data-collection-item-id={__dataCollectionItemId} />;

  if (avatar?.type === "letter") {
    const radiusClass = avatar.shape === "circle" ? "rounded-full" : avatar.shape === "rounded" ? "rounded-2xl" : "rounded-lg";
    return (
      <div data-source-location="src/components/AvatarBadge.jsx:11:6" data-dynamic-content="true"
      className={`flex items-center justify-center border-2 border-border shadow ${radiusClass}`}
      style={{ width: size, height: size, backgroundColor: avatar.bgColor, color: avatar.textColor }} data-collection-item-id={__dataCollectionItemId}>
        
        <span data-source-location="src/components/AvatarBadge.jsx:15:8" data-dynamic-content="true" className="font-heading font-bold" style={{ fontSize: size * 0.45 }}>
          {avatar.letter || "U"}
        </span>
      </div>);

  }

  return (
    <div data-source-location="src/components/AvatarBadge.jsx:23:4" data-dynamic-content="true" style={{ width: size, height: size }} className="rounded-full bg-secondary border-2 border-border shadow flex items-center justify-center" data-collection-item-id={__dataCollectionItemId}>
      <span data-source-location="src/components/AvatarBadge.jsx:24:6" data-dynamic-content="true" className="font-heading font-bold text-muted-foreground" style={{ fontSize: size * 0.45 }}>
        U
      </span>
    </div>);

}