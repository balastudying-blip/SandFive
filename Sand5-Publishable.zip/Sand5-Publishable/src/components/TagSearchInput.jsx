import { useState, useRef, useEffect } from "react";
import { X, Search } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";

export default function TagSearchInput({ suggestions, value = [], onChange, placeholder = "Search and add..." }) {
  const [query, setQuery] = useState("");
  const [showDropdown, setShowDropdown] = useState(false);
  const inputRef = useRef(null);
  const containerRef = useRef(null);

  const filtered = suggestions.filter(
    (s) => s.toLowerCase().includes(query.toLowerCase()) && !value.includes(s)
  );

  const addTag = (tag) => {
    if (!value.includes(tag)) onChange([...value, tag]);
    setQuery("");
    inputRef.current?.focus();
  };

  const addCustom = () => {
    const trimmed = query.trim();
    if (trimmed && !value.includes(trimmed)) {
      onChange([...value, trimmed]);
      setQuery("");
    }
  };

  const removeTag = (tag) => onChange(value.filter((t) => t !== tag));

  useEffect(() => {
    const handleClick = (e) => {
      if (!containerRef.current?.contains(e.target)) setShowDropdown(false);
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  const showCustomOption = query.trim() && !suggestions.includes(query.trim()) && !value.includes(query.trim());

  return (
    <div data-source-location="src/components/TagSearchInput.jsx:42:4" data-dynamic-content="true" ref={containerRef} className="space-y-3">
      {/* Tags */}
      {value.length > 0 &&
      <div data-source-location="src/components/TagSearchInput.jsx:45:8" data-dynamic-content="true" className="flex flex-wrap gap-2">
          {value.map((tag) =>
        <motion.span data-source-location="src/components/TagSearchInput.jsx:47:12" data-dynamic-content="true"
        key={tag}
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.8 }}
        className="inline-flex items-center gap-1.5 bg-primary text-primary-foreground text-sm font-medium px-3 py-1.5 rounded-full" data-collection-item-field="tag">
          
              {tag}
              <button data-source-location="src/components/TagSearchInput.jsx:55:14" data-dynamic-content="true" onClick={() => removeTag(tag)} className="hover:opacity-70 transition-opacity">
                <X data-source-location="src/components/TagSearchInput.jsx:56:16" data-dynamic-content="false" className="w-3.5 h-3.5" />
              </button>
            </motion.span>
        )}
        </div>
      }

      {/* Search input */}
      <div data-source-location="src/components/TagSearchInput.jsx:64:6" data-dynamic-content="true" className="relative">
        <Search data-source-location="src/components/TagSearchInput.jsx:65:8" data-dynamic-content="false" className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input data-source-location="src/components/TagSearchInput.jsx:66:8" data-dynamic-content="true"
        ref={inputRef}
        value={query}
        onChange={(e) => {setQuery(e.target.value);setShowDropdown(true);}}
        onFocus={() => setShowDropdown(true)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {e.preventDefault();filtered.length > 0 ? addTag(filtered[0]) : addCustom();}
        }}
        placeholder={placeholder}
        className="w-full pl-10 pr-4 py-3 border-2 border-border rounded-xl focus:border-gray-900 outline-none font-body text-foreground placeholder:text-muted-foreground transition-colors" />
        

        <AnimatePresence data-source-location="src/components/TagSearchInput.jsx:78:8" data-dynamic-content="true">
          {showDropdown && (filtered.length > 0 || showCustomOption) &&
          <motion.div data-source-location="src/components/TagSearchInput.jsx:80:12" data-dynamic-content="true"
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -4 }}
          transition={{ duration: 0.15 }}
          className="absolute z-50 mt-1 w-full bg-popover border border-border rounded-xl shadow-lg overflow-hidden max-h-56 overflow-y-auto" data-collection-id="suggestions">
            
              {filtered.map((s) =>
            <button data-source-location="src/components/TagSearchInput.jsx:88:16" data-dynamic-content="true"
            key={s}
            onMouseDown={(e) => {e.preventDefault();addTag(s);}}
            className="w-full text-left px-4 py-3 text-sm font-body text-popover-foreground hover:bg-muted transition-colors" data-collection-item-field="s">
              
                  {s}
                </button>
            )}
              {showCustomOption &&
            <button data-source-location="src/components/TagSearchInput.jsx:97:16" data-dynamic-content="true"
            onMouseDown={(e) => {e.preventDefault();addCustom();}}
            className="w-full text-left px-4 py-3 text-sm font-body text-muted-foreground hover:bg-muted transition-colors border-t border-border">
              
                  Add "<span data-source-location="src/components/TagSearchInput.jsx:101:23" data-dynamic-content="true" className="font-medium text-foreground">{query.trim()}</span>"
                </button>
            }
            </motion.div>
          }
        </AnimatePresence>
      </div>
    </div>);

}