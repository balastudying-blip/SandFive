export default function ShaderBackground() {
  return (
    <div data-source-location="src/components/ui/shader-background.jsx:3:4" data-dynamic-content="true"
    style={{
      position: "fixed",
      inset: 0,
      width: "100vw",
      height: "100dvh",
      background: "var(--background)",
      overflow: "hidden",
      zIndex: 0,
      pointerEvents: "none"
    }}>
      
      <div data-source-location="src/components/ui/shader-background.jsx:15:6" data-dynamic-content="true"
      style={{
        position: "absolute",
        inset: 0,
        opacity: 0.05,
        mixBlendMode: "overlay",
        pointerEvents: "none",
        backgroundImage:
        "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/></filter><rect width='100%25' height='100%25' filter='url(%23n)'/></svg>\")"
      }} />
      
    </div>);

}