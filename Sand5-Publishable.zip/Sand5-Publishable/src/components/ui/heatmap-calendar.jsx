import * as React from "react";
import { useState } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronLeft, ChevronRight, Trash2, Clock, Plus } from "lucide-react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, addMonths } from "date-fns";

const TIME_SLOTS = (() => {
  const slots = [];
  for (let h = 6; h <= 22; h++) {
    for (const m of [0, 15, 30, 45]) {
      const hour12 = h % 12 || 12;
      const ampm = h < 12 ? "AM" : "PM";
      slots.push(`${hour12}:${String(m).padStart(2, "0")} ${ampm}`);
    }
  }
  return slots;
})();

export default function HeatmapCalendar({ storageKey = "calendarEvents" }) {
  const [selectedDate, setSelectedDate] = React.useState(new Date());
  const [newTitle, setNewTitle] = React.useState("");
  const [newStartTime, setNewStartTime] = useState("");
  const [newEndTime, setNewEndTime] = useState("");
  const [events, setEvents] = React.useState(() =>
  JSON.parse(sessionStorage.getItem(storageKey) || "[]")
  );

  const saveEvents = (updated) => {
    setEvents(updated);
    sessionStorage.setItem(storageKey, JSON.stringify(updated));
  };

  const handleAddEvent = () => {
    if (!newTitle.trim()) return;
    saveEvents([...events, {
      id: crypto.randomUUID(),
      title: newTitle.trim(),
      date: selectedDate.toISOString(),
      startTime: newStartTime || "",
      endTime: newEndTime || ""
    }]);
    setNewTitle("");
    setNewStartTime("");
    setNewEndTime("");
  };

  const handleRemoveEvent = (id) => {
    saveEvents(events.filter((e) => e.id !== id));
  };

  const daysInMonth = eachDayOfInterval({
    start: startOfMonth(selectedDate),
    end: endOfMonth(selectedDate)
  });

  const eventsForDay = (date) =>
  events.filter((e) => format(new Date(e.date), "yyyy-MM-dd") === format(date, "yyyy-MM-dd"));

  const getIntensity = (count) => {
    if (count === 0) return "bg-muted/40 hover:bg-muted";
    if (count === 1) return "bg-green-500/30";
    if (count === 2) return "bg-green-500/50";
    return "bg-green-500/70";
  };

  const firstDayOfWeek = startOfMonth(selectedDate).getDay();
  const todayStr = format(new Date(), "yyyy-MM-dd");

  return (
    <div data-source-location="src/components/ui/heatmap-calendar.jsx:72:4" data-dynamic-content="true" className="bg-card/40 backdrop-blur-xl rounded-3xl border border-border/40 p-4 h-full">
      {/* Month navigation */}
      <div data-source-location="src/components/ui/heatmap-calendar.jsx:74:6" data-dynamic-content="true" className="flex items-center justify-between mb-3">
        <button data-source-location="src/components/ui/heatmap-calendar.jsx:75:8" data-dynamic-content="true" onClick={() => setSelectedDate((d) => addMonths(d, -1))} className="text-muted-foreground hover:text-foreground p-1 rounded-lg hover:bg-muted/50 transition-colors">
          <ChevronLeft data-source-location="src/components/ui/heatmap-calendar.jsx:76:10" data-dynamic-content="false" className="w-4 h-4" />
        </button>
        <p data-source-location="src/components/ui/heatmap-calendar.jsx:78:8" data-dynamic-content="true" className="text-xs font-semibold text-foreground">{format(selectedDate, "MMMM yyyy")}</p>
        <button data-source-location="src/components/ui/heatmap-calendar.jsx:79:8" data-dynamic-content="true" onClick={() => setSelectedDate((d) => addMonths(d, 1))} className="text-muted-foreground hover:text-foreground p-1 rounded-lg hover:bg-muted/50 transition-colors">
          <ChevronRight data-source-location="src/components/ui/heatmap-calendar.jsx:80:10" data-dynamic-content="false" className="w-4 h-4" />
        </button>
      </div>

      {/* Day labels */}
      <div data-source-location="src/components/ui/heatmap-calendar.jsx:85:6" data-dynamic-content="true" className="grid grid-cols-7 gap-0.5 mb-1">
        {["S", "M", "T", "W", "T", "F", "S"].map((d, i) =>
        <div data-source-location="src/components/ui/heatmap-calendar.jsx:87:10" data-dynamic-content="true" key={i} className="text-center text-[9px] text-muted-foreground font-medium py-0.5" data-arr-index={i}>{d}</div>
        )}
      </div>

      {/* Heatmap grid */}
      <div data-source-location="src/components/ui/heatmap-calendar.jsx:92:6" data-dynamic-content="true" className="grid grid-cols-7 gap-0.5">
        {Array.from({ length: firstDayOfWeek }).map((_, i) =>
        <div data-source-location="src/components/ui/heatmap-calendar.jsx:94:10" data-dynamic-content="true" key={`blank-${i}`} className="aspect-square" />
        )}
        {daysInMonth.map((day) => {
          const dayEvents = eventsForDay(day);
          const isToday = format(day, "yyyy-MM-dd") === todayStr;
          return (
            <Popover data-source-location="src/components/ui/heatmap-calendar.jsx:100:12" data-dynamic-content="true" key={day.toISOString()}>
              <PopoverTrigger data-source-location="src/components/ui/heatmap-calendar.jsx:101:14" data-dynamic-content="true" asChild>
                <div data-source-location="src/components/ui/heatmap-calendar.jsx:102:16" data-dynamic-content="true"
                className={`aspect-square rounded-md flex items-center justify-center cursor-pointer transition-all ${getIntensity(dayEvents.length)} ${isToday ? "ring-1 ring-green-500" : ""}`}
                onClick={() => setSelectedDate(day)}>
                  <span data-source-location="src/components/ui/heatmap-calendar.jsx:105:18" data-dynamic-content="true" className="text-[10px] font-medium text-foreground">{day.getDate()}</span>
                </div>
              </PopoverTrigger>
              <PopoverContent data-source-location="src/components/ui/heatmap-calendar.jsx:108:14" data-dynamic-content="true" className="w-56">
                <div data-source-location="src/components/ui/heatmap-calendar.jsx:109:16" data-dynamic-content="true" className="space-y-2 p-1">
                  <h3 data-source-location="src/components/ui/heatmap-calendar.jsx:110:18" data-dynamic-content="true" className="font-medium text-xs text-foreground">{format(day, "PPP")}</h3>
                  {dayEvents.length === 0 ?
                  <p data-source-location="src/components/ui/heatmap-calendar.jsx:112:20" data-dynamic-content="false" className="text-[10px] text-muted-foreground">No activities</p> :

                  dayEvents.map((event) =>
                  <div data-source-location="src/components/ui/heatmap-calendar.jsx:115:22" data-dynamic-content="true" key={event.id} className="flex justify-between items-start text-[10px] gap-2" data-collection-item-id={event?.id}>
                        <div data-source-location="src/components/ui/heatmap-calendar.jsx:116:24" data-dynamic-content="true" className="flex-1">
                          <p data-source-location="src/components/ui/heatmap-calendar.jsx:117:26" data-dynamic-content="true" className="text-foreground font-medium" data-collection-item-field="title" data-collection-item-id={event?.id}>{event.title}</p>
                          {event.startTime && event.endTime &&
                      <p data-source-location="src/components/ui/heatmap-calendar.jsx:119:28" data-dynamic-content="true" className="text-muted-foreground mt-0.5 flex items-center gap-1" data-collection-item-field="startTime" data-collection-item-id={event?.id}>
                              <Clock data-source-location="src/components/ui/heatmap-calendar.jsx:120:30" data-dynamic-content="false" className="w-2.5 h-2.5" />{event.startTime} – {event.endTime}
                            </p>
                      }
                        </div>
                        <Button data-source-location="src/components/ui/heatmap-calendar.jsx:124:24" data-dynamic-content="true" variant="ghost" size="icon" className="h-4 w-4 p-0 flex-shrink-0" onClick={() => handleRemoveEvent(event.id)}>
                          <Trash2 data-source-location="src/components/ui/heatmap-calendar.jsx:125:26" data-dynamic-content="false" className="h-3 w-3 text-destructive" />
                        </Button>
                      </div>
                  )
                  }
                </div>
              </PopoverContent>
            </Popover>);

        })}
      </div>

      {/* Add activity with time */}
      <div data-source-location="src/components/ui/heatmap-calendar.jsx:138:6" data-dynamic-content="true" className="mt-3 space-y-2">
        <Input data-source-location="src/components/ui/heatmap-calendar.jsx:139:8" data-dynamic-content="true"
        placeholder="Activity name..."
        value={newTitle}
        onChange={(e) => setNewTitle(e.target.value)}
        onKeyDown={(e) => {if (e.key === "Enter") {e.preventDefault();handleAddEvent();}}}
        className="h-9 text-xs bg-muted/50 border-border" />
        
        <div data-source-location="src/components/ui/heatmap-calendar.jsx:146:8" data-dynamic-content="true" className="grid grid-cols-2 gap-2">
          <div data-source-location="src/components/ui/heatmap-calendar.jsx:147:10" data-dynamic-content="true">
            <label data-source-location="src/components/ui/heatmap-calendar.jsx:148:12" data-dynamic-content="false" className="text-[9px] text-muted-foreground font-medium uppercase tracking-wide mb-1 block">Start</label>
            <select data-source-location="src/components/ui/heatmap-calendar.jsx:149:12" data-dynamic-content="true"
            value={newStartTime}
            onChange={(e) => setNewStartTime(e.target.value)}
            className="w-full h-9 text-xs rounded-md border border-border bg-card text-foreground px-2 cursor-pointer focus:border-primary focus:outline-none">
              
              <option data-source-location="src/components/ui/heatmap-calendar.jsx:154:14" data-dynamic-content="false" value="">--:--</option>
              {TIME_SLOTS.map((t) => <option data-source-location="src/components/ui/heatmap-calendar.jsx:155:35" data-dynamic-content="true" key={t} value={t} data-collection-item-field="t">{t}</option>)}
            </select>
          </div>
          <div data-source-location="src/components/ui/heatmap-calendar.jsx:158:10" data-dynamic-content="true">
            <label data-source-location="src/components/ui/heatmap-calendar.jsx:159:12" data-dynamic-content="false" className="text-[9px] text-muted-foreground font-medium uppercase tracking-wide mb-1 block">End</label>
            <select data-source-location="src/components/ui/heatmap-calendar.jsx:160:12" data-dynamic-content="true"
            value={newEndTime}
            onChange={(e) => setNewEndTime(e.target.value)}
            className="w-full h-9 text-xs rounded-md border border-border bg-card text-foreground px-2 cursor-pointer focus:border-primary focus:outline-none">
              
              <option data-source-location="src/components/ui/heatmap-calendar.jsx:165:14" data-dynamic-content="false" value="">--:--</option>
              {TIME_SLOTS.map((t) => <option data-source-location="src/components/ui/heatmap-calendar.jsx:166:35" data-dynamic-content="true" key={t} value={t} data-collection-item-field="t">{t}</option>)}
            </select>
          </div>
        </div>
        <Button data-source-location="src/components/ui/heatmap-calendar.jsx:170:8" data-dynamic-content="true" onClick={handleAddEvent} size="sm" className="w-full h-9 text-xs">
          <Plus data-source-location="src/components/ui/heatmap-calendar.jsx:171:10" data-dynamic-content="false" className="w-3.5 h-3.5 mr-1" /> Add Activity
        </Button>
      </div>
    </div>);

}