import * as React from "react";
import { OTPInput, OTPInputContext } from "input-otp";
import { Minus } from "lucide-react";

import { cn } from "@/lib/utils";

const InputOTP = React.forwardRef(({ className, containerClassName, ...props }, ref) =>
<OTPInput data-source-location="src/components/ui/input-otp.jsx:8:2" data-dynamic-content="true"
ref={ref}
containerClassName={cn("flex items-center gap-2 has-[:disabled]:opacity-50", containerClassName)}
className={cn("disabled:cursor-not-allowed", className)}
{...props} />
);
InputOTP.displayName = "InputOTP";

const InputOTPGroup = React.forwardRef(({ className, ...props }, ref) =>
<div data-source-location="src/components/ui/input-otp.jsx:17:2" data-dynamic-content="true" ref={ref} className={cn("flex items-center", className)} {...props} />
);
InputOTPGroup.displayName = "InputOTPGroup";

const InputOTPSlot = React.forwardRef(({ index, className, id, ...props }, ref) => {
  const inputOTPContext = React.useContext(OTPInputContext);
  const { char, hasFakeCaret, isActive } = inputOTPContext.slots[index];

  return (
    <div data-source-location="src/components/ui/input-otp.jsx:26:5" data-dynamic-content="true"
    ref={ref}
    className={cn(
      "relative flex h-9 w-9 items-center justify-center border-y border-r border-input text-sm shadow-sm transition-all first:rounded-l-md first:border-l last:rounded-r-md",
      isActive && "z-10 ring-1 ring-ring",
      className
    )}
    {...props} data-collection-item-field="char" data-collection-item-id={id}>
      {char}
      {hasFakeCaret &&
      <div data-source-location="src/components/ui/input-otp.jsx:36:8" data-dynamic-content="false"
      className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div data-source-location="src/components/ui/input-otp.jsx:38:10" data-dynamic-content="false" className="h-4 w-px animate-caret-blink bg-foreground duration-1000" />
        </div>
      }
    </div>);

});
InputOTPSlot.displayName = "InputOTPSlot";

const InputOTPSeparator = React.forwardRef(({ ...props }, ref) =>
<div data-source-location="src/components/ui/input-otp.jsx:47:2" data-dynamic-content="true" ref={ref} role="separator" {...props}>
    <Minus data-source-location="src/components/ui/input-otp.jsx:48:4" data-dynamic-content="false" />
  </div>
);
InputOTPSeparator.displayName = "InputOTPSeparator";

export { InputOTP, InputOTPGroup, InputOTPSlot, InputOTPSeparator };