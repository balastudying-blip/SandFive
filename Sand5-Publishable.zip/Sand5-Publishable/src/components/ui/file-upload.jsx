import { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import clsx from "clsx";
import { UploadCloud, File as FileIcon, Trash2, Loader, CheckCircle } from "lucide-react";

export default function FileUpload({ onFilesChange }) {
  const [files, setFiles] = useState([]);
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useRef(null);

  const handleFiles = (fileList) => {
    const newFiles = Array.from(fileList).map((file) => ({
      id: `${Date.now()}-${file.name}`,
      preview: URL.createObjectURL(file),
      progress: 0,
      name: file.name,
      size: file.size,
      type: file.type,
      file
    }));
    const updated = [...files, ...newFiles];
    setFiles(updated);
    onFilesChange?.(updated);
    newFiles.forEach((f) => simulateUpload(f.id));
  };

  const simulateUpload = (id) => {
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 20;
      setFiles((prev) => prev.map((f) => f.id === id ? { ...f, progress: Math.min(progress, 100) } : f));
      if (progress >= 100) clearInterval(interval);
    }, 250);
  };

  const onDrop = (e) => {e.preventDefault();setIsDragging(false);handleFiles(e.dataTransfer.files);};
  const onDragOver = (e) => {e.preventDefault();setIsDragging(true);};

  const formatSize = (b) => {
    if (!b) return "0 B";
    const k = 1024,sizes = ["B", "KB", "MB", "GB"],i = Math.floor(Math.log(b) / Math.log(k));
    return `${(b / Math.pow(k, i)).toFixed(1)} ${sizes[i]}`;
  };

  return (
    <div data-source-location="src/components/ui/file-upload.jsx:46:4" data-dynamic-content="true" className="w-full">
      <motion.div data-source-location="src/components/ui/file-upload.jsx:47:6" data-dynamic-content="true"
      onDragOver={onDragOver} onDragLeave={() => setIsDragging(false)} onDrop={onDrop}
      onClick={() => inputRef.current?.click()}
      animate={{ scale: isDragging ? 1.02 : 1 }}
      className={clsx("rounded-2xl p-8 text-center cursor-pointer bg-muted/40 border-2 border-dashed transition-colors",
      isDragging ? "border-primary" : "border-border hover:border-primary/50")}>
        <UploadCloud data-source-location="src/components/ui/file-upload.jsx:53:8" data-dynamic-content="true" className={clsx("w-12 h-12 mx-auto mb-3", isDragging ? "text-primary" : "text-muted-foreground")} />
        <p data-source-location="src/components/ui/file-upload.jsx:54:8" data-dynamic-content="true" className="font-semibold text-foreground mb-1">{isDragging ? "Drop files here" : "Upload Assignment Files"}</p>
        <p data-source-location="src/components/ui/file-upload.jsx:55:8" data-dynamic-content="false" className="text-sm text-muted-foreground">Drag & drop or <span data-source-location="src/components/ui/file-upload.jsx:55:68" data-dynamic-content="false" className="text-primary font-medium">browse</span></p>
        <input data-source-location="src/components/ui/file-upload.jsx:56:8" data-dynamic-content="true" ref={inputRef} type="file" multiple hidden onChange={(e) => handleFiles(e.target.files)}
        accept="image/*,application/pdf,video/*,audio/*,text/*" />
      </motion.div>

      <AnimatePresence data-source-location="src/components/ui/file-upload.jsx:60:6" data-dynamic-content="true">
        {files.length > 0 &&
        <div data-source-location="src/components/ui/file-upload.jsx:62:10" data-dynamic-content="true" className="mt-4 space-y-2">
            {files.map((file) =>
          <motion.div data-source-location="src/components/ui/file-upload.jsx:64:14" data-dynamic-content="true" key={file.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
          className="flex items-center gap-3 p-3 bg-white rounded-xl border border-border" data-collection-item-id={file?.id}>
                <FileIcon data-source-location="src/components/ui/file-upload.jsx:66:16" data-dynamic-content="false" className="w-8 h-8 text-primary flex-shrink-0" />
                <div data-source-location="src/components/ui/file-upload.jsx:67:16" data-dynamic-content="true" className="flex-1 min-w-0">
                  <p data-source-location="src/components/ui/file-upload.jsx:68:18" data-dynamic-content="true" className="text-sm font-medium truncate" data-collection-item-field="name" data-collection-item-id={file?.id}>{file.name}</p>
                  <div data-source-location="src/components/ui/file-upload.jsx:69:18" data-dynamic-content="true" className="flex items-center gap-2 mt-1">
                    <div data-source-location="src/components/ui/file-upload.jsx:70:20" data-dynamic-content="true" className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                      <motion.div data-source-location="src/components/ui/file-upload.jsx:71:22" data-dynamic-content="true" animate={{ width: `${file.progress}%` }} className={clsx("h-full rounded-full", file.progress < 100 ? "bg-primary" : "bg-emerald-500")} />
                    </div>
                    <span data-source-location="src/components/ui/file-upload.jsx:73:20" data-dynamic-content="true" className="text-xs text-muted-foreground">{formatSize(file.size)}</span>
                    {file.progress === 100 ?
                <Trash2 data-source-location="src/components/ui/file-upload.jsx:75:24" data-dynamic-content="true" className="w-4 h-4 text-muted-foreground hover:text-destructive cursor-pointer"
                onClick={() => setFiles((p) => p.filter((f) => f.id !== file.id))} /> :
                <Loader data-source-location="src/components/ui/file-upload.jsx:77:24" data-dynamic-content="false" className="w-4 h-4 text-primary animate-spin" />
                }
                  </div>
                </div>
              </motion.div>
          )}
          </div>
        }
      </AnimatePresence>
    </div>);

}