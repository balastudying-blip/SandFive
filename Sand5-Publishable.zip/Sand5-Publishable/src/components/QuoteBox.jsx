import { useState } from "react";
import { RefreshCw, Edit3, Check, X } from "lucide-react";
import { QUOTES } from "@/data/quotes";

export default function QuoteBox({ storageKey = "quoteBox", "data-collection-item-id": __dataCollectionItemId }) {
  const dayOfYear = Math.floor((new Date() - new Date(new Date().getFullYear(), 0, 0)) / 86400000);
  const saved = JSON.parse(sessionStorage.getItem(storageKey) || "{}");

  const [mode, setMode] = useState(saved.mode || "quote");
  const [quoteIndex, setQuoteIndex] = useState(saved.quoteIndex ?? dayOfYear % QUOTES.length);
  const [customMessage, setCustomMessage] = useState(saved.customMessage || "");
  const [editing, setEditing] = useState(false);
  const [editText, setEditText] = useState(customMessage);

  const persist = (data) => {
    sessionStorage.setItem(storageKey, JSON.stringify(data));
  };

  const handleNextQuote = () => {
    const nextIndex = (quoteIndex + 1) % QUOTES.length;
    setQuoteIndex(nextIndex);
    setMode("quote");
    persist({ mode: "quote", quoteIndex: nextIndex, customMessage });
  };

  const handleStartEdit = () => {
    setEditText(customMessage);
    setEditing(true);
  };

  const handleSaveEdit = () => {
    setCustomMessage(editText);
    setMode("custom");
    setEditing(false);
    persist({ mode: "custom", quoteIndex, customMessage: editText });
  };

  const handleCancelEdit = () => {
    setEditing(false);
  };

  const quote = QUOTES[quoteIndex];

  return (
    <div data-source-location="src/components/QuoteBox.jsx:45:4" data-dynamic-content="true" className="bg-card rounded-2xl border border-dashed border-border px-4 py-5" data-collection-item-id={__dataCollectionItemId}>
      {editing ?
      <div data-source-location="src/components/QuoteBox.jsx:47:8" data-dynamic-content="true">
          <textarea data-source-location="src/components/QuoteBox.jsx:48:10" data-dynamic-content="true"
        value={editText}
        onChange={(e) => setEditText(e.target.value.slice(0, 100))}
        placeholder="Type your reminder or message (max 100 chars)..."
        maxLength={100}
        rows={3}
        className="w-full px-3 py-2 border border-border rounded-lg text-sm resize-none focus:outline-none focus:ring-1 focus:ring-ring bg-background text-foreground" />
        
          <div data-source-location="src/components/QuoteBox.jsx:56:10" data-dynamic-content="true" className="flex items-center justify-between mt-2">
            <span data-source-location="src/components/QuoteBox.jsx:57:12" data-dynamic-content="true" className="text-xs text-muted-foreground">{editText.length}/100</span>
            <div data-source-location="src/components/QuoteBox.jsx:58:12" data-dynamic-content="true" className="flex gap-2">
              <button data-source-location="src/components/QuoteBox.jsx:59:14" data-dynamic-content="true" onClick={handleCancelEdit} className="p-1.5 rounded-lg text-muted-foreground hover:bg-muted transition-colors">
                <X data-source-location="src/components/QuoteBox.jsx:60:16" data-dynamic-content="false" className="w-3.5 h-3.5" />
              </button>
              <button data-source-location="src/components/QuoteBox.jsx:62:14" data-dynamic-content="true" onClick={handleSaveEdit} className="p-1.5 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition-colors">
                <Check data-source-location="src/components/QuoteBox.jsx:63:16" data-dynamic-content="false" className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div> :

      <>
          {mode === "quote" ?
        <>
              <p data-source-location="src/components/QuoteBox.jsx:72:14" data-dynamic-content="true" className="text-sm text-foreground italic leading-relaxed mb-2" data-collection-item-field="text" data-collection-item-id={quote?.id || quote?._id}>&ldquo;{quote.text}&rdquo;</p>
              <p data-source-location="src/components/QuoteBox.jsx:73:14" data-dynamic-content="true" className="text-xs text-muted-foreground font-medium mb-3" data-collection-item-field="author" data-collection-item-id={quote?.id || quote?._id}>&mdash; {quote.author}</p>
            </> :

        <p data-source-location="src/components/QuoteBox.jsx:76:12" data-dynamic-content="true" className="text-sm text-foreground leading-relaxed mb-3" data-collection-item-field="customMessage" data-collection-item-id={__dataCollectionItemId}>{customMessage}</p>
        }
          <div data-source-location="src/components/QuoteBox.jsx:78:10" data-dynamic-content="true" className="flex gap-2">
            <button data-source-location="src/components/QuoteBox.jsx:79:12" data-dynamic-content="true" onClick={handleNextQuote}
          className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-primary/10 text-primary text-xs font-medium hover:bg-primary/20 transition-colors">
              <RefreshCw data-source-location="src/components/QuoteBox.jsx:81:14" data-dynamic-content="false" className="w-3 h-3" /> Next Quote
            </button>
            <button data-source-location="src/components/QuoteBox.jsx:83:12" data-dynamic-content="true" onClick={handleStartEdit}
          className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-secondary text-secondary-foreground text-xs font-medium hover:bg-muted transition-colors">
              <Edit3 data-source-location="src/components/QuoteBox.jsx:85:14" data-dynamic-content="false" className="w-3 h-3" /> Custom
            </button>
          </div>
        </>
      }
    </div>);

}