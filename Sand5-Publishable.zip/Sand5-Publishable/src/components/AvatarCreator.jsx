import { useState, useEffect } from "react";
import { Shuffle } from "lucide-react";

const BG_COLORS = [
{ id: "blue", base: "#0d6bf6" },
{ id: "purple", base: "#7a5c9e" },
{ id: "teal", base: "#0ea5a5" },
{ id: "green", base: "#3a8a3a" },
{ id: "amber", base: "#d4a843" },
{ id: "coral", base: "#e87878" },
{ id: "slate", base: "#475569" },
{ id: "rose", base: "#c0456e" },
{ id: "indigo", base: "#4f46e5" },
{ id: "forest", base: "#16624a" },
{ id: "rust", base: "#b8420f" },
{ id: "graphite", base: "#1a1a1a" }];


const TEXT_COLORS = [
{ id: "white", base: "#ffffff" },
{ id: "cream", base: "#f3efe4" },
{ id: "dark", base: "#050505" }];


const SHAPES = ["circle", "rounded", "square"];

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

export default function AvatarCreator({ value, onChange, name = "", id }) {
  const [bg, setBg] = useState(value?.bg || BG_COLORS[0].id);
  const [text, setText] = useState(value?.text || "white");
  const [shape, setShape] = useState(value?.shape || "circle");

  const letter = (name?.trim()?.[0] || "U").toUpperCase();

  useEffect(() => {
    const bgColor = BG_COLORS.find((c) => c.id === bg)?.base || BG_COLORS[0].base;
    const textColor = TEXT_COLORS.find((c) => c.id === text)?.base || TEXT_COLORS[0].base;
    onChange({ type: "letter", letter, bg, bgColor, text, textColor, shape });
  }, [bg, text, shape, letter]);

  const handleShuffle = () => {
    setBg(pick(BG_COLORS).id);
    setText(pick(TEXT_COLORS).id);
    setShape(pick(SHAPES));
  };

  const bgColor = BG_COLORS.find((c) => c.id === bg)?.base;
  const textColor = TEXT_COLORS.find((c) => c.id === text)?.base;
  const radiusClass = shape === "circle" ? "rounded-full" : shape === "rounded" ? "rounded-2xl" : "rounded-lg";

  return (
    <div data-source-location="src/components/AvatarCreator.jsx:53:4" data-dynamic-content="true" className="max-w-md mx-auto bg-card border border-border rounded-3xl overflow-hidden text-foreground font-body shadow-lg">
      <div data-source-location="src/components/AvatarCreator.jsx:54:6" data-dynamic-content="false" className="pt-6 text-center">
        <h1 data-source-location="src/components/AvatarCreator.jsx:55:8" data-dynamic-content="false" className="text-xl font-bold font-heading">Pick your avatar</h1>
        <p data-source-location="src/components/AvatarCreator.jsx:56:8" data-dynamic-content="false" className="text-sm text-muted-foreground">A simple letter avatar based on your name.</p>
      </div>

      {/* Preview */}
      <div data-source-location="src/components/AvatarCreator.jsx:60:6" data-dynamic-content="true" className="flex justify-center py-6">
        <div data-source-location="src/components/AvatarCreator.jsx:61:8" data-dynamic-content="true"
        className={`flex items-center justify-center ${radiusClass} border-2 border-border shadow-md`}
        style={{ width: 140, height: 140, backgroundColor: bgColor, color: textColor }}>
          
          <span data-source-location="src/components/AvatarCreator.jsx:65:10" data-dynamic-content="true" className="font-heading font-bold" style={{ fontSize: 64 }} data-collection-item-field="letter" data-collection-item-id={id}>{letter}</span>
        </div>
      </div>

      <div data-source-location="src/components/AvatarCreator.jsx:69:6" data-dynamic-content="true" className="px-6 pb-6 space-y-5">
        {/* Background color */}
        <div data-source-location="src/components/AvatarCreator.jsx:71:8" data-dynamic-content="true">
          <h2 data-source-location="src/components/AvatarCreator.jsx:72:10" data-dynamic-content="false" className="text-sm font-bold mb-2">Background</h2>
          <div data-source-location="src/components/AvatarCreator.jsx:73:10" data-dynamic-content="true" className="flex flex-wrap gap-2">
            {BG_COLORS.map((c, __arrIdx__) =>
            <button data-source-location="src/components/AvatarCreator.jsx:75:14" data-dynamic-content="true" key={c.id} title={c.id}
            aria-pressed={bg === c.id}
            onClick={() => setBg(c.id)}
            className={`w-9 h-9 rounded-full border-2 transition-transform hover:-translate-y-0.5 ${bg === c.id ? "border-primary ring-2 ring-primary/30" : "border-border"}`}
            style={{ backgroundColor: c.base }} data-collection-item-id={c?.id} data-arr-index={__arrIdx__} data-arr-variable-name="BG_COLORS" />
            )}
          </div>
        </div>

        {/* Text color */}
        <div data-source-location="src/components/AvatarCreator.jsx:85:8" data-dynamic-content="true">
          <h2 data-source-location="src/components/AvatarCreator.jsx:86:10" data-dynamic-content="false" className="text-sm font-bold mb-2">Letter Color</h2>
          <div data-source-location="src/components/AvatarCreator.jsx:87:10" data-dynamic-content="true" className="flex gap-2">
            {TEXT_COLORS.map((c, __arrIdx__) =>
            <button data-source-location="src/components/AvatarCreator.jsx:89:14" data-dynamic-content="true" key={c.id} title={c.id}
            aria-pressed={text === c.id}
            onClick={() => setText(c.id)}
            className={`w-9 h-9 rounded-full border-2 transition-transform hover:-translate-y-0.5 ${text === c.id ? "border-primary ring-2 ring-primary/30" : "border-border"}`}
            style={{ backgroundColor: c.base }} data-collection-item-id={c?.id} data-arr-index={__arrIdx__} data-arr-variable-name="TEXT_COLORS" />
            )}
          </div>
        </div>

        {/* Shape */}
        <div data-source-location="src/components/AvatarCreator.jsx:99:8" data-dynamic-content="true">
          <h2 data-source-location="src/components/AvatarCreator.jsx:100:10" data-dynamic-content="false" className="text-sm font-bold mb-2">Shape</h2>
          <div data-source-location="src/components/AvatarCreator.jsx:101:10" data-dynamic-content="true" className="flex gap-2">
            {SHAPES.map((s, __arrIdx__) =>
            <button data-source-location="src/components/AvatarCreator.jsx:103:14" data-dynamic-content="true" key={s}
            aria-pressed={shape === s}
            onClick={() => setShape(s)}
            className={`px-4 py-2 rounded-lg border-2 text-sm font-semibold capitalize transition-colors ${shape === s ? "border-primary bg-accent text-accent-foreground" : "border-border text-muted-foreground hover:border-primary/50"}`} data-arr-index={__arrIdx__} data-arr-variable-name="SHAPES">
                {s}
              </button>
            )}
          </div>
        </div>

        <button data-source-location="src/components/AvatarCreator.jsx:113:8" data-dynamic-content="true" onClick={handleShuffle}
        className="w-full py-3 rounded-2xl bg-primary text-primary-foreground font-semibold flex items-center justify-center gap-2 hover:bg-primary/90 transition-colors">
          <Shuffle data-source-location="src/components/AvatarCreator.jsx:115:10" data-dynamic-content="false" className="w-4 h-4" /> Shuffle
        </button>
      </div>
    </div>);

}