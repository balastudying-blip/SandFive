import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { Shield, MessageCircle, Check, PhoneOff } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function AdminNotifications({ userName }) {
  const navigate = useNavigate();
  const location = useLocation();
  const [adminMsgs, setAdminMsgs] = useState([]);
  const [adminCalls, setAdminCalls] = useState([]);

  useEffect(() => {
    if (!userName || userName === "Student" || userName === "Tutor") return;
    const load = async () => {
      try {
        const [msgs, callsAsStudent, callsAsTutor] = await Promise.all([
        base44.entities.Message.filter({ recipient_name: userName, is_admin: true }, "-created_date", 20),
        base44.entities.Call.filter({ student_name: userName, is_admin: true }),
        base44.entities.Call.filter({ tutor_name: userName, is_admin: true })]
        );
        const seen = JSON.parse(sessionStorage.getItem("seenAdminMsgs") || "[]");
        setAdminMsgs(msgs.filter((m) => !seen.includes(m.id)));
        const calling = [...callsAsStudent, ...callsAsTutor].filter((c) => c.status === "calling");
        setAdminCalls(calling);
      } catch (e) {}
    };
    load();
    let unsubMsg, unsubCall;
    try {
      unsubMsg = base44.entities.Message.subscribe((ev) => {
        if (ev.data?.is_admin && ev.data.recipient_name === userName) load();
      });
    } catch (e) {}
    try {
      unsubCall = base44.entities.Call.subscribe((ev) => {
        if (ev.data?.is_admin && (ev.data.student_name === userName || ev.data.tutor_name === userName)) load();
      });
    } catch (e) {}
    return () => {
      if (typeof unsubMsg === "function") unsubMsg();
      if (typeof unsubCall === "function") unsubCall();
    };
  }, [userName]);

  const viewMsg = (m) => {
    const seen = JSON.parse(sessionStorage.getItem("seenAdminMsgs") || "[]");
    sessionStorage.setItem("seenAdminMsgs", JSON.stringify([...seen, m.id]));
    setAdminMsgs((prev) => prev.filter((x) => x.id !== m.id));
    navigate(`/chat?name=${encodeURIComponent(m.sender_name)}&back=${location.pathname}`);
  };

  const acceptCall = async (c) => {
    try {await base44.entities.Call.update(c.id, { status: "accepted" });} catch (e) {}
    setAdminCalls((prev) => prev.filter((x) => x.id !== c.id));
    window.open(c.meeting_link || "https://meet.jit.si/s5-tutoring", "_blank");
  };

  const declineCall = async (c) => {
    try {await base44.entities.Call.update(c.id, { status: "declined" });} catch (e) {}
    setAdminCalls((prev) => prev.filter((x) => x.id !== c.id));
  };

  if (adminMsgs.length === 0 && adminCalls.length === 0) return null;

  const callerName = (c) => c.student_name === userName ? c.tutor_name : c.student_name;

  return (
    <div data-source-location="src/components/AdminNotifications.jsx:69:4" data-dynamic-content="true" className="space-y-2">
      {adminCalls.map((c) =>
      <motion.div data-source-location="src/components/AdminNotifications.jsx:71:8" data-dynamic-content="true" key={c.id} initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
      className="bg-amber-500 text-white rounded-2xl p-4 flex items-center justify-between" data-collection-item-id={c?.id}>
          <div data-source-location="src/components/AdminNotifications.jsx:73:10" data-dynamic-content="true" className="flex items-center gap-3 min-w-0">
            <div data-source-location="src/components/AdminNotifications.jsx:74:12" data-dynamic-content="false" className="relative flex-shrink-0">
              <div data-source-location="src/components/AdminNotifications.jsx:75:14" data-dynamic-content="false" className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <Shield data-source-location="src/components/AdminNotifications.jsx:76:16" data-dynamic-content="false" className="w-5 h-5" />
              </div>
              <span data-source-location="src/components/AdminNotifications.jsx:78:14" data-dynamic-content="false" className="absolute inset-0 rounded-full animate-ping bg-white/30" />
            </div>
            <div data-source-location="src/components/AdminNotifications.jsx:80:12" data-dynamic-content="true" className="min-w-0">
              <p data-source-location="src/components/AdminNotifications.jsx:81:14" data-dynamic-content="true" className="font-semibold text-sm flex items-center gap-1.5"><Shield data-source-location="src/components/AdminNotifications.jsx:81:77" data-dynamic-content="false" className="w-3.5 h-3.5 flex-shrink-0" /> Admin · {callerName(c)} is calling you</p>
              <p data-source-location="src/components/AdminNotifications.jsx:82:14" data-dynamic-content="false" className="text-xs opacity-90">Incoming call from an S&5 admin</p>
            </div>
          </div>
          <div data-source-location="src/components/AdminNotifications.jsx:85:10" data-dynamic-content="true" className="flex gap-2 flex-shrink-0">
            <button data-source-location="src/components/AdminNotifications.jsx:86:12" data-dynamic-content="true" onClick={() => acceptCall(c)}
          className="px-3 py-1.5 rounded-lg bg-green-600 text-white text-xs font-semibold hover:bg-green-700 transition-colors flex items-center gap-1">
              <Check data-source-location="src/components/AdminNotifications.jsx:88:14" data-dynamic-content="false" className="w-3.5 h-3.5" /> Accept
            </button>
            <button data-source-location="src/components/AdminNotifications.jsx:90:12" data-dynamic-content="true" onClick={() => declineCall(c)}
          className="px-3 py-1.5 rounded-lg bg-white/25 text-white text-xs font-semibold hover:bg-white/30 transition-colors flex items-center gap-1">
              <PhoneOff data-source-location="src/components/AdminNotifications.jsx:92:14" data-dynamic-content="false" className="w-3.5 h-3.5" /> Decline
            </button>
          </div>
        </motion.div>
      )}
      {adminMsgs.map((m) =>
      <motion.div data-source-location="src/components/AdminNotifications.jsx:98:8" data-dynamic-content="true" key={m.id} initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
      className="bg-amber-500/90 text-white rounded-2xl p-4 flex items-center justify-between" data-collection-item-id={m?.id}>
          <div data-source-location="src/components/AdminNotifications.jsx:100:10" data-dynamic-content="true" className="flex items-center gap-3 min-w-0">
            <div data-source-location="src/components/AdminNotifications.jsx:101:12" data-dynamic-content="false" className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
              <Shield data-source-location="src/components/AdminNotifications.jsx:102:14" data-dynamic-content="false" className="w-5 h-5" />
            </div>
            <div data-source-location="src/components/AdminNotifications.jsx:104:12" data-dynamic-content="true" className="min-w-0">
              <p data-source-location="src/components/AdminNotifications.jsx:105:14" data-dynamic-content="true" className="font-semibold text-sm flex items-center gap-1.5" data-collection-item-field="sender_name" data-collection-item-id={m?.id}><Shield data-source-location="src/components/AdminNotifications.jsx:105:77" data-dynamic-content="false" className="w-3.5 h-3.5 flex-shrink-0" /> Admin · {m.sender_name}</p>
              <p data-source-location="src/components/AdminNotifications.jsx:106:14" data-dynamic-content="true" className="text-xs opacity-90 truncate" data-collection-item-field="content" data-collection-item-id={m?.id}>{m.content}</p>
            </div>
          </div>
          <button data-source-location="src/components/AdminNotifications.jsx:109:10" data-dynamic-content="true" onClick={() => viewMsg(m)}
        className="ml-3 px-3 py-1.5 rounded-lg bg-white text-amber-600 text-xs font-semibold hover:bg-white/90 transition-colors flex items-center gap-1 flex-shrink-0">
            <MessageCircle data-source-location="src/components/AdminNotifications.jsx:111:12" data-dynamic-content="false" className="w-3.5 h-3.5" /> View
          </button>
        </motion.div>
      )}
    </div>);

}