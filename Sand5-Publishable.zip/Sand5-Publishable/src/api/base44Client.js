import { createClient } from "/node_modules/.vite/deps/@base44_sdk.js?v=bcb1bd5c";
import { appParams } from "/src/lib/app-params.js";

const { appId, token, functionsVersion, appBaseUrl } = appParams;

//Create a client with authentication required
export const base44 = createClient({
  appId,
  token,
  functionsVersion,
  serverUrl: '',
  requiresAuth: false,
  appBaseUrl
});