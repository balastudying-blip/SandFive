import { Link } from "react-router-dom";
import Logo from "@/components/Logo";

const CSS = `
.pp-page { min-height: 100vh; background: var(--background); color: var(--foreground); font-family: var(--font-body); padding: 120px 0 60px; }
.pp-page .wrap { max-width: 760px; margin: 0 auto; padding: 0 24px; }
.pp-page h1 { font-size: clamp(2rem, 5vw, 3rem); font-weight: 700; margin-bottom: 8px; }
.pp-page .updated { color: var(--muted-foreground); font-style: italic; font-size: 0.9rem; margin-bottom: 40px; }
.pp-page h2 { font-size: 1.3rem; font-weight: 600; margin: 36px 0 12px; }
.pp-page p, .pp-page li { color: var(--muted-foreground); font-size: 1rem; line-height: 1.7; margin-bottom: 12px; }
.pp-page ul { padding-left: 20px; margin-bottom: 16px; }
.pp-page a { color: var(--primary); text-decoration: underline; }
.pp-page .pp-header { display: flex; align-items: center; gap: 12px; margin-bottom: 32px; }
.pp-page .pp-back { display: inline-flex; align-items: center; gap: 6px; color: var(--muted-foreground); font-style: italic; font-size: 0.95rem; margin-bottom: 32px; transition: color 0.3s; }
.pp-page .pp-back:hover { color: var(--foreground); }
`;

export default function PrivacyPolicy() {
  return (
    <div data-source-location="src/pages/PrivacyPolicy.jsx:20:4" data-dynamic-content="true" className="pp-page relative z-10">
      <style data-source-location="src/pages/PrivacyPolicy.jsx:21:6" data-dynamic-content="true" data-collection-item-field="CSS">{CSS}</style>
      <div data-source-location="src/pages/PrivacyPolicy.jsx:22:6" data-dynamic-content="false" className="wrap">
        <div data-source-location="src/pages/PrivacyPolicy.jsx:23:8" data-dynamic-content="false" className="pp-header">
          <Logo data-source-location="src/pages/PrivacyPolicy.jsx:24:10" data-dynamic-content="false" height={36} blend />
        </div>
        <Link data-source-location="src/pages/PrivacyPolicy.jsx:26:8" data-dynamic-content="false" to="/" className="pp-back">← Back to Home</Link>
        <h1 data-source-location="src/pages/PrivacyPolicy.jsx:27:8" data-dynamic-content="false">Privacy Policy</h1>
        <p data-source-location="src/pages/PrivacyPolicy.jsx:28:8" data-dynamic-content="false" className="updated">Last updated: September 7, 2026</p>

        <p data-source-location="src/pages/PrivacyPolicy.jsx:30:8" data-dynamic-content="false">S&amp;5 ("we", "us", or "our") operates the peer tutoring platform at sand5.base44.app. This Privacy Policy explains how we collect, use, and protect your information when you use our platform.</p>

        <h2 data-source-location="src/pages/PrivacyPolicy.jsx:32:8" data-dynamic-content="false">Information We Collect</h2>
        <ul data-source-location="src/pages/PrivacyPolicy.jsx:33:8" data-dynamic-content="false">
          <li data-source-location="src/pages/PrivacyPolicy.jsx:34:10" data-dynamic-content="false"><strong data-source-location="src/pages/PrivacyPolicy.jsx:34:14" data-dynamic-content="false">Account information:</strong> Your name, email address, and role (student or tutor) when you register.</li>
          <li data-source-location="src/pages/PrivacyPolicy.jsx:35:10" data-dynamic-content="false"><strong data-source-location="src/pages/PrivacyPolicy.jsx:35:14" data-dynamic-content="false">Profile information:</strong> Grade level, subjects, interests, bio, learning/teaching style, and pricing details you provide during onboarding.</li>
          <li data-source-location="src/pages/PrivacyPolicy.jsx:36:10" data-dynamic-content="false"><strong data-source-location="src/pages/PrivacyPolicy.jsx:36:14" data-dynamic-content="false">Usage data:</strong> Connections, messages, homework assignments, payments, calls, and reviews you create on the platform.</li>
          <li data-source-location="src/pages/PrivacyPolicy.jsx:37:10" data-dynamic-content="false"><strong data-source-location="src/pages/PrivacyPolicy.jsx:37:14" data-dynamic-content="false">Authentication data:</strong> When you sign in with Google, we receive your basic Google profile information.</li>
        </ul>

        <h2 data-source-location="src/pages/PrivacyPolicy.jsx:40:8" data-dynamic-content="false">How We Use Your Information</h2>
        <ul data-source-location="src/pages/PrivacyPolicy.jsx:41:8" data-dynamic-content="false">
          <li data-source-location="src/pages/PrivacyPolicy.jsx:42:10" data-dynamic-content="false">To create and manage your account and profile.</li>
          <li data-source-location="src/pages/PrivacyPolicy.jsx:43:10" data-dynamic-content="false">To match students with tutors based on grade, subjects, and learning style.</li>
          <li data-source-location="src/pages/PrivacyPolicy.jsx:44:10" data-dynamic-content="false">To facilitate messaging, video calls, homework assignments, and payments between users.</li>
          <li data-source-location="src/pages/PrivacyPolicy.jsx:45:10" data-dynamic-content="false">To send service-related notifications and updates.</li>
          <li data-source-location="src/pages/PrivacyPolicy.jsx:46:10" data-dynamic-content="false">To improve our platform features and user experience.</li>
        </ul>

        <h2 data-source-location="src/pages/PrivacyPolicy.jsx:49:8" data-dynamic-content="false">Information Sharing</h2>
        <p data-source-location="src/pages/PrivacyPolicy.jsx:50:8" data-dynamic-content="false">We do not sell your personal information. Profile information (name, subjects, bio, pricing) is visible to other users for matching purposes. Payment details are only visible to the payer and payee involved in a transaction. Administrators may access user data for platform management and support.</p>

        <h2 data-source-location="src/pages/PrivacyPolicy.jsx:52:8" data-dynamic-content="false">Data Security</h2>
        <p data-source-location="src/pages/PrivacyPolicy.jsx:53:8" data-dynamic-content="false">We use Row-Level Security to ensure users can only access their own data and data shared through connections. Payment records are restricted to the parties involved. We use secure authentication and encrypted data storage through our platform provider.</p>

        <h2 data-source-location="src/pages/PrivacyPolicy.jsx:55:8" data-dynamic-content="false">Cookies and Local Storage</h2>
        <p data-source-location="src/pages/PrivacyPolicy.jsx:56:8" data-dynamic-content="false">We use local storage to maintain your session, remember preferences, and cache profile data for faster loading. We do not use tracking cookies for advertising.</p>

        <h2 data-source-location="src/pages/PrivacyPolicy.jsx:58:8" data-dynamic-content="false">Your Rights</h2>
        <ul data-source-location="src/pages/PrivacyPolicy.jsx:59:8" data-dynamic-content="false">
          <li data-source-location="src/pages/PrivacyPolicy.jsx:60:10" data-dynamic-content="false"><strong data-source-location="src/pages/PrivacyPolicy.jsx:60:14" data-dynamic-content="false">Access:</strong> You can view your profile and activity data through your dashboard.</li>
          <li data-source-location="src/pages/PrivacyPolicy.jsx:61:10" data-dynamic-content="false"><strong data-source-location="src/pages/PrivacyPolicy.jsx:61:14" data-dynamic-content="false">Update:</strong> You can edit your profile information at any time.</li>
          <li data-source-location="src/pages/PrivacyPolicy.jsx:62:10" data-dynamic-content="false"><strong data-source-location="src/pages/PrivacyPolicy.jsx:62:14" data-dynamic-content="false">Delete:</strong> You can request account deletion by contacting us.</li>
        </ul>

        <h2 data-source-location="src/pages/PrivacyPolicy.jsx:65:8" data-dynamic-content="false">Third-Party Services</h2>
        <p data-source-location="src/pages/PrivacyPolicy.jsx:66:8" data-dynamic-content="false">We use Google for authentication and Jitsi for video calls. These services have their own privacy policies. We do not share your data with third parties beyond what is necessary to operate these features.</p>

        <h2 data-source-location="src/pages/PrivacyPolicy.jsx:68:8" data-dynamic-content="false">Children's Privacy</h2>
        <p data-source-location="src/pages/PrivacyPolicy.jsx:69:8" data-dynamic-content="false">Our platform is designed for students of all grade levels, including Pre-K through college. Parents or guardians should supervise minors using the platform and review their profile information.</p>

        <h2 data-source-location="src/pages/PrivacyPolicy.jsx:71:8" data-dynamic-content="false">Changes to This Policy</h2>
        <p data-source-location="src/pages/PrivacyPolicy.jsx:72:8" data-dynamic-content="false">We may update this Privacy Policy from time to time. We will update the "Last updated" date at the top of this page when we make changes.</p>

        <h2 data-source-location="src/pages/PrivacyPolicy.jsx:74:8" data-dynamic-content="false">Contact Us</h2>
        <p data-source-location="src/pages/PrivacyPolicy.jsx:75:8" data-dynamic-content="false">If you have questions about this Privacy Policy, please <Link data-source-location="src/pages/PrivacyPolicy.jsx:75:67" data-dynamic-content="false" to="/contact">contact us</Link> through our contact page.</p>
      </div>
    </div>);

}