import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Trash2, MessageCircle, Video, Users, GraduationCap } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { loadAcceptedConnections, generateMeetLink } from "@/lib/loadConnections";

export default function Admin() {
  const navigate = useNavigate();
  const [adminName, setAdminName] = useState("");
  const [tutors, setTutors] = useState([]);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [connections, setConnections] = useState({});

  useEffect(() => {
    const init = async () => {
      try {
        const me = await base44.auth.me();
        if (me.role !== "admin") {navigate("/get-started");return;}
        setAdminName(me.full_name || "Admin");
        loadAll();
      } catch (e) {navigate("/get-started");}
    };
    init();
  }, []);

  const loadAll = async () => {
    setLoading(true);
    try {
      const profiles = await base44.entities.Profile.list("-created_date", 500);
      const t = profiles.filter((p) => p.role === "tutor");
      const s = profiles.filter((p) => p.role === "student");
      setTutors(t);
      setStudents(s);
      const connMap = {};
      await Promise.all([...t, ...s].map(async (p) => {
        connMap[p.full_name] = await loadAcceptedConnections(p.full_name);
      }));
      setConnections(connMap);
    } catch (e) {}
    setLoading(false);
  };

  const handleRemove = async (p) => {
    if (!window.confirm(`Remove ${p.full_name}? This deletes their profile.`)) return;
    try {await base44.entities.Profile.delete(p.id);await loadAll();} catch (e) {}
  };

  const handleMessage = (p) => {
    navigate(`/chat?name=${encodeURIComponent(p.full_name)}&back=/admin`);
  };

  const handleCall = async (p) => {
    const link = generateMeetLink();
    const isTutor = p.role === "tutor";
    try {
      await base44.entities.Call.create({
        tutor_name: isTutor ? p.full_name : adminName,
        student_name: isTutor ? adminName : p.full_name,
        status: "calling",
        meeting_link: link,
        is_admin: true
      });
    } catch (e) {}
    window.open(link, "_blank");
  };

  const PersonCard = ({ p }) =>
  <div data-source-location="src/pages/Admin.jsx:69:4" data-dynamic-content="true" className="bg-card border border-border rounded-2xl p-4">
      <div data-source-location="src/pages/Admin.jsx:70:6" data-dynamic-content="true" className="flex items-start justify-between gap-3 mb-2">
        <div data-source-location="src/pages/Admin.jsx:71:8" data-dynamic-content="true" className="flex-1 min-w-0" data-collection-item-field="email" data-collection-item-id={p?.id || p?._id}>
          <p data-source-location="src/pages/Admin.jsx:72:10" data-dynamic-content="true" className="font-semibold text-foreground" data-collection-item-field="full_name" data-collection-item-id={p?.id || p?._id}>{p.full_name}</p>
          {p.email && <p data-source-location="src/pages/Admin.jsx:73:22" data-dynamic-content="true" className="text-xs text-muted-foreground" data-collection-item-field="email" data-collection-item-id={p?.id || p?._id}>{p.email}</p>}
          {p.grade && <p data-source-location="src/pages/Admin.jsx:74:22" data-dynamic-content="true" className="text-xs text-muted-foreground" data-collection-item-field="grade" data-collection-item-id={p?.id || p?._id}>{p.grade} Grade</p>}
          {p.role === "tutor" && p.pricing && !p.pricing.flexible && p.pricing.price &&
        <p data-source-location="src/pages/Admin.jsx:76:12" data-dynamic-content="true" className="text-xs text-green-600 font-semibold" data-collection-item-field="pricing.price" data-collection-item-id={p?.id || p?._id}>${p.pricing.price}/hr</p>
        }
          {p.role === "tutor" && p.tutor_grade?.length > 0 &&
        <p data-source-location="src/pages/Admin.jsx:79:12" data-dynamic-content="true" className="text-xs text-muted-foreground" data-collection-item-field="tutor_grade" data-collection-item-id={p?.id || p?._id}>Teaches {p.tutor_grade.join(", ")}</p>
        }
          {p.subjects?.length > 0 &&
        <div data-source-location="src/pages/Admin.jsx:82:12" data-dynamic-content="true" className="flex flex-wrap gap-1 mt-1" data-collection-id="p">
              {p.subjects.slice(0, 4).map((s) => <span data-source-location="src/pages/Admin.jsx:83:47" data-dynamic-content="true" key={s} className="px-1.5 py-0.5 bg-secondary text-secondary-foreground text-[10px] rounded" data-collection-item-field="s">{s}</span>)}
            </div>
        }
          {connections[p.full_name]?.length > 0 &&
        <p data-source-location="src/pages/Admin.jsx:87:12" data-dynamic-content="true" className="text-xs text-muted-foreground mt-2">
              {p.role === "tutor" ? "Students" : "Tutors"}: {connections[p.full_name].map((c) => c.name).join(", ")}
            </p>
        }
        </div>
        <span data-source-location="src/pages/Admin.jsx:92:8" data-dynamic-content="true" className="px-2 py-0.5 rounded text-[10px] font-medium bg-primary/10 text-primary" data-collection-item-field="role" data-collection-item-id={p?.id || p?._id}>{p.role}</span>
      </div>
      <div data-source-location="src/pages/Admin.jsx:94:6" data-dynamic-content="true" className="flex gap-2 mt-3">
        <button data-source-location="src/pages/Admin.jsx:95:8" data-dynamic-content="true" onClick={() => handleCall(p)}
      className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-green-50 text-green-700 border border-green-200 text-xs font-semibold hover:bg-green-100 transition-colors">
          <Video data-source-location="src/pages/Admin.jsx:97:10" data-dynamic-content="false" className="w-3.5 h-3.5" /> Call
        </button>
        <button data-source-location="src/pages/Admin.jsx:99:8" data-dynamic-content="true" onClick={() => handleMessage(p)}
      className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-primary/10 text-primary border border-primary/20 text-xs font-semibold hover:bg-primary/20 transition-colors">
          <MessageCircle data-source-location="src/pages/Admin.jsx:101:10" data-dynamic-content="false" className="w-3.5 h-3.5" /> Message
        </button>
        <button data-source-location="src/pages/Admin.jsx:103:8" data-dynamic-content="true" onClick={() => handleRemove(p)}
      className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-destructive/10 text-destructive border border-destructive/20 text-xs font-semibold hover:bg-destructive/20 transition-colors">
          <Trash2 data-source-location="src/pages/Admin.jsx:105:10" data-dynamic-content="false" className="w-3.5 h-3.5" /> Remove
        </button>
      </div>
    </div>;


  return (
    <div data-source-location="src/pages/Admin.jsx:112:4" data-dynamic-content="true" className="min-h-screen font-body relative z-10">
      <nav data-source-location="src/pages/Admin.jsx:113:6" data-dynamic-content="true" className="bg-card/80 backdrop-blur-md border-b border-border px-6 py-4 flex items-center gap-4">
        <Link data-source-location="src/pages/Admin.jsx:114:8" data-dynamic-content="false" to="/get-started" className="text-muted-foreground hover:text-foreground"><ArrowLeft data-source-location="src/pages/Admin.jsx:114:88" data-dynamic-content="false" className="w-5 h-5" /></Link>
        <div data-source-location="src/pages/Admin.jsx:115:8" data-dynamic-content="true">
          <h1 data-source-location="src/pages/Admin.jsx:116:10" data-dynamic-content="true" className="font-heading font-bold text-foreground text-lg" data-collection-item-field="adminName">Admin · {adminName}</h1>
          <p data-source-location="src/pages/Admin.jsx:117:10" data-dynamic-content="false" className="text-xs text-muted-foreground">Master control</p>
        </div>
        <button data-source-location="src/pages/Admin.jsx:119:8" data-dynamic-content="true" onClick={() => base44.auth.logout("/get-started")}
        className="ml-auto text-xs text-muted-foreground hover:text-foreground">Sign out</button>
      </nav>

      <div data-source-location="src/pages/Admin.jsx:123:6" data-dynamic-content="true" className="max-w-5xl mx-auto px-6 py-8">
        {loading ? <p data-source-location="src/pages/Admin.jsx:124:19" data-dynamic-content="false" className="text-muted-foreground text-center py-12">Loading everyone...</p> :
        <div data-source-location="src/pages/Admin.jsx:125:10" data-dynamic-content="true" className="space-y-8">
            <div data-source-location="src/pages/Admin.jsx:126:12" data-dynamic-content="true">
              <h2 data-source-location="src/pages/Admin.jsx:127:14" data-dynamic-content="true" className="font-heading font-bold text-foreground text-lg mb-3 flex items-center gap-2"><GraduationCap data-source-location="src/pages/Admin.jsx:127:106" data-dynamic-content="false" className="w-5 h-5 text-primary" /> Tutors ({tutors.length})</h2>
              <div data-source-location="src/pages/Admin.jsx:128:14" data-dynamic-content="true" className="grid md:grid-cols-2 gap-3" data-collection-id="Profile">
                {tutors.length === 0 ? <p data-source-location="src/pages/Admin.jsx:129:39" data-dynamic-content="false" className="text-muted-foreground text-sm">No tutors.</p> : tutors.map((p) => <PersonCard data-source-location="src/pages/Admin.jsx:129:117" data-dynamic-content="true" key={p.id} p={p} data-collection-item-id={p?.id} />)}
              </div>
            </div>
            <div data-source-location="src/pages/Admin.jsx:132:12" data-dynamic-content="true">
              <h2 data-source-location="src/pages/Admin.jsx:133:14" data-dynamic-content="true" className="font-heading font-bold text-foreground text-lg mb-3 flex items-center gap-2"><Users data-source-location="src/pages/Admin.jsx:133:106" data-dynamic-content="false" className="w-5 h-5 text-primary" /> Students ({students.length})</h2>
              <div data-source-location="src/pages/Admin.jsx:134:14" data-dynamic-content="true" className="grid md:grid-cols-2 gap-3" data-collection-id="Profile">
                {students.length === 0 ? <p data-source-location="src/pages/Admin.jsx:135:41" data-dynamic-content="false" className="text-muted-foreground text-sm">No students.</p> : students.map((p) => <PersonCard data-source-location="src/pages/Admin.jsx:135:123" data-dynamic-content="true" key={p.id} p={p} data-collection-item-id={p?.id} />)}
              </div>
            </div>
          </div>
        }
      </div>
    </div>);

}