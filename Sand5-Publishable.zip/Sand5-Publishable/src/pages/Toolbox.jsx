import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Upload, Plus, Lock, Globe, FileDown, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { base44 } from "@/api/base44Client";

export default function Toolbox() {
  const [tab, setTab] = useState("all");
  const [allTools, setAllTools] = useState([]);
  const [myTools, setMyTools] = useState([]);
  const [loading, setLoading] = useState(true);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [isPublic, setIsPublic] = useState(false);
  const [file, setFile] = useState(null);
  const [fileUrl, setFileUrl] = useState("");
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const fileRef = useRef(null);
  const myName = JSON.parse(sessionStorage.getItem("onboardingData") || "{}").name || "Tutor";

  const load = async () => {
    setLoading(true);
    try {
      const pub = await base44.entities.Tool.filter({ is_public: true }, "-created_date", 100);
      setAllTools(pub);
      const mine = await base44.entities.Tool.filter({ owner_name: myName }, "-created_date", 100);
      setMyTools(mine);
    } catch (e) {}
    setLoading(false);
  };

  useEffect(() => {load();}, [myName]);

  const handleFileChange = async (e) => {
    const selected = e.target.files?.[0];
    if (!selected) return;
    setFile(selected);
    setUploading(true);
    setError("");
    try {
      const res = await base44.integrations.Core.UploadFile({ file: selected });
      setFileUrl(res.file_url);
    } catch (err) {
      setError("File upload failed.");
    }
    setUploading(false);
  };

  const wordCount = (description || "").trim().split(/\s+/).filter(Boolean).length;

  const handleCreate = async () => {
    setError("");
    if (!title.trim()) {setError("Please give the tool a title.");return;}
    if (!fileUrl) {setError("Please upload a file.");return;}
    if (wordCount < 25) {setError(`Description must be at least 25 words (currently ${wordCount}).`);return;}
    setSaving(true);
    try {
      await base44.entities.Tool.create({
        title: title.trim(),
        description: description.trim(),
        file_url: fileUrl,
        file_name: file?.name || "",
        owner_name: myName,
        is_public: isPublic
      });
      setTitle("");setDescription("");setFile(null);setFileUrl("");setIsPublic(false);
      setTab("my");
      await load();
    } catch (err) {
      setError("Failed to save tool.");
    }
    setSaving(false);
  };

  const handleDelete = async (id) => {
    try {await base44.entities.Tool.delete(id);await load();} catch (e) {}
  };

  const ToolCard = ({ t, showOwner, "data-collection-item-id": __dataCollectionItemId }) =>
  <div data-source-location="src/pages/Toolbox.jsx:83:4" data-dynamic-content="true" className="bg-card border border-border rounded-2xl p-4" data-collection-item-id={__dataCollectionItemId}>
      <div data-source-location="src/pages/Toolbox.jsx:84:6" data-dynamic-content="true" className="flex items-start justify-between gap-3 mb-2">
        <div data-source-location="src/pages/Toolbox.jsx:85:8" data-dynamic-content="true" className="flex-1 min-w-0">
          <p data-source-location="src/pages/Toolbox.jsx:86:10" data-dynamic-content="true" className="font-semibold text-foreground" data-collection-item-field="title" data-collection-item-id={t?.id || t?._id}>{t.title}</p>
          {showOwner && <p data-source-location="src/pages/Toolbox.jsx:87:24" data-dynamic-content="true" className="text-xs text-muted-foreground" data-collection-item-field="owner_name" data-collection-item-id={t?.id || t?._id}>By {t.owner_name}</p>}
        </div>
        <span data-source-location="src/pages/Toolbox.jsx:89:8" data-dynamic-content="true" className={`px-2 py-0.5 rounded text-[10px] font-medium ${t.is_public ? "bg-primary/10 text-primary" : "bg-secondary text-secondary-foreground"}`}>
          {t.is_public ? <span data-source-location="src/pages/Toolbox.jsx:90:25" data-dynamic-content="false" className="flex items-center gap-1"><Globe data-source-location="src/pages/Toolbox.jsx:90:67" data-dynamic-content="false" className="w-3 h-3" /> Public</span> : <span data-source-location="src/pages/Toolbox.jsx:90:113" data-dynamic-content="false" className="flex items-center gap-1"><Lock data-source-location="src/pages/Toolbox.jsx:90:155" data-dynamic-content="false" className="w-3 h-3" /> Private</span>}
        </span>
      </div>
      <p data-source-location="src/pages/Toolbox.jsx:93:6" data-dynamic-content="true" className="text-sm text-muted-foreground mb-3 whitespace-pre-wrap" data-collection-item-field="description" data-collection-item-id={t?.id || t?._id}>{t.description}</p>
      <div data-source-location="src/pages/Toolbox.jsx:94:6" data-dynamic-content="true" className="flex items-center gap-2" data-collection-item-field="file_url" data-collection-item-id={t?.id || t?._id}>
        {t.file_url &&
      <a data-source-location="src/pages/Toolbox.jsx:96:10" data-dynamic-content="true" href={t.file_url} target="_blank" rel="noopener noreferrer"
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary/10 text-primary border border-primary/20 text-xs font-semibold hover:bg-primary/20 transition-colors">
            <FileDown data-source-location="src/pages/Toolbox.jsx:98:12" data-dynamic-content="false" className="w-3.5 h-3.5" /> {t.file_name || "Download"}
          </a>
      }
        {t.owner_name === myName &&
      <button data-source-location="src/pages/Toolbox.jsx:102:10" data-dynamic-content="true" onClick={() => handleDelete(t.id)}
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-destructive/10 text-destructive border border-destructive/20 text-xs font-semibold hover:bg-destructive/20 transition-colors">
            <Trash2 data-source-location="src/pages/Toolbox.jsx:104:12" data-dynamic-content="false" className="w-3.5 h-3.5" /> Delete
          </button>
      }
      </div>
    </div>;


  return (
    <div data-source-location="src/pages/Toolbox.jsx:112:4" data-dynamic-content="true" className="min-h-screen font-body relative z-10">
      <nav data-source-location="src/pages/Toolbox.jsx:113:6" data-dynamic-content="false" className="bg-card/80 backdrop-blur-md border-b border-border px-6 py-4 flex items-center gap-4">
        <Link data-source-location="src/pages/Toolbox.jsx:114:8" data-dynamic-content="false" to="/tutor-dashboard" className="text-muted-foreground hover:text-foreground"><ArrowLeft data-source-location="src/pages/Toolbox.jsx:114:92" data-dynamic-content="false" className="w-5 h-5" /></Link>
        <h1 data-source-location="src/pages/Toolbox.jsx:115:8" data-dynamic-content="false" className="font-heading font-bold text-foreground text-lg">Toolbox</h1>
      </nav>

      <div data-source-location="src/pages/Toolbox.jsx:118:6" data-dynamic-content="true" className="max-w-3xl mx-auto px-6 py-8">
        <div data-source-location="src/pages/Toolbox.jsx:119:8" data-dynamic-content="true" className="flex gap-2 mb-6 bg-muted/50 p-1 rounded-xl">
          {[
          { key: "all", label: "All Tools" },
          { key: "my", label: "My Tools" },
          { key: "create", label: "Create Tool" }].
          map((t, __arrIdx__) =>
          <button data-source-location="src/pages/Toolbox.jsx:125:12" data-dynamic-content="true" key={t.key} onClick={() => setTab(t.key)}
          className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-colors ${tab === t.key ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`} data-arr-index={__arrIdx__} data-arr-field="label">
              {t.label}
            </button>
          )}
        </div>

        {tab === "all" &&
        <div data-source-location="src/pages/Toolbox.jsx:133:10" data-dynamic-content="true" className="space-y-3" data-collection-id="Tool">
            {loading ? <p data-source-location="src/pages/Toolbox.jsx:134:23" data-dynamic-content="false" className="text-muted-foreground text-sm text-center py-8">Loading...</p> :
          allTools.length === 0 ? <p data-source-location="src/pages/Toolbox.jsx:135:37" data-dynamic-content="false" className="text-muted-foreground text-sm text-center py-8">No public tools yet.</p> :
          allTools.map((t) => <ToolCard data-source-location="src/pages/Toolbox.jsx:136:31" data-dynamic-content="true" key={t.id} t={t} showOwner data-collection-item-id={t?.id} />)}
          </div>
        }

        {tab === "my" &&
        <div data-source-location="src/pages/Toolbox.jsx:141:10" data-dynamic-content="true" className="space-y-3" data-collection-id="Tool">
            {loading ? <p data-source-location="src/pages/Toolbox.jsx:142:23" data-dynamic-content="false" className="text-muted-foreground text-sm text-center py-8">Loading...</p> :
          myTools.length === 0 ? <p data-source-location="src/pages/Toolbox.jsx:143:36" data-dynamic-content="false" className="text-muted-foreground text-sm text-center py-8">You haven't created any tools yet.</p> :
          myTools.map((t) => <ToolCard data-source-location="src/pages/Toolbox.jsx:144:30" data-dynamic-content="true" key={t.id} t={t} data-collection-item-id={t?.id} />)}
          </div>
        }

        {tab === "create" &&
        <div data-source-location="src/pages/Toolbox.jsx:149:10" data-dynamic-content="true" className="bg-card/60 backdrop-blur-xl border border-border rounded-2xl p-6 space-y-5">
            <div data-source-location="src/pages/Toolbox.jsx:150:12" data-dynamic-content="true">
              <label data-source-location="src/pages/Toolbox.jsx:151:14" data-dynamic-content="false" className="block text-sm font-medium text-foreground mb-1.5">Title</label>
              <Input data-source-location="src/pages/Toolbox.jsx:152:14" data-dynamic-content="true" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Calculus cheat sheet"
            className="h-11 text-foreground bg-muted/50 border-border placeholder:text-muted-foreground/60" />
            </div>
            <div data-source-location="src/pages/Toolbox.jsx:155:12" data-dynamic-content="true">
              <label data-source-location="src/pages/Toolbox.jsx:156:14" data-dynamic-content="false" className="block text-sm font-medium text-foreground mb-1.5">Upload a file (any type)</label>
              <input data-source-location="src/pages/Toolbox.jsx:157:14" data-dynamic-content="true" ref={fileRef} type="file" hidden onChange={handleFileChange} />
              <button data-source-location="src/pages/Toolbox.jsx:158:14" data-dynamic-content="true" type="button" onClick={() => fileRef.current?.click()}
            className="w-full border-2 border-dashed border-border rounded-xl p-6 text-center hover:border-primary/50 transition-colors">
                {uploading ? <p data-source-location="src/pages/Toolbox.jsx:160:29" data-dynamic-content="false" className="text-sm text-muted-foreground">Uploading...</p> :
              file ? <p data-source-location="src/pages/Toolbox.jsx:161:24" data-dynamic-content="true" className="text-sm text-foreground" data-collection-item-field="name" data-collection-item-id={file?.id || file?._id}>{file.name}</p> :
              <div data-source-location="src/pages/Toolbox.jsx:162:17" data-dynamic-content="false" className="flex flex-col items-center gap-2 text-muted-foreground"><Upload data-source-location="src/pages/Toolbox.jsx:162:89" data-dynamic-content="false" className="w-6 h-6" /><span data-source-location="src/pages/Toolbox.jsx:162:119" data-dynamic-content="false" className="text-sm">Click to upload any file</span></div>}
              </button>
            </div>
            <div data-source-location="src/pages/Toolbox.jsx:165:12" data-dynamic-content="true">
              <label data-source-location="src/pages/Toolbox.jsx:166:14" data-dynamic-content="false" className="block text-sm font-medium text-foreground mb-1.5">Explanation (min 25 words)</label>
              <textarea data-source-location="src/pages/Toolbox.jsx:167:14" data-dynamic-content="true" value={description} onChange={(e) => setDescription(e.target.value)} rows={5}
            placeholder="Explain how to use this tool step by step so any tutor can follow it..."
            className="w-full px-4 py-3 border border-border rounded-xl focus:border-primary focus:outline-none resize-none text-sm text-foreground bg-muted/50 placeholder:text-muted-foreground/60" />
              <p data-source-location="src/pages/Toolbox.jsx:170:14" data-dynamic-content="true" className="text-xs text-muted-foreground mt-1" data-collection-item-field="wordCount">{wordCount} words</p>
            </div>
            <div data-source-location="src/pages/Toolbox.jsx:172:12" data-dynamic-content="true">
              <label data-source-location="src/pages/Toolbox.jsx:173:14" data-dynamic-content="false" className="block text-sm font-medium text-foreground mb-2">Visibility</label>
              <div data-source-location="src/pages/Toolbox.jsx:174:14" data-dynamic-content="true" className="flex gap-2">
                <button data-source-location="src/pages/Toolbox.jsx:175:16" data-dynamic-content="true" type="button" onClick={() => setIsPublic(false)}
              className={`flex-1 py-2.5 rounded-lg text-sm font-semibold border transition-colors ${!isPublic ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground"}`}>
                  <span data-source-location="src/pages/Toolbox.jsx:177:18" data-dynamic-content="false" className="flex items-center justify-center gap-1.5"><Lock data-source-location="src/pages/Toolbox.jsx:177:77" data-dynamic-content="false" className="w-4 h-4" /> Private (My Tools)</span>
                </button>
                <button data-source-location="src/pages/Toolbox.jsx:179:16" data-dynamic-content="true" type="button" onClick={() => setIsPublic(true)}
              className={`flex-1 py-2.5 rounded-lg text-sm font-semibold border transition-colors ${isPublic ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground"}`}>
                  <span data-source-location="src/pages/Toolbox.jsx:181:18" data-dynamic-content="false" className="flex items-center justify-center gap-1.5"><Globe data-source-location="src/pages/Toolbox.jsx:181:77" data-dynamic-content="false" className="w-4 h-4" /> Public (All Tools)</span>
                </button>
              </div>
            </div>
            {error && <p data-source-location="src/pages/Toolbox.jsx:185:22" data-dynamic-content="true" className="text-sm text-destructive bg-destructive/10 p-3 rounded-lg" data-collection-item-field="error">{error}</p>}
            <Button data-source-location="src/pages/Toolbox.jsx:186:12" data-dynamic-content="true" onClick={handleCreate} disabled={saving || uploading}
          className="w-full h-12 text-base bg-primary hover:bg-primary/90 text-primary-foreground flex items-center justify-center gap-2">
              <Plus data-source-location="src/pages/Toolbox.jsx:188:14" data-dynamic-content="false" className="w-5 h-5" /> {saving ? "Saving..." : "Save Tool"}
            </Button>
          </div>
        }
      </div>
    </div>);

}