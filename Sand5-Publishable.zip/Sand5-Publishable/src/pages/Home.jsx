import { useEffect, useRef, useState } from "react";
import { useAuth } from "@/lib/AuthContext";
import Logo from "@/components/Logo";

const CHAPTERS = [
{ num: "I", title: "Our Story", text: "S&5 started with a simple observation: the best explanations often come from someone who learned the material last year, not last decade. We built a place for that kind of teaching to happen on purpose." },
{ num: "II", title: "Our Mission", text: "Make expert peer tutoring easy to find, easy to book, and easy to trust — so every student has someone in their corner, and every tutor is paid fairly for their time." },
{ num: "III", title: "Our Approach", text: "We match on subject, grade level, and learning style, not just availability. A good match means fewer wasted sessions and faster progress for the student." },
{ num: "IV", title: "Student Success", text: "Every session is built around a goal — better grades, real understanding, or simply more confidence walking into a test. Progress is the only metric that matters." },
{ num: "V", title: "Our Values", text: "Clarity over jargon, fairness over friction, and respect for both sides of the desk. Tutors are professionals here, not volunteers." },
{ num: "VI", title: "Looking Forward", text: "We're building toward a version of tutoring that scales without losing the one-on-one feeling that makes it work in the first place." }];


const ROW1 = ["Pre-Algebra", "Algebra I", "Algebra II", "Geometry", "Pre-Calculus", "Calculus AB", "Calculus BC", "Statistics", "Trigonometry"];
const ROW2 = ["Biology", "Chemistry", "Physics", "Astronomy", "Earth Science", "Environmental Science", "AP Biology", "AP Chemistry", "AP Physics", "Microbiology", "Genetics", "Organic Chemistry", "Anatomy & Physiology", "Marine Biology"];
const ROW3 = ["English", "Literature", "Essay Writing", "Creative Writing", "World History", "US History", "Economics", "Psychology", "Philosophy", "Spanish", "French", "Mandarin Chinese", "Music Theory", "Art History", "Swimming", "Playing an instrument", "Martial arts", "Singing and vocal training", "Dance", "Tennis and golf coaching"];

const SOCIALS = [
{ label: "LinkedIn", href: "https://www.linkedin.com/in/sand-five-27046842a/" },
{ label: "Twitter", href: "https://x.com/SandFive618" },
{ label: "Instagram", href: "https://www.instagram.com/s5tutoring" },
{ label: "YouTube", href: "https://youtube.com/@sandfive618?si=iAWIbWkY8mp6Ovr9" },
{ label: "Facebook", href: "https://www.facebook.com/share/14rssoLo7rx/?mibextid=wwXIfr" }];


function MarqueeRow({ words, variant, "data-collection-item-id": __dataCollectionItemId }) {
  const items = [];
  words.forEach((w, i) => {
    items.push(<span data-source-location="src/pages/Home.jsx:29:15" data-dynamic-content="true" key={`w${i}`} data-collection-item-field="w">{w}</span>);
    items.push(<span data-source-location="src/pages/Home.jsx:30:15" data-dynamic-content="true" key={`d${i}`} className="dot">·</span>);
  });
  return (
    <div data-source-location="src/pages/Home.jsx:33:4" data-dynamic-content="true" className={`subj-row ${variant}`} data-collection-item-id={__dataCollectionItemId}>
      <div data-source-location="src/pages/Home.jsx:34:6" data-dynamic-content="true" className="subj-track">{items}{items}</div>
    </div>);

}

export default function Home() {
  const { user } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const revealRefs = useRef([]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          e.target.classList.add("in");
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.15 });
    revealRefs.current.forEach((el) => el && io.observe(el));
    return () => io.disconnect();
  }, []);

  const setRef = (i) => (el) => {revealRefs.current[i] = el;};

  const tickerItems = [];
  for (let i = 0; i < 12; i++) {
    tickerItems.push(<span data-source-location="src/pages/Home.jsx:67:21" data-dynamic-content="true" key={`l${i}`}>LEARN</span>);
    tickerItems.push(<span data-source-location="src/pages/Home.jsx:68:21" data-dynamic-content="true" key={`d${i}`} className="dot">·</span>);
    tickerItems.push(<span data-source-location="src/pages/Home.jsx:69:21" data-dynamic-content="true" key={`t${i}`}>TEACH</span>);
    tickerItems.push(<span data-source-location="src/pages/Home.jsx:70:21" data-dynamic-content="true" key={`d2${i}`} className="dot">·</span>);
    tickerItems.push(<span data-source-location="src/pages/Home.jsx:71:21" data-dynamic-content="true" key={`e${i}`}>EARN</span>);
    tickerItems.push(<span data-source-location="src/pages/Home.jsx:72:21" data-dynamic-content="true" key={`d3${i}`} className="dot">·</span>);
  }

  return (
    <div data-source-location="src/pages/Home.jsx:76:4" data-dynamic-content="true" className="s5-home">
      <header data-source-location="src/pages/Home.jsx:77:6" data-dynamic-content="true" id="siteHeader" className={scrolled ? "scrolled" : ""}>
        <div data-source-location="src/pages/Home.jsx:78:8" data-dynamic-content="false" className="wrap">
          <div data-source-location="src/pages/Home.jsx:79:10" data-dynamic-content="false" className="brandmark">
            <Logo data-source-location="src/pages/Home.jsx:80:12" data-dynamic-content="false" height={34} />
            <span data-source-location="src/pages/Home.jsx:81:12" data-dynamic-content="false">S<em data-source-location="src/pages/Home.jsx:81:19" data-dynamic-content="false">&amp;</em>5</span>
          </div>
          <nav data-source-location="src/pages/Home.jsx:83:10" data-dynamic-content="false" className="links">
            <a data-source-location="src/pages/Home.jsx:84:12" data-dynamic-content="false" href="/get-started" className="login">Login</a>
            <a data-source-location="src/pages/Home.jsx:85:12" data-dynamic-content="false" href="/sign-up" className="cta">Get Started</a>
          </nav>
        </div>
      </header>

      <section data-source-location="src/pages/Home.jsx:90:6" data-dynamic-content="false" className="hero">
        <div data-source-location="src/pages/Home.jsx:91:8" data-dynamic-content="false" className="hero-amp" aria-hidden="true">&amp;</div>
        <div data-source-location="src/pages/Home.jsx:92:8" data-dynamic-content="false" className="wrap">
          <div data-source-location="src/pages/Home.jsx:93:10" data-dynamic-content="false" className="eyebrow"><span data-source-location="src/pages/Home.jsx:93:35" data-dynamic-content="false" className="rule" /> Peer tutoring, done right</div>
          <h1 data-source-location="src/pages/Home.jsx:94:10" data-dynamic-content="false" className="wordmark">S<em data-source-location="src/pages/Home.jsx:94:36" data-dynamic-content="false">&amp;</em>5</h1>
          <h2 data-source-location="src/pages/Home.jsx:95:10" data-dynamic-content="false" className="tagline">Earn Today,<br data-source-location="src/pages/Home.jsx:95:45" data-dynamic-content="false" />Build Tomorrow.</h2>
          <p data-source-location="src/pages/Home.jsx:96:10" data-dynamic-content="false" className="sub">Connect students with expert peer tutors. Learn smarter, earn faster.</p>
          <div data-source-location="src/pages/Home.jsx:97:10" data-dynamic-content="false" className="hero-actions">
            <a data-source-location="src/pages/Home.jsx:98:12" data-dynamic-content="false" href="/sign-up" className="btn-primary">Get Started</a>
            <a data-source-location="src/pages/Home.jsx:99:12" data-dynamic-content="false" href="#about" className="link-arrow">About S&amp;5</a>
          </div>
        </div>
      </section>

      <div data-source-location="src/pages/Home.jsx:104:6" data-dynamic-content="true" className="ticker-band" aria-hidden="true">
        <div data-source-location="src/pages/Home.jsx:105:8" data-dynamic-content="true" className="ticker-track">{tickerItems}</div>
      </div>

      <section data-source-location="src/pages/Home.jsx:108:6" data-dynamic-content="true" className="about" id="about">
        <div data-source-location="src/pages/Home.jsx:109:8" data-dynamic-content="true" className="wrap">
          <div data-source-location="src/pages/Home.jsx:110:10" data-dynamic-content="true" className="section-head reveal" ref={setRef(0)}>
            <div data-source-location="src/pages/Home.jsx:111:12" data-dynamic-content="false" className="eyebrow"><span data-source-location="src/pages/Home.jsx:111:37" data-dynamic-content="false" className="rule" /> About Us</div>
            <h3 data-source-location="src/pages/Home.jsx:112:12" data-dynamic-content="false">Six chapters, one platform.</h3>
          </div>
          {CHAPTERS.map((ch, i) =>
          <div data-source-location="src/pages/Home.jsx:115:12" data-dynamic-content="true" className="chapter reveal" key={ch.num} ref={setRef(i + 1)} data-arr-index={i} data-arr-variable-name="CHAPTERS">
              <div data-source-location="src/pages/Home.jsx:116:14" data-dynamic-content="true" className="num" data-arr-index={i} data-arr-variable-name="CHAPTERS" data-arr-field="num">{ch.num}</div>
              <h4 data-source-location="src/pages/Home.jsx:117:14" data-dynamic-content="true" data-arr-index={i} data-arr-variable-name="CHAPTERS" data-arr-field="title">{ch.title}</h4>
              <p data-source-location="src/pages/Home.jsx:118:14" data-dynamic-content="true" data-arr-index={i} data-arr-variable-name="CHAPTERS" data-arr-field="text">{ch.text}</p>
            </div>
          )}
        </div>
      </section>

      <section data-source-location="src/pages/Home.jsx:124:6" data-dynamic-content="true" className="subjects">
        <div data-source-location="src/pages/Home.jsx:125:8" data-dynamic-content="false" className="watermark" aria-hidden="true">learn..</div>
        <MarqueeRow data-source-location="src/pages/Home.jsx:126:8" data-dynamic-content="true" words={ROW1} variant="big" />
        <MarqueeRow data-source-location="src/pages/Home.jsx:127:8" data-dynamic-content="true" words={ROW2} variant="med" />
        <MarqueeRow data-source-location="src/pages/Home.jsx:128:8" data-dynamic-content="true" words={ROW3} variant="big" />
      </section>

      <section data-source-location="src/pages/Home.jsx:131:6" data-dynamic-content="true" className="connect">
        <div data-source-location="src/pages/Home.jsx:132:8" data-dynamic-content="true" className="wrap">
          <div data-source-location="src/pages/Home.jsx:133:10" data-dynamic-content="true" className="section-head reveal" ref={setRef(7)}>
            <div data-source-location="src/pages/Home.jsx:134:12" data-dynamic-content="true" className="eyebrow" style={{ justifyContent: "center" }}><span data-source-location="src/pages/Home.jsx:134:74" data-dynamic-content="false" className="rule" /> Find Us <span data-source-location="src/pages/Home.jsx:134:108" data-dynamic-content="false" className="rule" /></div>
            <h3 data-source-location="src/pages/Home.jsx:135:12" data-dynamic-content="false">Say hello.</h3>
          </div>
          <div data-source-location="src/pages/Home.jsx:137:10" data-dynamic-content="true" className="social-list reveal" ref={setRef(8)}>
            {SOCIALS.map((s, __arrIdx__) =>
            <a data-source-location="src/pages/Home.jsx:139:14" data-dynamic-content="true" key={s.label} href={s.href} target="_blank" rel="noopener noreferrer" data-arr-index={__arrIdx__} data-arr-variable-name="SOCIALS" data-arr-field="label">
                {s.label}
              </a>
            )}
          </div>
        </div>
      </section>

      <footer data-source-location="src/pages/Home.jsx:147:6" data-dynamic-content="true">
        <div data-source-location="src/pages/Home.jsx:148:8" data-dynamic-content="true" className="wrap">
          <div data-source-location="src/pages/Home.jsx:149:10" data-dynamic-content="false" className="foot-brand">
            <Logo data-source-location="src/pages/Home.jsx:150:12" data-dynamic-content="false" height={20} />
            <span data-source-location="src/pages/Home.jsx:151:12" data-dynamic-content="false">S<em data-source-location="src/pages/Home.jsx:151:19" data-dynamic-content="false">&amp;</em>5</span>
          </div>
          <div data-source-location="src/pages/Home.jsx:153:10" data-dynamic-content="true" className="foot-links">
            <a data-source-location="src/pages/Home.jsx:154:12" data-dynamic-content="false" href="/about">About</a>
            <a data-source-location="src/pages/Home.jsx:155:12" data-dynamic-content="false" href="/contact">Contact</a>
            <a data-source-location="src/pages/Home.jsx:156:12" data-dynamic-content="false" href="/privacy-policy">Privacy Policy</a>
            {user?.role === "admin" && <a data-source-location="src/pages/Home.jsx:157:39" data-dynamic-content="false" href="/admin">Admin</a>}
          </div>
        </div>
      </footer>

      <style data-source-location="src/pages/Home.jsx:162:6" data-dynamic-content="false">{`
        .s5-home {
          --ink:#050505;
          --ink-2:#0a0a0a;
          --paper:#f3efe4;
          --paper-dim:rgba(243,239,228,0.62);
          --paper-faint:rgba(243,239,228,0.36);
          --line:rgba(243,239,228,0.14);
          --line-strong:rgba(243,239,228,0.28);
          --blue:#0d6bf6;
          --blue-light:#7ea7ff;
          --blue-deep:#03102e;
          --radius:2px;
          background:var(--ink);
          color:var(--paper);
          font-family:'Neuton', Georgia, serif;
          font-weight:400;
          line-height:1.5;
          overflow-x:hidden;
          position:relative;
          min-height:100vh;
        }
        .s5-home * { margin:0; padding:0; box-sizing:border-box; }
        .s5-home a { color:inherit; text-decoration:none; }
        .s5-home .wrap { max-width:1180px; margin:0 auto; padding:0 32px; }

        /* NAV */
        .s5-home header {
          position:fixed; top:0; left:0; right:0; z-index:100;
          padding:26px 0;
          transition:background 0.4s ease, border-color 0.4s ease, padding 0.4s ease;
          border-bottom:1px solid transparent;
        }
        .s5-home header.scrolled {
          background:rgba(5,5,5,0.86);
          backdrop-filter:blur(10px);
          border-bottom-color:var(--line);
          padding:16px 0;
        }
        .s5-home header .wrap { display:flex; align-items:center; justify-content:space-between; }
        .s5-home .brandmark { display:flex; align-items:center; gap:12px; }
        .s5-home .brandmark span { font-weight:800; font-size:1.35rem; letter-spacing:0.01em; }
        .s5-home .brandmark span em { font-style:italic; color:var(--blue-light); font-weight:400; padding:0 1px; }
        .s5-home nav.links { display:flex; align-items:center; gap:36px; font-size:0.98rem; }
        .s5-home nav.links a.login { color:var(--paper-dim); position:relative; padding-bottom:2px; }
        .s5-home nav.links a.login::after {
          content:""; position:absolute; left:0; right:100%; bottom:0; height:1px; background:var(--paper);
          transition:right 0.35s ease;
        }
        .s5-home nav.links a.login:hover::after { right:0; }
        .s5-home nav.links a.cta {
          border:1px solid var(--blue); color:var(--paper); padding:9px 22px;
          font-style:italic; font-size:0.95rem; transition:background 0.3s ease, color 0.3s ease;
        }
        .s5-home nav.links a.cta:hover { background:var(--blue); }

        /* HERO */
        .s5-home .hero {
          position:relative; min-height:100vh; display:flex; align-items:center;
          padding:140px 0 100px; overflow:hidden;
        }
        .s5-home .hero-amp {
          position:absolute; right:-8vw; top:50%; transform:translateY(-52%);
          font-size:62vw; line-height:1; font-weight:800; font-style:italic;
          background:linear-gradient(160deg, var(--blue) 0%, var(--blue-deep) 78%);
          -webkit-background-clip:text; background-clip:text; color:transparent;
          opacity:0.5; pointer-events:none; user-select:none; filter:blur(0.5px);
        }
        .s5-home .hero .wrap { position:relative; z-index:2; }
        .s5-home .eyebrow {
          display:flex; align-items:center; gap:10px;
          font-style:italic; color:var(--paper-dim); font-size:1rem;
          letter-spacing:0.04em; margin-bottom:28px;
        }
        .s5-home .eyebrow .rule { width:38px; height:1px; background:var(--line-strong); }
        .s5-home h1.wordmark {
          font-size:clamp(3.4rem, 9vw, 7.2rem); font-weight:800;
          line-height:0.95; letter-spacing:-0.01em; margin-bottom:6px;
        }
        .s5-home h1.wordmark em { font-style:italic; font-weight:400; color:var(--blue-light); }
        .s5-home h2.tagline {
          font-size:clamp(2rem, 4.4vw, 3.6rem); font-weight:200; font-style:italic;
          color:rgba(243,239,228,0.82); max-width:720px; margin:18px 0 26px; line-height:1.12;
        }
        .s5-home p.sub { font-size:1.18rem; color:var(--paper-dim); max-width:480px; margin-bottom:44px; }
        .s5-home .hero-actions { display:flex; align-items:center; gap:28px; flex-wrap:wrap; }
        .s5-home .btn-primary {
          background:var(--blue); color:#fff; padding:15px 34px;
          font-family:'Neuton', serif; font-size:1.05rem; font-style:italic;
          border:1px solid var(--blue); transition:background 0.3s ease, transform 0.3s ease;
          display:inline-block;
        }
        .s5-home .btn-primary:hover { background:#0958d1; transform:translateY(-1px); }
        .s5-home .link-arrow { font-size:1rem; color:var(--paper-dim); position:relative; padding-right:22px; }
        .s5-home .link-arrow::after { content:"→"; position:absolute; right:0; top:0; transition:right 0.3s ease; }
        .s5-home .link-arrow:hover::after { right:-6px; }
        .s5-home .link-arrow:hover { color:var(--paper); }

        /* TICKER */
        .s5-home .ticker-band {
          background:var(--blue); color:var(--ink); padding:14px 0;
          overflow:hidden; white-space:nowrap;
          border-top:1px solid var(--ink); border-bottom:1px solid var(--ink);
        }
        .s5-home .ticker-track {
          display:inline-flex; animation:s5-scroll-left 42s linear infinite;
          font-style:italic; font-size:1.05rem; font-weight:400;
        }
        .s5-home .ticker-track span { padding:0 22px; display:inline-block; }
        .s5-home .ticker-track span.dot { padding:0 6px; font-style:normal; }
        @keyframes s5-scroll-left { from{transform:translateX(0);} to{transform:translateX(-50%);} }
        @keyframes s5-scroll-right { from{transform:translateX(-50%);} to{transform:translateX(0);} }

        /* SECTIONS */
        .s5-home section { padding:130px 0; }
        .s5-home .section-head { margin-bottom:70px; }
        .s5-home .section-head .eyebrow { margin-bottom:16px; }
        .s5-home .section-head h3 {
          font-size:clamp(2.2rem, 4vw, 3.2rem); font-weight:400; font-style:italic; color:var(--paper);
        }

        /* ABOUT */
        .s5-home .about { border-top:1px solid var(--line); }
        .s5-home .chapter {
          display:grid; grid-template-columns:120px 1fr 1.15fr; gap:40px;
          align-items:baseline; padding:36px 0; border-top:1px solid var(--line);
          transition:padding-left 0.4s ease;
        }
        .s5-home .chapter:last-child { border-bottom:1px solid var(--line); }
        .s5-home .chapter:hover { padding-left:14px; }
        .s5-home .chapter .num { font-style:italic; font-weight:200; font-size:1.6rem; color:var(--blue-light); }
        .s5-home .chapter h4 { font-size:1.6rem; font-weight:700; letter-spacing:-0.01em; }
        .s5-home .chapter p { color:var(--paper-dim); font-size:1.02rem; max-width:46ch; }
        @media (max-width:760px) { .s5-home .chapter { grid-template-columns:1fr; gap:10px; } }

        /* SUBJECTS */
        .s5-home .subjects {
          position:relative; border-top:1px solid var(--line); overflow:hidden; padding:110px 0;
        }
        .s5-home .subjects .watermark {
          position:absolute; left:50%; top:50%; transform:translate(-50%,-50%);
          font-size:22vw; font-style:italic; font-weight:800;
          color:rgba(243,239,228,0.035); white-space:nowrap; pointer-events:none; z-index:0;
        }
        .s5-home .subj-row { position:relative; z-index:1; white-space:nowrap; overflow:hidden; margin:20px 0; }
        .s5-home .subj-track { display:inline-flex; font-style:italic; }
        .s5-home .subj-track span { padding:0 20px; display:inline-block; color:var(--paper-dim); }
        .s5-home .subj-track span.dot { padding:0 4px; color:var(--line-strong); font-style:normal; }
        .s5-home .subj-row.big .subj-track { font-size:clamp(2rem,5vw,4.2rem); font-weight:200; animation:s5-scroll-left 70s linear infinite; }
        .s5-home .subj-row.med .subj-track { font-size:clamp(1.1rem,2.2vw,1.7rem); font-weight:400; animation:s5-scroll-right 55s linear infinite; color:var(--blue-light); }
        .s5-home .subj-row.big .subj-track span { color:var(--paper-faint); }

        /* CONNECT */
        .s5-home .connect { border-top:1px solid var(--line); text-align:center; }
        .s5-home .connect .section-head { margin-bottom:50px; }
        .s5-home .connect .section-head h3 { text-align:center; }
        .s5-home .social-list { display:flex; justify-content:center; flex-wrap:wrap; gap:0; font-size:1.3rem; font-style:italic; }
        .s5-home .social-list a { padding:0 28px; position:relative; color:var(--paper-dim); transition:color 0.3s ease; }
        .s5-home .social-list a:not(:last-child)::after {
          content:"·"; position:absolute; right:-3px; color:var(--line-strong); font-style:normal;
        }
        .s5-home .social-list a:hover { color:var(--blue-light); }

        /* FOOTER */
        .s5-home footer { border-top:1px solid var(--line); padding:48px 0 40px; }
        .s5-home footer .wrap { display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:20px; }
        .s5-home .foot-brand { display:flex; align-items:center; gap:10px; font-size:1rem; color:var(--paper-dim); }
        .s5-home .foot-brand span { font-weight:800; font-size:1.35rem; }
        .s5-home .foot-brand span em { font-style:italic; color:var(--blue-light); font-weight:400; padding:0 1px; }
        .s5-home footer .foot-links { display:flex; gap:30px; font-size:0.95rem; color:var(--paper-dim); }
        .s5-home footer .foot-links a:hover { color:var(--paper); }

        @media (max-width:640px) {
          .s5-home .hero { padding:120px 0 70px; }
          .s5-home section { padding:90px 0; }
          .s5-home .hero-amp { font-size:130vw; right:-40vw; }
        }

        /* reveal */
        .s5-home .reveal { opacity:0; transform:translateY(18px); transition:opacity 0.8s ease, transform 0.8s ease; }
        .s5-home .reveal.in { opacity:1; transform:translateY(0); }

        @media (prefers-reduced-motion: reduce) {
          .s5-home .ticker-track, .s5-home .subj-track { animation:none !important; }
          .s5-home .reveal { opacity:1; transform:none; }
        }
      `}</style>
    </div>);

}