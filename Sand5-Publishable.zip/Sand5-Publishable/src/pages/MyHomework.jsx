import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { Check, ArrowLeft, ChevronDown, BookOpen } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function MyHomework() {
  const studentName = JSON.parse(sessionStorage.getItem("onboardingData") || "{}").name || "Student";
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    if (!studentName || studentName === "Student") {setLoading(false);return;}
    const loadHomework = async () => {
      try {
        const hw = await base44.entities.Homework.filter({ student_name: studentName }, "-created_date");
        setItems(hw);
      } catch (e) {console.error("Failed to load homework:", e);}
      setLoading(false);
    };
    loadHomework();
    const unsubscribe = base44.entities.Homework.subscribe((event) => {
      if (!event.data || event.data.student_name !== studentName) return;
      if (event.type === "create") {
        setItems((prev) => [event.data, ...prev.filter((i) => i.id !== event.data.id)]);
      } else if (event.type === "update") {
        setItems((prev) => prev.map((i) => i.id === event.data.id ? event.data : i));
      } else if (event.type === "delete") {
        setItems((prev) => prev.filter((i) => i.id !== event.data.id));
      }
    });
    return () => {if (typeof unsubscribe === 'function') unsubscribe();};
  }, [studentName]);

  const toggle = async (id) => {
    const item = items.find((i) => i.id === id);
    if (!item) return;
    try {
      await base44.entities.Homework.update(id, { done: !item.done });
    } catch (e) {console.error("Failed to update homework:", e);}
  };

  return (
    <div data-source-location="src/pages/MyHomework.jsx:45:4" data-dynamic-content="true" className="min-h-screen font-body relative z-10">
      <nav data-source-location="src/pages/MyHomework.jsx:46:6" data-dynamic-content="false" className="bg-card/80 backdrop-blur-md border-b border-border px-6 py-4 flex items-center gap-4">
        <Link data-source-location="src/pages/MyHomework.jsx:47:8" data-dynamic-content="false" to="/student-dashboard" className="text-muted-foreground hover:text-foreground"><ArrowLeft data-source-location="src/pages/MyHomework.jsx:47:94" data-dynamic-content="false" className="w-5 h-5" /></Link>
        <h1 data-source-location="src/pages/MyHomework.jsx:48:8" data-dynamic-content="false" className="font-heading font-bold text-foreground text-lg">My Homework</h1>
      </nav>

      <div data-source-location="src/pages/MyHomework.jsx:51:6" data-dynamic-content="true" className="max-w-2xl mx-auto px-6 py-8">
        {loading ?
        <div data-source-location="src/pages/MyHomework.jsx:53:10" data-dynamic-content="false" className="flex items-center justify-center py-20">
            <div data-source-location="src/pages/MyHomework.jsx:54:12" data-dynamic-content="false" className="w-8 h-8 border-4 border-border border-t-primary rounded-full animate-spin"></div>
          </div> :
        items.length === 0 ?
        <div data-source-location="src/pages/MyHomework.jsx:57:10" data-dynamic-content="false" className="text-center py-16">
            <BookOpen data-source-location="src/pages/MyHomework.jsx:58:12" data-dynamic-content="false" className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
            <p data-source-location="src/pages/MyHomework.jsx:59:12" data-dynamic-content="false" className="text-lg font-semibold text-foreground mb-1">No homework yet</p>
            <p data-source-location="src/pages/MyHomework.jsx:60:12" data-dynamic-content="false" className="text-sm text-muted-foreground">When your tutor assigns homework, it will appear here.</p>
          </div> :

        <div data-source-location="src/pages/MyHomework.jsx:63:10" data-dynamic-content="true" className="space-y-2" data-collection-id="Homework">
            {items.map((item, i) =>
          <motion.div data-source-location="src/pages/MyHomework.jsx:65:14" data-dynamic-content="true" key={item.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
          className="bg-card rounded-2xl border border-border overflow-hidden" data-collection-item-id={item?.id}>
                <div data-source-location="src/pages/MyHomework.jsx:67:16" data-dynamic-content="true" className="p-4 flex items-center gap-4 cursor-pointer" onClick={() => setExpanded(expanded === item.id ? null : item.id)} data-collection-item-field="description" data-collection-item-id={item?.id}>
                  <button data-source-location="src/pages/MyHomework.jsx:68:18" data-dynamic-content="true" onClick={(e) => {e.stopPropagation();toggle(item.id);}}
              className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-colors ${item.done ? "bg-primary border-primary" : "border-border hover:border-primary"}`} data-collection-item-field="done" data-collection-item-id={item?.id}>
                    {item.done && <Check data-source-location="src/pages/MyHomework.jsx:70:34" data-dynamic-content="false" className="w-3 h-3 text-primary-foreground" />}
                  </button>
                  <div data-source-location="src/pages/MyHomework.jsx:72:18" data-dynamic-content="true" className="flex-1 min-w-0">
                    <p data-source-location="src/pages/MyHomework.jsx:73:20" data-dynamic-content="true" className={`text-sm font-medium ${item.done ? "line-through text-muted-foreground" : "text-foreground"}`} data-collection-item-field="title" data-collection-item-id={item?.id}>{item.title}</p>
                    <p data-source-location="src/pages/MyHomework.jsx:74:20" data-dynamic-content="true" className="text-xs text-muted-foreground" data-collection-item-field="subject" data-collection-item-id={item?.id}>{item.subject} · Due {item.due_date || "—"}</p>
                  </div>
                  {item.description &&
              <ChevronDown data-source-location="src/pages/MyHomework.jsx:77:20" data-dynamic-content="true" className={`w-4 h-4 text-muted-foreground transition-transform flex-shrink-0 ${expanded === item.id ? "rotate-180" : ""}`} />
              }
                </div>
                <AnimatePresence data-source-location="src/pages/MyHomework.jsx:80:16" data-dynamic-content="true">
                  {expanded === item.id && item.description &&
              <motion.div data-source-location="src/pages/MyHomework.jsx:82:20" data-dynamic-content="true" initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden border-t border-border">
                      <div data-source-location="src/pages/MyHomework.jsx:84:22" data-dynamic-content="true" className="px-4 py-3" data-collection-item-field="tutor_name" data-collection-item-id={item?.id}>
                        <p data-source-location="src/pages/MyHomework.jsx:85:24" data-dynamic-content="false" className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Instructions</p>
                        <p data-source-location="src/pages/MyHomework.jsx:86:24" data-dynamic-content="true" className="text-sm text-foreground leading-relaxed" data-collection-item-field="description" data-collection-item-id={item?.id}>{item.description}</p>
                        {item.tutor_name &&
                  <p data-source-location="src/pages/MyHomework.jsx:88:26" data-dynamic-content="true" className="text-xs text-muted-foreground mt-2" data-collection-item-field="tutor_name" data-collection-item-id={item?.id}>Assigned by {item.tutor_name}</p>
                  }
                      </div>
                    </motion.div>
              }
                </AnimatePresence>
              </motion.div>
          )}
          </div>
        }
      </div>
    </div>);

}