import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Logo from "@/components/Logo";

const CSS = `
.s5-page{
  --ink:var(--background); --ink-2:var(--card);
  --paper:var(--foreground); --paper-dim:var(--muted-foreground); --paper-faint:color-mix(in srgb, var(--foreground) 36%, transparent);
  --line:var(--border); --line-strong:color-mix(in srgb, var(--foreground) 28%, transparent);
  --blue:var(--primary); --blue-light:var(--accent-foreground); --blue-deep:var(--chart-4);
  background:var(--ink); color:var(--paper);
  font-family:'Neuton',Georgia,serif; font-weight:400; line-height:1.6;
  overflow-x:hidden; position:relative; min-height:100vh;
}
.s5-page *{margin:0;padding:0;box-sizing:border-box;}
.s5-page .wrap{max-width:860px; margin:0 auto; padding:0 32px;}
.s5-page a{color:inherit; text-decoration:none;}
.s5-page ::selection{background:var(--blue); color:var(--paper);}
.s5-page :focus-visible{outline:2px solid var(--blue-light); outline-offset:3px;}
.s5-page header{
  position:fixed; top:0; left:0; right:0; z-index:100;
  padding:22px 0; transition:background 0.4s ease,border-color 0.4s ease,padding 0.4s ease;
  border-bottom:1px solid transparent;
}
.s5-page header.scrolled{ background:color-mix(in srgb, var(--background) 86%, transparent); backdrop-filter:blur(10px); border-bottom-color:var(--line); padding:14px 0; }
.s5-page header .wrap{display:flex; align-items:center; justify-content:space-between;}
.s5-page .brandmark{display:flex; align-items:center; gap:14px;}
.s5-page .brandmark img{height:48px; width:48px; display:block;}
.s5-page .brandmark span{font-weight:800; font-size:1.55rem; letter-spacing:0.01em;}
.s5-page .brandmark span em{font-style:italic; color:var(--blue-light); font-weight:400; padding:0 1px;}
.s5-page nav.links{display:flex; align-items:center; gap:28px; font-size:0.98rem;}
.s5-page nav.links a{color:var(--paper-dim); position:relative; padding-bottom:2px;}
.s5-page nav.links a::after{content:""; position:absolute; left:0; right:100%; bottom:0; height:1px; background:var(--paper); transition:right 0.35s ease;}
.s5-page nav.links a:hover::after{right:0;}
.s5-page nav.links a.cta{border:1px solid var(--blue); color:var(--paper); padding:9px 22px; font-style:italic; font-size:0.95rem; transition:background 0.3s ease;}
.s5-page nav.links a.cta:hover{background:var(--blue);}
.s5-page nav.links a.cta::after{display:none;}
.s5-page .hero{ position:relative; min-height:60vh; display:flex; align-items:flex-end; padding:160px 0 60px; overflow:hidden;}
.s5-page .hero-amp{ position:absolute; right:-6vw; top:40%; transform:translateY(-50%); font-size:60vw; line-height:1; font-weight:800; font-style:italic;
  background:linear-gradient(160deg,var(--blue) 0%,var(--blue-deep) 78%); -webkit-background-clip:text; background-clip:text; color:transparent;
  opacity:0.4; pointer-events:none; user-select:none; filter:blur(0.5px);}
.s5-page .hero .wrap{position:relative; z-index:2;}
.s5-page .eyebrow{display:flex; align-items:center; gap:10px; font-style:italic; color:var(--paper-dim); font-size:1rem; letter-spacing:0.04em; margin-bottom:24px;}
.s5-page .eyebrow .rule{width:38px; height:1px; background:var(--line-strong);}
.s5-page h1.wordmark{ font-size:clamp(2.8rem,7vw,5rem); font-weight:800; line-height:0.95; letter-spacing:-0.01em;}
.s5-page h1.wordmark em{ font-style:italic; font-weight:400; color:var(--blue-light);}
.s5-page section.body{padding:70px 0 120px; border-top:1px solid var(--line);}
.s5-page section.body p{ font-size:1.18rem; color:var(--paper-dim); margin-bottom:24px; max-width:760px;}
.s5-page section.body p strong{color:var(--paper); font-weight:700;}
.s5-page section.body h2{ font-size:1.7rem; font-weight:700; font-style:italic; color:var(--paper); margin:48px 0 18px;}
.s5-page footer{ border-top:1px solid var(--line); padding:40px 0;}
.s5-page footer .wrap{display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:16px;}
.s5-page .foot-brand img{height:40px; width:40px;}
.s5-page footer p{color:var(--paper-dim); font-size:0.9rem; font-style:italic;}
.s5-page footer .foot-links{display:flex; gap:24px; font-size:0.9rem;}
.s5-page footer .foot-links a{color:var(--paper-dim); position:relative; padding-bottom:2px;}
.s5-page footer .foot-links a::after{content:""; position:absolute; left:0; right:100%; bottom:0; height:1px; background:var(--paper); transition:right 0.35s ease;}
.s5-page footer .foot-links a:hover::after{right:0;}
@media(max-width:820px){
  .s5-page .hero{padding:130px 0 50px;}
  .s5-page nav.links{gap:18px;}
}
`;

export default function About() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div data-source-location="src/pages/About.jsx:75:4" data-dynamic-content="true" className="s5-page">
      <style data-source-location="src/pages/About.jsx:76:6" data-dynamic-content="true" data-collection-item-field="CSS">{CSS}</style>

      <header data-source-location="src/pages/About.jsx:78:6" data-dynamic-content="true" className={scrolled ? "scrolled" : ""}>
        <div data-source-location="src/pages/About.jsx:79:8" data-dynamic-content="false" className="wrap">
          <Link data-source-location="src/pages/About.jsx:80:10" data-dynamic-content="false" to="/" className="brandmark">
            <Logo data-source-location="src/pages/About.jsx:81:12" data-dynamic-content="false" height={48} blend />
            <span data-source-location="src/pages/About.jsx:82:12" data-dynamic-content="false">S<em data-source-location="src/pages/About.jsx:82:19" data-dynamic-content="false">&</em>5</span>
          </Link>
          <nav data-source-location="src/pages/About.jsx:84:10" data-dynamic-content="false" className="links">
            <Link data-source-location="src/pages/About.jsx:85:12" data-dynamic-content="false" to="/about">About</Link>
            <Link data-source-location="src/pages/About.jsx:86:12" data-dynamic-content="false" to="/contact">Contact</Link>
            <Link data-source-location="src/pages/About.jsx:87:12" data-dynamic-content="false" to="/get-started" className="cta">Get Started</Link>
          </nav>
        </div>
      </header>

      <section data-source-location="src/pages/About.jsx:92:6" data-dynamic-content="false" className="hero">
        <div data-source-location="src/pages/About.jsx:93:8" data-dynamic-content="false" className="hero-amp" aria-hidden="true">&amp;</div>
        <div data-source-location="src/pages/About.jsx:94:8" data-dynamic-content="false" className="wrap">
          <div data-source-location="src/pages/About.jsx:95:10" data-dynamic-content="false" className="eyebrow"><span data-source-location="src/pages/About.jsx:95:35" data-dynamic-content="false" className="rule" /> About Us</div>
          <h1 data-source-location="src/pages/About.jsx:96:10" data-dynamic-content="false" className="wordmark">About S<em data-source-location="src/pages/About.jsx:96:42" data-dynamic-content="false">&amp;</em>5</h1>
        </div>
      </section>

      <section data-source-location="src/pages/About.jsx:100:6" data-dynamic-content="false" className="body">
        <div data-source-location="src/pages/About.jsx:101:8" data-dynamic-content="false" className="wrap">
          <p data-source-location="src/pages/About.jsx:102:10" data-dynamic-content="false">
            <strong data-source-location="src/pages/About.jsx:103:12" data-dynamic-content="false">S&amp;5 is a peer tutoring marketplace</strong> built on a simple idea: the best explanations often come from someone who learned the material last year, not last decade. We connect students with expert peer tutors for one-on-one sessions across math, science, humanities, languages, music, and more — so every learner has someone in their corner.
          </p>
          <p data-source-location="src/pages/About.jsx:105:10" data-dynamic-content="false">
            Our platform matches students and tutors by subject, grade level, and learning style — not just availability — so every session starts on a real foundation. Students browse tutor profiles, read honest reviews, and request connections. Tutors set their own rates, manage their roster, assign homework, and schedule live sessions over Google Meet.
          </p>
          <h2 data-source-location="src/pages/About.jsx:108:10" data-dynamic-content="false">Who it&rsquo;s for</h2>
          <p data-source-location="src/pages/About.jsx:109:10" data-dynamic-content="false">
            S&amp;5 is built for two people. The <strong data-source-location="src/pages/About.jsx:110:49" data-dynamic-content="false">student</strong> who wants clearer explanations, better grades, and more confidence walking into a test. And the <strong data-source-location="src/pages/About.jsx:110:170" data-dynamic-content="false">tutor</strong> who wants to earn meaningfully from what they already know. We serve everyone from early learners to college students, with grade levels spanning Pre-K through College &amp; Up.
          </p>
          <h2 data-source-location="src/pages/About.jsx:112:10" data-dynamic-content="false">Who builds it</h2>
          <p data-source-location="src/pages/About.jsx:113:10" data-dynamic-content="false">
            S&amp;5 is built by a small team that believes tutoring should feel personal, fair, and focused — even at scale. Clarity over jargon, fairness over friction, and respect for both sides of the desk. Tutors are professionals here, and students deserve explanations that actually click.
          </p>
          <p data-source-location="src/pages/About.jsx:116:10" data-dynamic-content="false">
            We&rsquo;re building toward tutoring that scales without losing the one-on-one feeling that makes it work. Earn today, build tomorrow.
          </p>
        </div>
      </section>

      <footer data-source-location="src/pages/About.jsx:122:6" data-dynamic-content="false">
        <div data-source-location="src/pages/About.jsx:123:8" data-dynamic-content="false" className="wrap">
          <Link data-source-location="src/pages/About.jsx:124:10" data-dynamic-content="false" to="/" className="foot-brand">
            <Logo data-source-location="src/pages/About.jsx:125:12" data-dynamic-content="false" height={40} blend />
          </Link>
          <div data-source-location="src/pages/About.jsx:127:10" data-dynamic-content="false" className="foot-links">
            <Link data-source-location="src/pages/About.jsx:128:12" data-dynamic-content="false" to="/about">About</Link>
            <Link data-source-location="src/pages/About.jsx:129:12" data-dynamic-content="false" to="/contact">Contact</Link>
            <Link data-source-location="src/pages/About.jsx:130:12" data-dynamic-content="false" to="/get-started">Login</Link>
            <Link data-source-location="src/pages/About.jsx:131:12" data-dynamic-content="false" to="/sign-up">Get Started</Link>
          </div>
          <p data-source-location="src/pages/About.jsx:133:10" data-dynamic-content="false">© 2025 S&amp;5 — Earn Today, Build Tomorrow.</p>
        </div>
      </footer>
    </div>);

}