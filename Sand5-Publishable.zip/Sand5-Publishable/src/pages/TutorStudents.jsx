import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowLeft, Video, MessageCircle, BookOpen, Mail, Clock, PhoneOff } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { refreshMyStudents, generateMeetLink, expireOldCalls } from "@/lib/loadConnections";
import AdminNotifications from "@/components/AdminNotifications";

export default function TutorStudents() {
  const [students, setStudents] = useState(() => JSON.parse(sessionStorage.getItem("myStudents") || "[]"));
  const [activeCall, setActiveCall] = useState(null);
  const [callStatus, setCallStatus] = useState(null); // "calling" | "accepted" | "declined" | null
  const tutorName = JSON.parse(sessionStorage.getItem("onboardingData") || "{}").name || "Tutor";

  useEffect(() => {
    refreshMyStudents(tutorName).then(setStudents);
  }, [tutorName]);

  useEffect(() => {
    if (!tutorName || tutorName === "Tutor") return;
    const loadCalls = async () => {
      try {
        const calling = (await expireOldCalls(tutorName, "tutor")).filter((c) => !c.is_admin);
        if (calling.length > 0) {
          setActiveCall(calling[0]);
          setCallStatus("calling");
        }
        const accepted = (await base44.entities.Call.filter({ tutor_name: tutorName, status: "accepted" })).filter((c) => !c.is_admin);
        if (accepted.length > 0) {
          setActiveCall(accepted[0]);
          setCallStatus("accepted");
        }
      } catch (e) {}
    };
    loadCalls();
    const interval = setInterval(loadCalls, 30000);
    const unsubscribe = base44.entities.Call.subscribe((event) => {
      if (!event.data || event.data.tutor_name !== tutorName) return;
      if (event.data.is_admin) return;
      if (event.type === "create" && event.data.status === "calling") {
        setActiveCall(event.data);
        setCallStatus("calling");
      } else if (event.type === "update") {
        if (event.data.status === "accepted") {
          setActiveCall(event.data);
          setCallStatus("accepted");
        } else if (event.data.status === "declined") {
          setActiveCall(null);
          setCallStatus("declined");
          setTimeout(() => setCallStatus(null), 3000);
        }
      } else if (event.type === "delete") {
        setActiveCall(null);
        setCallStatus(null);
      }
    });
    return () => {clearInterval(interval);if (typeof unsubscribe === 'function') unsubscribe();};
  }, [tutorName]);

  const handleCall = async (student) => {
    const meetingLink = generateMeetLink();
    try {
      const call = await base44.entities.Call.create({
        tutor_name: tutorName,
        student_name: student.name,
        status: "calling",
        meeting_link: meetingLink
      });
      setActiveCall(call);
      setCallStatus("calling");
    } catch (e) {
      console.error("Failed to create call:", e);
    }
  };

  const handleCancelCall = async () => {
    if (!activeCall) return;
    try {
      await base44.entities.Call.update(activeCall.id, { status: "declined" });
      setActiveCall(null);
      setCallStatus(null);
    } catch (e) {}
  };

  const handleJoinMeeting = () => {
    if (activeCall?.meeting_link) {
      window.open(activeCall.meeting_link, "_blank");
    }
  };

  return (
    <div data-source-location="src/pages/TutorStudents.jsx:92:4" data-dynamic-content="true" className="min-h-screen font-body relative z-10">
      <nav data-source-location="src/pages/TutorStudents.jsx:93:6" data-dynamic-content="true" className="bg-card/80 backdrop-blur-md border-b border-border px-6 py-4 flex items-center gap-4">
        <Link data-source-location="src/pages/TutorStudents.jsx:94:8" data-dynamic-content="false" to="/tutor-dashboard" className="text-muted-foreground hover:text-foreground"><ArrowLeft data-source-location="src/pages/TutorStudents.jsx:94:92" data-dynamic-content="false" className="w-5 h-5" /></Link>
        <div data-source-location="src/pages/TutorStudents.jsx:95:8" data-dynamic-content="true">
          <h1 data-source-location="src/pages/TutorStudents.jsx:96:10" data-dynamic-content="false" className="font-heading font-bold text-foreground text-lg">My Students</h1>
          <p data-source-location="src/pages/TutorStudents.jsx:97:10" data-dynamic-content="true" className="text-xs text-muted-foreground">{students.length} connected student{students.length !== 1 ? "s" : ""}</p>
        </div>
      </nav>

      <div data-source-location="src/pages/TutorStudents.jsx:101:6" data-dynamic-content="true" className="max-w-3xl mx-auto px-6 py-8">
        <AdminNotifications data-source-location="src/pages/TutorStudents.jsx:102:8" data-dynamic-content="true" userName={tutorName} />
        {/* Call status banner */}
        {callStatus === "calling" && activeCall &&
        <motion.div data-source-location="src/pages/TutorStudents.jsx:105:10" data-dynamic-content="true" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
        className="bg-primary text-primary-foreground rounded-2xl p-4 flex items-center justify-between mb-4">
            <div data-source-location="src/pages/TutorStudents.jsx:107:12" data-dynamic-content="true" className="flex items-center gap-3">
              <div data-source-location="src/pages/TutorStudents.jsx:108:14" data-dynamic-content="false" className="relative">
                <div data-source-location="src/pages/TutorStudents.jsx:109:16" data-dynamic-content="false" className="w-10 h-10 rounded-full bg-primary-foreground/20 flex items-center justify-center">
                  <Clock data-source-location="src/pages/TutorStudents.jsx:110:18" data-dynamic-content="false" className="w-5 h-5" />
                </div>
                <span data-source-location="src/pages/TutorStudents.jsx:112:16" data-dynamic-content="false" className="absolute inset-0 rounded-full animate-ping bg-primary-foreground/30" />
              </div>
              <div data-source-location="src/pages/TutorStudents.jsx:114:14" data-dynamic-content="true">
                <p data-source-location="src/pages/TutorStudents.jsx:115:16" data-dynamic-content="true" className="font-semibold text-sm" data-collection-item-field="student_name" data-collection-item-id={activeCall?.id || activeCall?._id}>Calling {activeCall.student_name}...</p>
                <p data-source-location="src/pages/TutorStudents.jsx:116:16" data-dynamic-content="false" className="text-xs opacity-80">Waiting for them to accept</p>
              </div>
            </div>
            <button data-source-location="src/pages/TutorStudents.jsx:119:12" data-dynamic-content="true" onClick={handleCancelCall}
          className="px-3 py-1.5 rounded-lg bg-red-500 text-white text-xs font-semibold hover:bg-red-600 transition-colors flex items-center gap-1">
              <PhoneOff data-source-location="src/pages/TutorStudents.jsx:121:14" data-dynamic-content="false" className="w-3.5 h-3.5" /> Cancel
            </button>
          </motion.div>
        }
        {callStatus === "accepted" && activeCall &&
        <motion.div data-source-location="src/pages/TutorStudents.jsx:126:10" data-dynamic-content="true" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
        className="bg-green-600 text-white rounded-2xl p-4 flex items-center justify-between mb-4">
            <div data-source-location="src/pages/TutorStudents.jsx:128:12" data-dynamic-content="true" className="flex items-center gap-3">
              <div data-source-location="src/pages/TutorStudents.jsx:129:14" data-dynamic-content="false" className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <Video data-source-location="src/pages/TutorStudents.jsx:130:16" data-dynamic-content="false" className="w-5 h-5" />
              </div>
              <div data-source-location="src/pages/TutorStudents.jsx:132:14" data-dynamic-content="true">
                <p data-source-location="src/pages/TutorStudents.jsx:133:16" data-dynamic-content="true" className="font-semibold text-sm" data-collection-item-field="student_name" data-collection-item-id={activeCall?.id || activeCall?._id}>{activeCall.student_name} accepted your call</p>
                <p data-source-location="src/pages/TutorStudents.jsx:134:16" data-dynamic-content="false" className="text-xs opacity-80">Join the Google Meet now</p>
              </div>
            </div>
            <button data-source-location="src/pages/TutorStudents.jsx:137:12" data-dynamic-content="true" onClick={handleJoinMeeting}
          className="px-3 py-1.5 rounded-lg bg-white text-green-600 text-xs font-semibold hover:bg-white/90 transition-colors flex items-center gap-1">
              <Video data-source-location="src/pages/TutorStudents.jsx:139:14" data-dynamic-content="false" className="w-3.5 h-3.5" /> Join Meeting
            </button>
          </motion.div>
        }
        {callStatus === "declined" &&
        <motion.div data-source-location="src/pages/TutorStudents.jsx:144:10" data-dynamic-content="true" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
        className="bg-red-500 text-white rounded-2xl p-4 mb-4 text-center text-sm font-semibold">
            Call was declined
          </motion.div>
        }

        {students.length === 0 ?
        <div data-source-location="src/pages/TutorStudents.jsx:151:10" data-dynamic-content="false" className="text-center py-20">
            <p data-source-location="src/pages/TutorStudents.jsx:152:12" data-dynamic-content="false" className="text-xl font-semibold text-foreground mb-2">No students yet</p>
            <p data-source-location="src/pages/TutorStudents.jsx:153:12" data-dynamic-content="false" className="text-muted-foreground mb-6">Find students to connect with and start tutoring.</p>
            <Link data-source-location="src/pages/TutorStudents.jsx:154:12" data-dynamic-content="false" to="/find-students" className="inline-flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 transition-colors">
              Find Students
            </Link>
          </div> :

        <div data-source-location="src/pages/TutorStudents.jsx:159:10" data-dynamic-content="true" className="space-y-3">
            {students.map((s, i) =>
          <motion.div data-source-location="src/pages/TutorStudents.jsx:161:14" data-dynamic-content="true" key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
          className="bg-card border border-border rounded-2xl p-5">
                <div data-source-location="src/pages/TutorStudents.jsx:163:16" data-dynamic-content="true" className="flex items-center gap-4 mb-4">
                  <div data-source-location="src/pages/TutorStudents.jsx:164:18" data-dynamic-content="true" className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center font-bold text-primary font-heading text-sm">
                    {s.name.split(" ").map((n) => n[0]).join("")}
                  </div>
                  <div data-source-location="src/pages/TutorStudents.jsx:167:18" data-dynamic-content="true" className="flex-1 min-w-0" data-collection-item-field="email" data-collection-item-id={s?.id || s?._id}>
                    <p data-source-location="src/pages/TutorStudents.jsx:168:20" data-dynamic-content="true" className="font-semibold text-foreground" data-collection-item-field="name" data-collection-item-id={s?.id || s?._id}>{s.name}</p>
                    {s.email && <p data-source-location="src/pages/TutorStudents.jsx:169:32" data-dynamic-content="true" className="text-xs text-muted-foreground flex items-center gap-1" data-collection-item-field="email" data-collection-item-id={s?.id || s?._id}><Mail data-source-location="src/pages/TutorStudents.jsx:169:101" data-dynamic-content="false" className="w-3 h-3" />{s.email}</p>}
                    <p data-source-location="src/pages/TutorStudents.jsx:170:20" data-dynamic-content="true" className="text-xs text-muted-foreground" data-collection-item-field="grade" data-collection-item-id={s?.id || s?._id}>{s.grade} Grade</p>
                    {s.subjects?.length > 0 &&
                <div data-source-location="src/pages/TutorStudents.jsx:172:22" data-dynamic-content="true" className="flex flex-wrap gap-1 mt-1">
                        {s.subjects.slice(0, 3).map((sub) =>
                  <span data-source-location="src/pages/TutorStudents.jsx:174:26" data-dynamic-content="true" key={sub} className="px-1.5 py-0.5 bg-secondary text-secondary-foreground text-[10px] rounded font-medium" data-collection-item-field="sub">{sub}</span>
                  )}
                      </div>
                }
                  </div>
                </div>

                {/* Action buttons */}
                <div data-source-location="src/pages/TutorStudents.jsx:182:16" data-dynamic-content="true" className="flex gap-2">
                  <button data-source-location="src/pages/TutorStudents.jsx:183:18" data-dynamic-content="true" onClick={() => handleCall(s)}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-green-50 text-green-700 border border-green-200 text-xs font-semibold hover:bg-green-100 transition-colors">
                    <Video data-source-location="src/pages/TutorStudents.jsx:185:20" data-dynamic-content="false" className="w-3.5 h-3.5" /> Call
                  </button>
                  <Link data-source-location="src/pages/TutorStudents.jsx:187:18" data-dynamic-content="true" to={`/chat?name=${encodeURIComponent(s.name)}&back=/tutor-students`}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-primary/10 text-primary border border-primary/20 text-xs font-semibold hover:bg-primary/20 transition-colors">
                    <MessageCircle data-source-location="src/pages/TutorStudents.jsx:189:20" data-dynamic-content="false" className="w-3.5 h-3.5" /> Message
                  </Link>
                  <Link data-source-location="src/pages/TutorStudents.jsx:191:18" data-dynamic-content="true" to={`/assign-homework?student=${encodeURIComponent(s.name)}`}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-secondary text-secondary-foreground border border-border text-xs font-semibold hover:bg-muted transition-colors">
                    <BookOpen data-source-location="src/pages/TutorStudents.jsx:193:20" data-dynamic-content="false" className="w-3.5 h-3.5" /> Assign HW
                  </Link>
                </div>
              </motion.div>
          )}
          </div>
        }
      </div>
    </div>);

}