import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { GraduationCap, Users, Check, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import TagSearchInput from "@/components/TagSearchInput";
import AvatarCreator from "@/components/AvatarCreator";
import { base44 } from "@/api/base44Client";
import Logo from "@/components/Logo";

// --- Suggestion lists ---
const INTEREST_SUGGESTIONS = [
"Reading", "Writing", "Drawing", "Painting", "Music", "Guitar", "Piano", "Singing",
"Dancing", "Sports", "Soccer", "Basketball", "Baseball", "Swimming", "Running",
"Hiking", "Cooking", "Baking", "Photography", "Film & Movies", "Video Games",
"Coding", "Robotics", "3D Printing", "Animation", "Graphic Design", "Fashion",
"Travel", "Languages", "History", "Politics", "Philosophy", "Psychology",
"Biology", "Chemistry", "Physics", "Astronomy", "Mathematics", "Economics",
"Business", "Entrepreneurship", "Investing", "Environment", "Volunteering",
"Social Media", "Podcasts", "Fitness", "Yoga", "Meditation", "Chess", "Debate"];


const SUBJECT_SUGGESTIONS = [
// Math
"Pre-Algebra", "Algebra I", "Algebra II", "Geometry", "Pre-Calculus",
"Calculus AB", "Calculus BC", "Multivariable Calculus", "Statistics", "AP Statistics",
"Trigonometry", "Linear Algebra", "Discrete Math", "Number Theory", "Probability",
"Math Competition Prep (AMC/AIME)", "SAT Math", "ACT Math",
// Science
"Biology", "AP Biology", "Honors Biology", "Microbiology", "Genetics",
"Chemistry", "AP Chemistry", "Honors Chemistry", "Organic Chemistry",
"Physics", "AP Physics 1", "AP Physics 2", "AP Physics C: Mechanics",
"AP Physics C: E&M", "Honors Physics",
"Earth Science", "Environmental Science", "AP Environmental Science",
"Anatomy & Physiology", "Astronomy", "Marine Biology",
// English & Writing
"English", "Reading Comprehension", "Essay Writing", "Grammar", "Vocabulary",
"Literature", "American Literature", "British Literature", "World Literature",
"Creative Writing", "Expository Writing", "Research Papers",
"AP English Language & Composition", "AP English Literature & Composition",
"SAT Reading & Writing", "ACT English",
// History & Social Studies
"World History", "AP World History", "Ancient History",
"US History", "AP US History", "US Government", "AP Government & Politics",
"Economics", "AP Macroeconomics", "AP Microeconomics",
"Geography", "Sociology", "AP Psychology", "Philosophy",
"European History", "AP European History",
// Languages
"Spanish (Beginner)", "Spanish (Intermediate)", "Spanish (Advanced)", "AP Spanish",
"French (Beginner)", "French (Intermediate)", "AP French",
"German", "AP German", "Mandarin Chinese", "AP Chinese",
"Japanese", "Italian", "Latin", "Portuguese", "Arabic", "Korean",
// Computer Science & Tech
"Computer Science", "AP Computer Science A", "AP Computer Science Principles",
"Python", "Java", "JavaScript", "Web Development", "Data Science",
"Algorithms", "Data Structures", "Cybersecurity",
// Arts & Music
"Music Theory", "AP Music Theory", "Art History", "AP Art History",
// Test Prep
"SAT Prep", "ACT Prep", "PSAT Prep", "GRE Prep", "GMAT Prep",
"LSAT Prep", "MCAT Prep",
// Extracurriculars & Coaching
"Swimming", "Playing an instrument (Piano, Guitar, Violin)", "Martial arts",
"Singing and vocal training", "Dance", "Tennis and golf coaching"];


// --- Step definitions ---
const roleStep = {
  id: "role",
  title: "I am a...",
  description: "Let's get you started with a personalized experience",
  options: ["Student", "Tutor"]
};

const avatarStep = {
  id: "avatar",
  title: "Create your profile",
  description: "Upload a photo or build your own character",
  type: "avatar"
};

const personalInfoSteps = [
{ id: "name", title: "What's your name?", type: "input" },
{ id: "bio", title: "Write a short bio", description: "Tell others a bit about yourself (optional)", type: "textarea" },
{ id: "interests", title: "What are your interests?", description: "Search and add as many as you like", type: "tags", suggestions: INTEREST_SUGGESTIONS, placeholder: "e.g. Music, Coding, Sports..." }];


const studentFlow = [
...personalInfoSteps,
{ id: "grade", title: "What grade are you in?", options: ["6th", "7th", "8th", "9th", "10th", "11th", "12th", "College"] },
{ id: "subjects", title: "What subjects do you want help with?", description: "Search and add your subjects", type: "tags", suggestions: SUBJECT_SUGGESTIONS, placeholder: "e.g. Algebra II, AP Biology..." },
{ id: "improve", title: "What are you trying to improve?", options: ["Grades", "Understanding", "Test performance", "Confidence"], multiSelect: true },
{ id: "learnStyle", title: "How do you prefer to learn?", options: ["Step-by-step help", "Practice problems", "Examples first", "Mixed approach"] },
avatarStep];


const tutorFlow = [
...personalInfoSteps,
{ id: "grade", title: "What grade are you in?", options: ["6th", "7th", "8th", "9th", "10th", "11th", "12th", "College"] },
{ id: "tutorGrade", title: "What grade level do you teach?", options: ["Pre-K", "Kindergarten", "1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th", "9th", "10th", "11th", "12th", "College & Up"], multiSelect: true },
{ id: "tutorSubjects", title: "What subjects can you teach?", description: "Search and add your subjects", type: "tags", suggestions: SUBJECT_SUGGESTIONS, placeholder: "e.g. Calculus BC, AP Chemistry..." },
{ id: "tutored", title: "Have you tutored before?", options: ["Yes", "No"] },
{ id: "teachStyle", title: "How do you prefer to teach?", options: ["Explain concepts", "Work through problems", "Mixed approach"] },
{ id: "strengths", title: "What are your strengths?", options: ["Explaining ideas", "Helping struggling students", "Test prep", "Advanced content"], multiSelect: true },
{ id: "pricing", title: "What's your hourly rate?", description: "Set a fixed price or offer flexible pricing", type: "pricing" },
avatarStep];


export default function Questionnaire() {
  const [userData, setUserData] = useState({});
  const [currentFlow, setCurrentFlow] = useState(null);
  const [step, setStep] = useState(0);

  const allSteps = currentFlow ? [roleStep, ...currentFlow] : [roleStep];
  const currentStep = allSteps[step];
  const totalSteps = allSteps.length;

  const handleRoleSelect = (role) => {
    setUserData({ role });
    setCurrentFlow(role === "Student" ? studentFlow : tutorFlow);
  };

  const handleNext = async () => {
    if (step < totalSteps - 1) {
      setStep((prev) => prev + 1);
    } else {
      let avatarData = userData.avatar;
      if (avatarData?.dataUrl?.startsWith("data:")) {
        try {
          const [meta, base64] = avatarData.dataUrl.split(",");
          const mime = meta.match(/:(.*?);/)?.[1] || "image/png";
          const bytes = atob(base64);
          const arr = new Uint8Array(bytes.length);
          for (let i = 0; i < bytes.length; i++) arr[i] = bytes.charCodeAt(i);
          const file = new File([arr], "avatar.png", { type: mime });
          const { file_url } = await base44.integrations.Core.UploadFile({ file });
          avatarData = { type: avatarData.type, url: file_url, config: avatarData.config, state: avatarData.state };
        } catch (err) {
          console.error("Avatar upload failed:", err);
        }
      }
      sessionStorage.setItem("onboardingData", JSON.stringify({ ...userData, avatar: avatarData }));
      let myEmail = "";
      try {
        const me = await base44.auth.me();
        myEmail = me.email || "";
      } catch (e2) {}
      try {
        const profile = await base44.entities.Profile.create({
          full_name: userData.name,
          role: (userData.role || "").toLowerCase(),
          email: myEmail,
          grade: userData.grade || "",
          subjects: userData.subjects || [],
          interests: userData.interests || [],
          bio: userData.bio || "",
          learn_style: userData.learnStyle || "",
          teach_style: userData.teachStyle || "",
          tutored: userData.tutored || "",
          improve: userData.improve || [],
          strengths: userData.strengths || [],
          tutor_grade: userData.tutorGrade || [],
          tutor_subjects: userData.tutorSubjects || [],
          pricing: userData.pricing || null,
          avatar: avatarData || null
        });
        if (profile?.id) sessionStorage.setItem("profileId", profile.id);
      } catch (e) {
        console.error("Profile save failed:", e);
      }
      const dest = userData.role === "Student" ? "/student-dashboard" : "/tutor-dashboard";
      window.location.href = dest;
    }
  };

  const handleBack = () => {
    if (step > 0) setStep((prev) => prev - 1);
  };

  const handleOptionClick = (option) => {
    if (currentStep.id === "role") {handleRoleSelect(option);return;}
    if (currentStep.multiSelect) {
      const current = userData[currentStep.id] || [];
      const updated = current.includes(option) ? current.filter((o) => o !== option) : [...current, option];
      setUserData((prev) => ({ ...prev, [currentStep.id]: updated }));
    } else {
      setUserData((prev) => ({ ...prev, [currentStep.id]: option }));
    }
  };

  const canProceed = () => {
    if (currentStep.id === "role") return !!userData.role;
    if (currentStep.type === "avatar") return true; // optional, always allow
    if (currentStep.type === "pricing") {
      const v = userData[currentStep.id];
      if (!v) return false;
      if (v.flexible) return !!v.flexibleNote?.trim();
      return !!v.price?.trim();
    }
    const value = userData[currentStep.id];
    if (currentStep.type === "input") return typeof value === "string" && value.trim().length > 0;
    if (currentStep.type === "textarea") return true; // optional
    if (currentStep.type === "tags") return Array.isArray(value) && value.length > 0;
    if (currentStep.multiSelect) return Array.isArray(value) && value.length > 0;
    return !!value;
  };

  const currentValue = userData[currentStep.id];

  return (
    <div data-source-location="src/pages/Questionnaire.jsx:212:4" data-dynamic-content="true" className="min-h-screen flex items-center justify-center p-4 relative z-10">
      <motion.div data-source-location="src/pages/Questionnaire.jsx:213:6" data-dynamic-content="true" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-2xl">
        {/* Progress */}
        <div data-source-location="src/pages/Questionnaire.jsx:215:8" data-dynamic-content="true" className="mb-8">
          <div data-source-location="src/pages/Questionnaire.jsx:216:10" data-dynamic-content="true" className="flex items-center justify-between mb-3">
            <Logo data-source-location="src/pages/Questionnaire.jsx:217:12" data-dynamic-content="false" height={16} />
            <span data-source-location="src/pages/Questionnaire.jsx:218:12" data-dynamic-content="true" className="text-sm text-foreground/50 font-medium" data-collection-item-field="totalSteps">Step {step + 1} of {totalSteps}</span>
          </div>
          <div data-source-location="src/pages/Questionnaire.jsx:220:10" data-dynamic-content="true" className="h-2 bg-muted/50 rounded-full overflow-hidden">
            <motion.div data-source-location="src/pages/Questionnaire.jsx:221:12" data-dynamic-content="true" className="h-full bg-primary" initial={{ width: 0 }}
            animate={{ width: `${(step + 1) / totalSteps * 100}%` }} transition={{ duration: 0.3 }} />
          </div>
        </div>

        <AnimatePresence data-source-location="src/pages/Questionnaire.jsx:226:8" data-dynamic-content="true" mode="wait">
          <motion.div data-source-location="src/pages/Questionnaire.jsx:227:10" data-dynamic-content="true" key={step} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.2 }}>
            <Card data-source-location="src/pages/Questionnaire.jsx:229:12" data-dynamic-content="true" className="p-8 shadow-lg border border-border bg-muted/50 backdrop-blur-md text-foreground">
              <div data-source-location="src/pages/Questionnaire.jsx:230:14" data-dynamic-content="true" className="mb-8" data-collection-item-field="description" data-collection-item-id={currentStep?.id || currentStep?._id}>
                <h2 data-source-location="src/pages/Questionnaire.jsx:231:16" data-dynamic-content="true" className="text-2xl font-heading font-bold text-foreground mb-2" data-collection-item-field="title" data-collection-item-id={currentStep?.id || currentStep?._id}>{currentStep.title}</h2>
                {currentStep.description && <p data-source-location="src/pages/Questionnaire.jsx:232:44" data-dynamic-content="true" className="text-foreground/60 font-body" data-collection-item-field="description" data-collection-item-id={currentStep?.id || currentStep?._id}>{currentStep.description}</p>}
              </div>

              <div data-source-location="src/pages/Questionnaire.jsx:235:14" data-dynamic-content="true" className="space-y-4 mb-8">
                {/* Single select options */}
                {currentStep.options && !currentStep.multiSelect &&
                <div data-source-location="src/pages/Questionnaire.jsx:238:18" data-dynamic-content="true" className="grid grid-cols-1 sm:grid-cols-2 gap-3" data-collection-item-field="options" data-collection-item-id={currentStep?.id || currentStep?._id}>
                    {currentStep.options.map((option) => {
                    const isSelected = currentValue === option;
                    return (
                      <motion.button data-source-location="src/pages/Questionnaire.jsx:242:24" data-dynamic-content="true" key={option} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                      onClick={() => handleOptionClick(option)}
                      className={`p-4 rounded-xl border-2 text-left font-medium transition-all font-body ${isSelected ? "border-primary bg-primary text-primary-foreground" : "border-border hover:border-primary/50 text-foreground"}`}>
                          <div data-source-location="src/pages/Questionnaire.jsx:245:26" data-dynamic-content="true" className="flex items-center gap-3">
                            {option === "Student" && <Users data-source-location="src/pages/Questionnaire.jsx:246:53" data-dynamic-content="false" className="w-5 h-5" />}
                            {option === "Tutor" && <GraduationCap data-source-location="src/pages/Questionnaire.jsx:247:51" data-dynamic-content="false" className="w-5 h-5" />}
                            <span data-source-location="src/pages/Questionnaire.jsx:248:28" data-dynamic-content="true" data-collection-item-field="option">{option}</span>
                          </div>
                        </motion.button>);

                  })}
                  </div>
                }

                {/* Multi select */}
                {currentStep.options && currentStep.multiSelect &&
                <div data-source-location="src/pages/Questionnaire.jsx:258:18" data-dynamic-content="true" className="grid grid-cols-1 sm:grid-cols-2 gap-3" data-collection-item-field="options" data-collection-item-id={currentStep?.id || currentStep?._id}>
                    {currentStep.options.map((option) => {
                    const selected = currentValue || [];
                    const isSelected = selected.includes(option);
                    return (
                      <motion.button data-source-location="src/pages/Questionnaire.jsx:263:24" data-dynamic-content="true" key={option} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                      onClick={() => handleOptionClick(option)}
                      className={`p-4 rounded-xl border-2 text-left font-medium transition-all font-body ${isSelected ? "border-primary bg-primary text-primary-foreground" : "border-border hover:border-primary/50 text-foreground"}`} data-collection-item-field="option">
                          {option}
                        </motion.button>);

                  })}
                  </div>
                }

                {/* Plain text input */}
                {currentStep.type === "input" &&
                <Input data-source-location="src/pages/Questionnaire.jsx:275:18" data-dynamic-content="true" value={currentValue || ""}
                onChange={(e) => setUserData((prev) => ({ ...prev, [currentStep.id]: e.target.value }))}
                placeholder="Type your answer..."
                className="w-full px-4 py-6 border-2 border-border rounded-xl focus:border-primary focus-visible:ring-0 text-foreground bg-muted/50 placeholder:text-foreground/40" />
                }

                {/* Textarea */}
                {currentStep.type === "textarea" &&
                <textarea data-source-location="src/pages/Questionnaire.jsx:283:18" data-dynamic-content="true" value={currentValue || ""}
                onChange={(e) => setUserData((prev) => ({ ...prev, [currentStep.id]: e.target.value }))}
                placeholder="e.g. I'm a junior who loves math competitions and helping others understand difficult concepts..."
                rows={4}
                className="w-full px-4 py-3 border-2 border-border rounded-xl focus:border-primary focus:outline-none resize-none font-body text-sm text-foreground bg-muted/50 placeholder:text-foreground/40" />
                }

                {/* Tag search input */}
                {currentStep.type === "tags" &&
                <TagSearchInput data-source-location="src/pages/Questionnaire.jsx:292:18" data-dynamic-content="true"
                suggestions={currentStep.suggestions}
                value={currentValue || []}
                onChange={(tags) => setUserData((prev) => ({ ...prev, [currentStep.id]: tags }))}
                placeholder={currentStep.placeholder} />

                }

                {/* Avatar creator */}
                {currentStep.type === "avatar" &&
                <AvatarCreator data-source-location="src/pages/Questionnaire.jsx:302:18" data-dynamic-content="true"
                value={currentValue}
                name={userData.name}
                onChange={(val) => setUserData((prev) => ({ ...prev, avatar: val }))} />

                }

                {/* Pricing step */}
                {currentStep.type === "pricing" &&
                <div data-source-location="src/pages/Questionnaire.jsx:311:18" data-dynamic-content="true" className="space-y-4">
                    <div data-source-location="src/pages/Questionnaire.jsx:312:20" data-dynamic-content="true"
                  className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${!userData[currentStep.id]?.flexible ? "border-primary bg-primary/5" : "border-border"}`}
                  onClick={() => setUserData((prev) => ({ ...prev, [currentStep.id]: { flexible: false, price: prev[currentStep.id]?.price || "" } }))}>
                      <div data-source-location="src/pages/Questionnaire.jsx:315:22" data-dynamic-content="true" className="flex items-center gap-3 mb-2">
                        <div data-source-location="src/pages/Questionnaire.jsx:316:24" data-dynamic-content="true" className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${!userData[currentStep.id]?.flexible ? "border-primary bg-primary" : "border-border"}`}>
                          {!userData[currentStep.id]?.flexible && <div data-source-location="src/pages/Questionnaire.jsx:317:66" data-dynamic-content="false" className="w-2 h-2 rounded-full bg-primary-foreground" />}
                        </div>
                        <span data-source-location="src/pages/Questionnaire.jsx:319:24" data-dynamic-content="false" className="font-medium text-sm text-foreground">Fixed Rate</span>
                      </div>
                      {!userData[currentStep.id]?.flexible &&
                    <div data-source-location="src/pages/Questionnaire.jsx:322:24" data-dynamic-content="true" className="flex items-center gap-2 pl-8">
                          <span data-source-location="src/pages/Questionnaire.jsx:323:26" data-dynamic-content="false" className="text-lg font-semibold text-foreground">$</span>
                          <input data-source-location="src/pages/Questionnaire.jsx:324:26" data-dynamic-content="true" type="number" value={userData[currentStep.id]?.price || ""}
                      onChange={(e) => setUserData((prev) => ({ ...prev, [currentStep.id]: { flexible: false, price: e.target.value } }))}
                      placeholder="28" className="w-24 px-3 py-2 border-2 border-border rounded-lg text-sm focus:border-primary focus:outline-none text-foreground bg-muted/50" />
                          <span data-source-location="src/pages/Questionnaire.jsx:327:26" data-dynamic-content="false" className="text-sm text-foreground/50">/hour</span>
                        </div>
                    }
                    </div>
                    <div data-source-location="src/pages/Questionnaire.jsx:331:20" data-dynamic-content="true"
                  className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${userData[currentStep.id]?.flexible ? "border-primary bg-primary/5" : "border-border"}`}
                  onClick={() => setUserData((prev) => ({ ...prev, [currentStep.id]: { flexible: true, flexibleNote: prev[currentStep.id]?.flexibleNote || "" } }))} data-collection-item-field="flexible" data-collection-item-id={userData?.id || userData?._id}>
                      <div data-source-location="src/pages/Questionnaire.jsx:334:22" data-dynamic-content="true" className="flex items-center gap-3 mb-2">
                        <div data-source-location="src/pages/Questionnaire.jsx:335:24" data-dynamic-content="true" className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${userData[currentStep.id]?.flexible ? "border-primary bg-primary" : "border-border"}`} data-collection-item-field="flexible" data-collection-item-id={userData?.id || userData?._id}>
                          {userData[currentStep.id]?.flexible && <div data-source-location="src/pages/Questionnaire.jsx:336:65" data-dynamic-content="false" className="w-2 h-2 rounded-full bg-primary-foreground" />}
                        </div>
                        <span data-source-location="src/pages/Questionnaire.jsx:338:24" data-dynamic-content="false" className="font-medium text-sm text-foreground">Flexible Pricing</span>
                      </div>
                      {userData[currentStep.id]?.flexible &&
                    <textarea data-source-location="src/pages/Questionnaire.jsx:341:24" data-dynamic-content="true" value={userData[currentStep.id]?.flexibleNote || ""}
                    onChange={(e) => setUserData((prev) => ({ ...prev, [currentStep.id]: { flexible: true, flexibleNote: e.target.value } }))}
                    placeholder="Explain your pricing (e.g. 'I charge based on the subject and session length')..."
                    rows={3}
                    className="w-full ml-8 px-3 py-2 border-2 border-border rounded-lg text-sm focus:border-primary focus:outline-none resize-none text-foreground bg-muted/50"
                    onClick={(e) => e.stopPropagation()} />
                    }
                    </div>
                  </div>
                }
              </div>

              <div data-source-location="src/pages/Questionnaire.jsx:353:14" data-dynamic-content="true" className="flex items-center gap-3">
                <Button data-source-location="src/pages/Questionnaire.jsx:354:16" data-dynamic-content="true" onClick={handleBack} disabled={step === 0} variant="outline"
                className="flex items-center gap-2 px-6 py-6 rounded-full border-border text-foreground">
                  <ChevronLeft data-source-location="src/pages/Questionnaire.jsx:356:18" data-dynamic-content="false" className="w-4 h-4" />
                  Back
                </Button>
                <Button data-source-location="src/pages/Questionnaire.jsx:359:16" data-dynamic-content="true" onClick={handleNext} disabled={!canProceed()}
                className="flex-1 flex items-center justify-center gap-2 px-6 py-6 rounded-full bg-primary hover:bg-primary/90 text-primary-foreground">
                  {step === totalSteps - 1 ? "Go to Dashboard" : "Next"}
                  {step === totalSteps - 1 ? <Check data-source-location="src/pages/Questionnaire.jsx:362:45" data-dynamic-content="false" className="w-4 h-4" /> : <ChevronRight data-source-location="src/pages/Questionnaire.jsx:362:77" data-dynamic-content="false" className="w-4 h-4" />}
                </Button>
              </div>
            </Card>
          </motion.div>
        </AnimatePresence>
      </motion.div>
    </div>);

}