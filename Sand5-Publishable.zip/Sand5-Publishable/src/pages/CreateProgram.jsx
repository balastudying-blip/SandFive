import { useState, useRef } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Upload, Mail, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { base44 } from "@/api/base44Client";

export default function CreateProgram() {
  const [subjectName, setSubjectName] = useState("");
  const [description, setDescription] = useState("");
  const [file, setFile] = useState(null);
  const [fileUrl, setFileUrl] = useState("");
  const [uploading, setUploading] = useState(false);
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");
  const fileRef = useRef(null);

  const handleFileChange = async (e) => {
    const selected = e.target.files?.[0];
    if (!selected) return;
    setFile(selected);
    setUploading(true);
    setError("");
    try {
      const res = await base44.integrations.Core.UploadFile({ file: selected });
      setFileUrl(res.file_url);
    } catch (err) {
      setError("File upload failed. Please try again.");
    }
    setUploading(false);
  };

  const handleSendEmail = async () => {
    if (!subjectName.trim() || !description.trim()) {
      setError("Please fill in the subject name and description.");
      return;
    }
    setSending(true);
    setError("");
    try {
      const body = `A new program has been created.\n\nSubject: ${subjectName}\n\nDescription:\n${description}${fileUrl ? `\n\nAttached file: ${fileUrl}` : ""}`;
      await base44.integrations.Core.SendEmail({
        to: "jayakrishna.arvapalli29@gmail.com",
        subject: `New Program: ${subjectName}`,
        body: body
      });
      setSent(true);
    } catch (err) {
      setError(err.message || "Failed to send email. Please try again.");
    }
    setSending(false);
  };

  if (sent) {
    return (
      <div data-source-location="src/pages/CreateProgram.jsx:57:6" data-dynamic-content="false" className="min-h-screen flex items-center justify-center p-4 font-body relative z-10">
        <div data-source-location="src/pages/CreateProgram.jsx:58:8" data-dynamic-content="false" className="w-full max-w-md text-center">
          <div data-source-location="src/pages/CreateProgram.jsx:59:10" data-dynamic-content="false" className="bg-card/60 backdrop-blur-xl border border-border rounded-2xl p-8 shadow-lg">
            <CheckCircle data-source-location="src/pages/CreateProgram.jsx:60:12" data-dynamic-content="false" className="w-16 h-16 text-primary mx-auto mb-4" />
            <h2 data-source-location="src/pages/CreateProgram.jsx:61:12" data-dynamic-content="false" className="text-2xl font-heading font-bold text-foreground mb-2">Program Sent!</h2>
            <p data-source-location="src/pages/CreateProgram.jsx:62:12" data-dynamic-content="false" className="text-muted-foreground mb-6">Your program details have been emailed successfully.</p>
            <Link data-source-location="src/pages/CreateProgram.jsx:63:12" data-dynamic-content="false" to="/tutor-dashboard">
              <Button data-source-location="src/pages/CreateProgram.jsx:64:14" data-dynamic-content="false" className="w-full h-11 bg-primary hover:bg-primary/90 text-primary-foreground">
                Back to Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </div>);

  }

  return (
    <div data-source-location="src/pages/CreateProgram.jsx:75:4" data-dynamic-content="true" className="min-h-screen font-body relative z-10">
      <nav data-source-location="src/pages/CreateProgram.jsx:76:6" data-dynamic-content="false" className="bg-card/80 backdrop-blur-md border-b border-border px-6 py-4 flex items-center gap-4">
        <Link data-source-location="src/pages/CreateProgram.jsx:77:8" data-dynamic-content="false" to="/tutor-dashboard" className="text-muted-foreground hover:text-foreground">
          <ArrowLeft data-source-location="src/pages/CreateProgram.jsx:78:10" data-dynamic-content="false" className="w-5 h-5" />
        </Link>
        <h1 data-source-location="src/pages/CreateProgram.jsx:80:8" data-dynamic-content="false" className="text-lg font-heading font-bold text-foreground">Create New Program</h1>
      </nav>

      <div data-source-location="src/pages/CreateProgram.jsx:83:6" data-dynamic-content="true" className="max-w-2xl mx-auto p-6">
        <div data-source-location="src/pages/CreateProgram.jsx:84:8" data-dynamic-content="true" className="bg-card/60 backdrop-blur-xl border border-border rounded-2xl p-6 shadow-lg space-y-5">
          <div data-source-location="src/pages/CreateProgram.jsx:85:10" data-dynamic-content="true">
            <label data-source-location="src/pages/CreateProgram.jsx:86:12" data-dynamic-content="false" className="block text-sm font-medium text-foreground mb-1.5">Subject Name</label>
            <Input data-source-location="src/pages/CreateProgram.jsx:87:12" data-dynamic-content="true" value={subjectName} onChange={(e) => setSubjectName(e.target.value)}
            placeholder="e.g. AP Calculus AB Prep Course"
            className="h-11 text-foreground bg-muted/50 border-border placeholder:text-muted-foreground/60" />
          </div>

          <div data-source-location="src/pages/CreateProgram.jsx:92:10" data-dynamic-content="true">
            <label data-source-location="src/pages/CreateProgram.jsx:93:12" data-dynamic-content="false" className="block text-sm font-medium text-foreground mb-1.5">Description</label>
            <textarea data-source-location="src/pages/CreateProgram.jsx:94:12" data-dynamic-content="true" value={description} onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe the program, what students will learn, duration, etc."
            rows={5}
            className="w-full px-4 py-3 border border-border rounded-xl focus:border-primary focus:outline-none resize-none text-sm text-foreground bg-muted/50 placeholder:text-muted-foreground/60" />
          </div>

          <div data-source-location="src/pages/CreateProgram.jsx:100:10" data-dynamic-content="true">
            <label data-source-location="src/pages/CreateProgram.jsx:101:12" data-dynamic-content="false" className="block text-sm font-medium text-foreground mb-1.5">Upload a File</label>
            <input data-source-location="src/pages/CreateProgram.jsx:102:12" data-dynamic-content="true" ref={fileRef} type="file" hidden onChange={handleFileChange} />
            <button data-source-location="src/pages/CreateProgram.jsx:103:12" data-dynamic-content="true" type="button" onClick={() => fileRef.current?.click()}
            className="w-full border-2 border-dashed border-border rounded-xl p-6 text-center hover:border-primary/50 transition-colors">
              {uploading ?
              <p data-source-location="src/pages/CreateProgram.jsx:106:16" data-dynamic-content="false" className="text-sm text-muted-foreground">Uploading...</p> :
              file ?
              <div data-source-location="src/pages/CreateProgram.jsx:108:16" data-dynamic-content="true" className="flex items-center justify-center gap-2 text-sm text-foreground" data-collection-item-field="name" data-collection-item-id={file?.id || file?._id}>
                  <CheckCircle data-source-location="src/pages/CreateProgram.jsx:109:18" data-dynamic-content="false" className="w-4 h-4 text-primary" />
                  {file.name}
                </div> :

              <div data-source-location="src/pages/CreateProgram.jsx:113:16" data-dynamic-content="false" className="flex flex-col items-center gap-2 text-muted-foreground">
                  <Upload data-source-location="src/pages/CreateProgram.jsx:114:18" data-dynamic-content="false" className="w-6 h-6" />
                  <span data-source-location="src/pages/CreateProgram.jsx:115:18" data-dynamic-content="false" className="text-sm">Click to upload a file</span>
                </div>
              }
            </button>
          </div>

          {error && <p data-source-location="src/pages/CreateProgram.jsx:121:20" data-dynamic-content="true" className="text-sm text-destructive bg-destructive/10 p-3 rounded-lg" data-collection-item-field="error">{error}</p>}

          <Button data-source-location="src/pages/CreateProgram.jsx:123:10" data-dynamic-content="true" onClick={handleSendEmail} disabled={sending || uploading || !subjectName.trim() || !description.trim()}
          className="w-full h-12 text-base bg-primary hover:bg-primary/90 text-primary-foreground flex items-center justify-center gap-2">
            <Mail data-source-location="src/pages/CreateProgram.jsx:125:12" data-dynamic-content="false" className="w-5 h-5" />
            {sending ? "Sending Email..." : "Send Email"}
          </Button>
        </div>
      </div>
    </div>);

}