import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

export default function AuthRedirect() {
  const [error, setError] = useState("");

  useEffect(() => {
    const redirect = async () => {
      try {
        const user = await base44.auth.me();
        if (user.role === "admin") {
          window.location.href = "/admin";
          return;
        }
        const profiles = await base44.entities.Profile.filter({ email: user.email });
        if (profiles.length > 0) {
          window.location.href = profiles[0].role === "tutor" ? "/tutor-dashboard" : "/student-dashboard";
        } else {
          window.location.href = "/questionnaire";
        }
      } catch (err) {
        setError("Failed to load profile. Redirecting...");
        setTimeout(() => {window.location.href = "/questionnaire";}, 2000);
      }
    };
    redirect();
  }, []);

  return (
    <div data-source-location="src/pages/AuthRedirect.jsx:30:4" data-dynamic-content="true" className="min-h-screen flex items-center justify-center relative z-10">
      <div data-source-location="src/pages/AuthRedirect.jsx:31:6" data-dynamic-content="true" className="text-center">
        <div data-source-location="src/pages/AuthRedirect.jsx:32:8" data-dynamic-content="false" className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin mx-auto mb-4"></div>
        <p data-source-location="src/pages/AuthRedirect.jsx:33:8" data-dynamic-content="true" className="text-muted-foreground">{error || "Loading your dashboard..."}</p>
      </div>
    </div>);

}