import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowLeft, MessageCircle, UserPlus, Star, CreditCard } from "lucide-react";
import ReviewsModal from "@/components/ReviewsModal";
import PaymentModal from "@/components/PaymentModal";
import { base44 } from "@/api/base44Client";
import { refreshMyTutors } from "@/lib/loadConnections";

export default function MyTutors() {
  const [reviewTutor, setReviewTutor] = useState(null);
  const [payTutor, setPayTutor] = useState(null);
  const [savedCard, setSavedCard] = useState(null);
  const myName = JSON.parse(sessionStorage.getItem("onboardingData") || "{}").name || "Me";
  const [tutors, setTutors] = useState(() => JSON.parse(sessionStorage.getItem("myTutors") || "[]"));

  useEffect(() => {
    refreshMyTutors(myName).then(setTutors);
  }, [myName]);

  useEffect(() => {
    const card = sessionStorage.getItem("savedCard");
    if (card) setSavedCard(JSON.parse(card));
    const profileId = sessionStorage.getItem("profileId");
    if (profileId) {
      base44.entities.Profile.get(profileId).then((p) => {
        if (p?.saved_card) {
          setSavedCard(p.saved_card);
          sessionStorage.setItem("savedCard", JSON.stringify(p.saved_card));
        }
      }).catch(() => {});
    }
  }, []);

  const getTutorRate = (tutor) => {
    if (tutor.pricing && !tutor.pricing.flexible && tutor.pricing.price) return parseFloat(tutor.pricing.price);
    return null;
  };

  const handleCardSaved = (cardInfo) => {
    setSavedCard(cardInfo);
    sessionStorage.setItem("savedCard", JSON.stringify(cardInfo));
    const profileId = sessionStorage.getItem("profileId");
    if (profileId) {
      base44.entities.Profile.update(profileId, { saved_card: cardInfo }).catch(() => {});
    }
  };

  return (
    <div data-source-location="src/pages/MyTutors.jsx:50:4" data-dynamic-content="true" className="min-h-screen font-body relative z-10" data-collection-id="Profile">
      <nav data-source-location="src/pages/MyTutors.jsx:51:6" data-dynamic-content="true" className="bg-card/80 backdrop-blur-md border-b border-border px-6 py-4 flex items-center gap-4" data-collection-id="Profile">
        <Link data-source-location="src/pages/MyTutors.jsx:52:8" data-dynamic-content="false" to="/student-dashboard" className="text-muted-foreground hover:text-foreground"><ArrowLeft data-source-location="src/pages/MyTutors.jsx:52:94" data-dynamic-content="false" className="w-5 h-5" /></Link>
        <div data-source-location="src/pages/MyTutors.jsx:53:8" data-dynamic-content="true" data-collection-id="Profile">
          <h1 data-source-location="src/pages/MyTutors.jsx:54:10" data-dynamic-content="false" className="font-heading font-bold text-foreground text-lg">My Tutors</h1>
          <p data-source-location="src/pages/MyTutors.jsx:55:10" data-dynamic-content="true" className="text-xs text-muted-foreground" data-collection-id="Profile">{tutors.length} connected tutor{tutors.length !== 1 ? "s" : ""}</p>
        </div>
      </nav>

      <div data-source-location="src/pages/MyTutors.jsx:59:6" data-dynamic-content="true" className="max-w-2xl mx-auto px-6 py-8">
        {tutors.length === 0 ?
        <div data-source-location="src/pages/MyTutors.jsx:61:10" data-dynamic-content="false" className="text-center py-20">
            <p data-source-location="src/pages/MyTutors.jsx:62:12" data-dynamic-content="false" className="text-xl font-semibold text-foreground mb-2">No tutors yet</p>
            <p data-source-location="src/pages/MyTutors.jsx:63:12" data-dynamic-content="false" className="text-muted-foreground mb-6">Browse tutors and connect to get started.</p>
            <Link data-source-location="src/pages/MyTutors.jsx:64:12" data-dynamic-content="false" to="/browse-tutors" className="inline-flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 transition-colors">
              <UserPlus data-source-location="src/pages/MyTutors.jsx:65:14" data-dynamic-content="false" className="w-4 h-4" /> Find Tutors
            </Link>
          </div> :

        <div data-source-location="src/pages/MyTutors.jsx:69:10" data-dynamic-content="true" className="space-y-3">
            {tutors.map((t, i) =>
          <motion.div data-source-location="src/pages/MyTutors.jsx:71:14" data-dynamic-content="true" key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
          className="bg-card rounded-2xl border border-border p-5">
                <div data-source-location="src/pages/MyTutors.jsx:73:16" data-dynamic-content="true" className="flex items-center gap-4 mb-4">
                  <div data-source-location="src/pages/MyTutors.jsx:74:18" data-dynamic-content="true" className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center font-bold text-primary font-heading text-sm">
                    {t.name.split(" ").map((n) => n[0]).join("")}
                  </div>
                  <div data-source-location="src/pages/MyTutors.jsx:77:18" data-dynamic-content="true" className="flex-1" data-collection-item-field="email" data-collection-item-id={t?.id || t?._id}>
                    <p data-source-location="src/pages/MyTutors.jsx:78:20" data-dynamic-content="true" className="font-semibold text-foreground" data-collection-item-field="name" data-collection-item-id={t?.id || t?._id}>{t.name}</p>
                    {t.email && <p data-source-location="src/pages/MyTutors.jsx:79:32" data-dynamic-content="true" className="text-xs text-muted-foreground" data-collection-item-field="email" data-collection-item-id={t?.id || t?._id}>{t.email}</p>}
                    {t.pricing && !t.pricing.flexible && t.pricing.price && <p data-source-location="src/pages/MyTutors.jsx:80:76" data-dynamic-content="true" className="text-xs text-green-600 font-semibold" data-collection-item-field="pricing.price" data-collection-item-id={t?.id || t?._id}>${t.pricing.price}/hr</p>}
                    {t.pricing?.flexible && <p data-source-location="src/pages/MyTutors.jsx:81:44" data-dynamic-content="false" className="text-xs text-primary font-semibold">Flexible rate</p>}
                    {t.tutorGrade?.length > 0 && <p data-source-location="src/pages/MyTutors.jsx:82:49" data-dynamic-content="true" className="text-xs text-muted-foreground" data-collection-item-field="tutorGrade" data-collection-item-id={t?.id || t?._id}>Teaches {t.tutorGrade.join(", ")} Grade</p>}
                    {t.subjects?.length > 0 &&
                <div data-source-location="src/pages/MyTutors.jsx:84:22" data-dynamic-content="true" className="flex flex-wrap gap-1 mt-1">
                        {t.subjects.slice(0, 3).map((s) => <span data-source-location="src/pages/MyTutors.jsx:85:57" data-dynamic-content="true" key={s} className="px-1.5 py-0.5 bg-secondary text-secondary-foreground text-[10px] rounded font-medium" data-collection-item-field="s">{s}</span>)}
                      </div>
                }
                  </div>
                </div>
                <div data-source-location="src/pages/MyTutors.jsx:90:16" data-dynamic-content="true" className="flex gap-2">
                  <Link data-source-location="src/pages/MyTutors.jsx:91:18" data-dynamic-content="true" to={`/chat?name=${encodeURIComponent(t.name)}&back=/my-tutors`}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-primary/10 text-primary border border-primary/20 text-xs font-semibold hover:bg-primary/20 transition-colors">
                    <MessageCircle data-source-location="src/pages/MyTutors.jsx:93:20" data-dynamic-content="false" className="w-3.5 h-3.5" /> Message
                  </Link>
                  <button data-source-location="src/pages/MyTutors.jsx:95:18" data-dynamic-content="true" onClick={() => setReviewTutor(t.name)}
              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-primary/10 text-primary border border-primary/20 text-xs font-semibold hover:bg-primary/20 transition-colors">
                    <Star data-source-location="src/pages/MyTutors.jsx:97:20" data-dynamic-content="false" className="w-3.5 h-3.5" /> Review
                  </button>
                  <button data-source-location="src/pages/MyTutors.jsx:99:18" data-dynamic-content="true" onClick={() => setPayTutor(t)}
              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-green-50 text-green-700 border border-green-200 text-xs font-semibold hover:bg-green-100 transition-colors">
                    <CreditCard data-source-location="src/pages/MyTutors.jsx:101:20" data-dynamic-content="false" className="w-3.5 h-3.5" /> Pay
                  </button>
                </div>
              </motion.div>
          )}
          </div>
        }

        <div data-source-location="src/pages/MyTutors.jsx:109:8" data-dynamic-content="false" className="mt-5 text-center">
          <Link data-source-location="src/pages/MyTutors.jsx:110:10" data-dynamic-content="false" to="/browse-tutors" className="text-sm text-muted-foreground hover:text-foreground underline transition-colors">Find more tutors</Link>
        </div>
      </div>
      {reviewTutor && <ReviewsModal data-source-location="src/pages/MyTutors.jsx:113:22" data-dynamic-content="true" tutorName={reviewTutor} allowReview onClose={() => setReviewTutor(null)} />}
      {payTutor &&
      <PaymentModal data-source-location="src/pages/MyTutors.jsx:115:8" data-dynamic-content="true"
      payee={{ name: payTutor.name }}
      payerName={myName}
      amount={getTutorRate(payTutor)}
      subject={(payTutor.subjects || ["Tutoring"])[0]}
      savedCard={savedCard}
      onCardSaved={handleCardSaved}
      onClose={() => setPayTutor(null)} />

      }
    </div>);

}