import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Eye, EyeOff, Mail, Sparkles } from "lucide-react";
import { FcGoogle } from "react-icons/fc";
import { base44 } from "@/api/base44Client";
import Logo from "@/components/Logo";

const Pupil = ({ size = 12, maxDistance = 5, pupilColor = "black", forceLookX, forceLookY, "data-collection-item-id": __dataCollectionItemId }) => {
  const [mouseX, setMouseX] = useState(0);
  const [mouseY, setMouseY] = useState(0);
  const pupilRef = useRef(null);

  useEffect(() => {
    const handleMouseMove = (e) => {setMouseX(e.clientX);setMouseY(e.clientY);};
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  const calculatePupilPosition = () => {
    if (!pupilRef.current) return { x: 0, y: 0 };
    if (forceLookX !== undefined && forceLookY !== undefined) return { x: forceLookX, y: forceLookY };
    const pupil = pupilRef.current.getBoundingClientRect();
    const deltaX = mouseX - (pupil.left + pupil.width / 2);
    const deltaY = mouseY - (pupil.top + pupil.height / 2);
    const distance = Math.min(Math.sqrt(deltaX ** 2 + deltaY ** 2), maxDistance);
    const angle = Math.atan2(deltaY, deltaX);
    return { x: Math.cos(angle) * distance, y: Math.sin(angle) * distance };
  };

  const pos = calculatePupilPosition();
  return (
    <div data-source-location="src/pages/GetStarted.jsx:34:4" data-dynamic-content="true" ref={pupilRef} className="rounded-full" style={{ width: `${size}px`, height: `${size}px`, backgroundColor: pupilColor, transform: `translate(${pos.x}px, ${pos.y}px)`, transition: 'transform 0.1s ease-out' }} data-collection-item-id={__dataCollectionItemId} />);

};

const EyeBall = ({ size = 48, pupilSize = 16, maxDistance = 10, eyeColor = "white", pupilColor = "black", isBlinking = false, forceLookX, forceLookY, "data-collection-item-id": __dataCollectionItemId }) => {
  const [mouseX, setMouseX] = useState(0);
  const [mouseY, setMouseY] = useState(0);
  const eyeRef = useRef(null);

  useEffect(() => {
    const handleMouseMove = (e) => {setMouseX(e.clientX);setMouseY(e.clientY);};
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  const calculatePupilPosition = () => {
    if (!eyeRef.current) return { x: 0, y: 0 };
    if (forceLookX !== undefined && forceLookY !== undefined) return { x: forceLookX, y: forceLookY };
    const eye = eyeRef.current.getBoundingClientRect();
    const deltaX = mouseX - (eye.left + eye.width / 2);
    const deltaY = mouseY - (eye.top + eye.height / 2);
    const distance = Math.min(Math.sqrt(deltaX ** 2 + deltaY ** 2), maxDistance);
    const angle = Math.atan2(deltaY, deltaX);
    return { x: Math.cos(angle) * distance, y: Math.sin(angle) * distance };
  };

  const pos = calculatePupilPosition();
  return (
    <div data-source-location="src/pages/GetStarted.jsx:62:4" data-dynamic-content="true" ref={eyeRef} className="rounded-full flex items-center justify-center transition-all duration-150" style={{ width: `${size}px`, height: isBlinking ? '2px' : `${size}px`, backgroundColor: eyeColor, overflow: 'hidden' }} data-collection-item-id={__dataCollectionItemId}>
      {!isBlinking && <div data-source-location="src/pages/GetStarted.jsx:63:22" data-dynamic-content="true" className="rounded-full" style={{ width: `${pupilSize}px`, height: `${pupilSize}px`, backgroundColor: pupilColor, transform: `translate(${pos.x}px, ${pos.y}px)`, transition: 'transform 0.1s ease-out' }} />}
    </div>);
};

export default function GetStarted() {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [mouseX, setMouseX] = useState(0);
  const [mouseY, setMouseY] = useState(0);
  const [isPurpleBlinking, setIsPurpleBlinking] = useState(false);
  const [isBlackBlinking, setIsBlackBlinking] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [isLookingAtEachOther, setIsLookingAtEachOther] = useState(false);
  const [isPurplePeeking, setIsPurplePeeking] = useState(false);
  const purpleRef = useRef(null);
  const blackRef = useRef(null);
  const yellowRef = useRef(null);
  const orangeRef = useRef(null);

  useEffect(() => {
    const handleMouseMove = (e) => {setMouseX(e.clientX);setMouseY(e.clientY);};
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  useEffect(() => {
    const scheduleBlink = (setter) => {
      const t = setTimeout(() => {
        setter(true);
        setTimeout(() => {setter(false);scheduleBlink(setter);}, 150);
      }, Math.random() * 4000 + 3000);
      return t;
    };
    const t1 = scheduleBlink(setIsPurpleBlinking);
    const t2 = scheduleBlink(setIsBlackBlinking);
    return () => {clearTimeout(t1);clearTimeout(t2);};
  }, []);

  useEffect(() => {
    if (isTyping) {
      setIsLookingAtEachOther(true);
      const t = setTimeout(() => setIsLookingAtEachOther(false), 800);
      return () => clearTimeout(t);
    } else {
      setIsLookingAtEachOther(false);
    }
  }, [isTyping]);

  useEffect(() => {
    if (password.length > 0 && showPassword) {
      const t = setTimeout(() => {
        setIsPurplePeeking(true);
        setTimeout(() => setIsPurplePeeking(false), 800);
      }, Math.random() * 3000 + 2000);
      return () => clearTimeout(t);
    } else {
      setIsPurplePeeking(false);
    }
  }, [password, showPassword, isPurplePeeking]);

  const calculatePosition = (ref) => {
    if (!ref.current) return { faceX: 0, faceY: 0, bodySkew: 0 };
    const rect = ref.current.getBoundingClientRect();
    const deltaX = mouseX - (rect.left + rect.width / 2);
    const deltaY = mouseY - (rect.top + rect.height / 3);
    return {
      faceX: Math.max(-15, Math.min(15, deltaX / 20)),
      faceY: Math.max(-10, Math.min(10, deltaY / 30)),
      bodySkew: Math.max(-6, Math.min(6, -deltaX / 120))
    };
  };

  const purplePos = calculatePosition(purpleRef);
  const blackPos = calculatePosition(blackRef);
  const yellowPos = calculatePosition(yellowRef);
  const orangePos = calculatePosition(orangeRef);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);
    try {
      await base44.auth.loginViaEmailPassword(email, password);
      const user = await base44.auth.me();
      const profiles = await base44.entities.Profile.filter({ email: user.email });
      if (profiles.length > 0) {
        const p = profiles[0];
        const profileData = {
          name: p.full_name, role: p.role, grade: p.grade, email: user.email,
          subjects: p.subjects || [], interests: p.interests || [],
          bio: p.bio, learnStyle: p.learn_style, teachStyle: p.teach_style,
          tutored: p.tutored, improve: p.improve || [], strengths: p.strengths || [],
          tutorGrade: p.tutor_grade || [], tutorSubjects: p.tutor_subjects || [],
          pricing: p.pricing, avatar: p.avatar
        };
        sessionStorage.setItem("onboardingData", JSON.stringify(profileData));
        window.location.href = p.role === "tutor" ? "/tutor-dashboard" : "/student-dashboard";
      } else {
        window.location.href = "/questionnaire";
      }
    } catch (err) {
      setError(err.message || "Invalid email or password. Please try again.");
    }
    setIsLoading(false);
  };

  const handleGoogle = () => {
    base44.auth.loginWithProvider("google", "/auth-redirect");
  };

  return (
    <div data-source-location="src/pages/GetStarted.jsx:177:4" data-dynamic-content="true" className="min-h-screen grid lg:grid-cols-2 font-body relative z-10">
      {/* Left Section */}
      <div data-source-location="src/pages/GetStarted.jsx:179:6" data-dynamic-content="true" className="relative hidden lg:flex flex-col justify-between p-12 text-foreground overflow-hidden">
        <div data-source-location="src/pages/GetStarted.jsx:180:8" data-dynamic-content="false" className="relative z-20">
          <div data-source-location="src/pages/GetStarted.jsx:181:10" data-dynamic-content="false" className="flex items-center gap-2 text-lg font-heading font-bold">
            <Logo data-source-location="src/pages/GetStarted.jsx:182:12" data-dynamic-content="false" height={28} />
          </div>
        </div>

        <div data-source-location="src/pages/GetStarted.jsx:186:8" data-dynamic-content="true" className="relative z-20 flex items-end justify-center h-[500px]">
          <div data-source-location="src/pages/GetStarted.jsx:187:10" data-dynamic-content="true" className="relative" style={{ width: '550px', height: '400px' }}>
            {/* Purple character */}
            <div data-source-location="src/pages/GetStarted.jsx:189:12" data-dynamic-content="true" ref={purpleRef} className="absolute bottom-0 transition-all duration-700 ease-in-out"
            style={{ left: '70px', width: '180px', height: isTyping || password.length > 0 && !showPassword ? '440px' : '400px', backgroundColor: '#6C3FF5', borderRadius: '10px 10px 0 0', zIndex: 1,
              transform: password.length > 0 && showPassword ? `skewX(0deg)` : isTyping || password.length > 0 && !showPassword ? `skewX(${(purplePos.bodySkew || 0) - 12}deg) translateX(40px)` : `skewX(${purplePos.bodySkew || 0}deg)`,
              transformOrigin: 'bottom center' }}>
              <div data-source-location="src/pages/GetStarted.jsx:193:14" data-dynamic-content="true" className="absolute flex gap-8 transition-all duration-700 ease-in-out"
              style={{ left: password.length > 0 && showPassword ? '20px' : isLookingAtEachOther ? '55px' : `${45 + purplePos.faceX}px`, top: password.length > 0 && showPassword ? '35px' : isLookingAtEachOther ? '65px' : `${40 + purplePos.faceY}px` }}>
                <EyeBall data-source-location="src/pages/GetStarted.jsx:195:16" data-dynamic-content="true" size={18} pupilSize={7} maxDistance={5} eyeColor="white" pupilColor="#2D2D2D" isBlinking={isPurpleBlinking} forceLookX={password.length > 0 && showPassword ? isPurplePeeking ? 4 : -4 : isLookingAtEachOther ? 3 : undefined} forceLookY={password.length > 0 && showPassword ? isPurplePeeking ? 5 : -4 : isLookingAtEachOther ? 4 : undefined} />
                <EyeBall data-source-location="src/pages/GetStarted.jsx:196:16" data-dynamic-content="true" size={18} pupilSize={7} maxDistance={5} eyeColor="white" pupilColor="#2D2D2D" isBlinking={isPurpleBlinking} forceLookX={password.length > 0 && showPassword ? isPurplePeeking ? 4 : -4 : isLookingAtEachOther ? 3 : undefined} forceLookY={password.length > 0 && showPassword ? isPurplePeeking ? 5 : -4 : isLookingAtEachOther ? 4 : undefined} />
              </div>
            </div>

            {/* Black character */}
            <div data-source-location="src/pages/GetStarted.jsx:201:12" data-dynamic-content="true" ref={blackRef} className="absolute bottom-0 transition-all duration-700 ease-in-out"
            style={{ left: '240px', width: '120px', height: '310px', backgroundColor: '#2D2D2D', borderRadius: '8px 8px 0 0', zIndex: 2,
              transform: password.length > 0 && showPassword ? `skewX(0deg)` : isLookingAtEachOther ? `skewX(${(blackPos.bodySkew || 0) * 1.5 + 10}deg) translateX(20px)` : isTyping || password.length > 0 && !showPassword ? `skewX(${(blackPos.bodySkew || 0) * 1.5}deg)` : `skewX(${blackPos.bodySkew || 0}deg)`,
              transformOrigin: 'bottom center' }}>
              <div data-source-location="src/pages/GetStarted.jsx:205:14" data-dynamic-content="true" className="absolute flex gap-6 transition-all duration-700 ease-in-out"
              style={{ left: password.length > 0 && showPassword ? '10px' : isLookingAtEachOther ? '32px' : `${26 + blackPos.faceX}px`, top: password.length > 0 && showPassword ? '28px' : isLookingAtEachOther ? '12px' : `${32 + blackPos.faceY}px` }}>
                <EyeBall data-source-location="src/pages/GetStarted.jsx:207:16" data-dynamic-content="true" size={16} pupilSize={6} maxDistance={4} eyeColor="white" pupilColor="#2D2D2D" isBlinking={isBlackBlinking} forceLookX={password.length > 0 && showPassword ? -4 : isLookingAtEachOther ? 0 : undefined} forceLookY={password.length > 0 && showPassword ? -4 : isLookingAtEachOther ? -4 : undefined} />
                <EyeBall data-source-location="src/pages/GetStarted.jsx:208:16" data-dynamic-content="true" size={16} pupilSize={6} maxDistance={4} eyeColor="white" pupilColor="#2D2D2D" isBlinking={isBlackBlinking} forceLookX={password.length > 0 && showPassword ? -4 : isLookingAtEachOther ? 0 : undefined} forceLookY={password.length > 0 && showPassword ? -4 : isLookingAtEachOther ? -4 : undefined} />
              </div>
            </div>

            {/* Orange character */}
            <div data-source-location="src/pages/GetStarted.jsx:213:12" data-dynamic-content="true" ref={orangeRef} className="absolute bottom-0 transition-all duration-700 ease-in-out"
            style={{ left: '0px', width: '240px', height: '200px', zIndex: 3, backgroundColor: '#FF9B6B', borderRadius: '120px 120px 0 0',
              transform: password.length > 0 && showPassword ? `skewX(0deg)` : `skewX(${orangePos.bodySkew || 0}deg)`, transformOrigin: 'bottom center' }}>
              <div data-source-location="src/pages/GetStarted.jsx:216:14" data-dynamic-content="true" className="absolute flex gap-8 transition-all duration-200 ease-out"
              style={{ left: password.length > 0 && showPassword ? '50px' : `${82 + (orangePos.faceX || 0)}px`, top: password.length > 0 && showPassword ? '85px' : `${90 + (orangePos.faceY || 0)}px` }}>
                <Pupil data-source-location="src/pages/GetStarted.jsx:218:16" data-dynamic-content="true" size={12} maxDistance={5} pupilColor="#2D2D2D" forceLookX={password.length > 0 && showPassword ? -5 : undefined} forceLookY={password.length > 0 && showPassword ? -4 : undefined} />
                <Pupil data-source-location="src/pages/GetStarted.jsx:219:16" data-dynamic-content="true" size={12} maxDistance={5} pupilColor="#2D2D2D" forceLookX={password.length > 0 && showPassword ? -5 : undefined} forceLookY={password.length > 0 && showPassword ? -4 : undefined} />
              </div>
            </div>

            {/* Yellow character */}
            <div data-source-location="src/pages/GetStarted.jsx:224:12" data-dynamic-content="true" ref={yellowRef} className="absolute bottom-0 transition-all duration-700 ease-in-out"
            style={{ left: '310px', width: '140px', height: '230px', backgroundColor: '#E8D754', borderRadius: '70px 70px 0 0', zIndex: 4,
              transform: password.length > 0 && showPassword ? `skewX(0deg)` : `skewX(${yellowPos.bodySkew || 0}deg)`, transformOrigin: 'bottom center' }}>
              <div data-source-location="src/pages/GetStarted.jsx:227:14" data-dynamic-content="true" className="absolute flex gap-6 transition-all duration-200 ease-out"
              style={{ left: password.length > 0 && showPassword ? '20px' : `${52 + (yellowPos.faceX || 0)}px`, top: password.length > 0 && showPassword ? '35px' : `${40 + (yellowPos.faceY || 0)}px` }}>
                <Pupil data-source-location="src/pages/GetStarted.jsx:229:16" data-dynamic-content="true" size={12} maxDistance={5} pupilColor="#2D2D2D" forceLookX={password.length > 0 && showPassword ? -5 : undefined} forceLookY={password.length > 0 && showPassword ? -4 : undefined} />
                <Pupil data-source-location="src/pages/GetStarted.jsx:230:16" data-dynamic-content="true" size={12} maxDistance={5} pupilColor="#2D2D2D" forceLookX={password.length > 0 && showPassword ? -5 : undefined} forceLookY={password.length > 0 && showPassword ? -4 : undefined} />
              </div>
              <div data-source-location="src/pages/GetStarted.jsx:232:14" data-dynamic-content="true" className="absolute w-20 h-[4px] bg-[#2D2D2D] rounded-full transition-all duration-200 ease-out"
              style={{ left: password.length > 0 && showPassword ? '10px' : `${40 + (yellowPos.faceX || 0)}px`, top: password.length > 0 && showPassword ? '88px' : `${88 + (yellowPos.faceY || 0)}px` }} />
            </div>
          </div>
        </div>

        <div data-source-location="src/pages/GetStarted.jsx:238:8" data-dynamic-content="false" className="relative z-20" />

        {/* Decorative */}
        <div data-source-location="src/pages/GetStarted.jsx:241:8" data-dynamic-content="true" className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle, rgba(128,128,128,0.06) 1px, transparent 1px)' }} />
        <div data-source-location="src/pages/GetStarted.jsx:242:8" data-dynamic-content="false" className="absolute top-1/4 right-1/4 size-64 bg-primary/5 rounded-full blur-3xl" />
        <div data-source-location="src/pages/GetStarted.jsx:243:8" data-dynamic-content="false" className="absolute bottom-1/4 left-1/4 size-96 bg-primary/3 rounded-full blur-3xl" />
      </div>

      {/* Right Login Section */}
      <div data-source-location="src/pages/GetStarted.jsx:247:6" data-dynamic-content="true" className="flex items-center justify-center p-8">
        <div data-source-location="src/pages/GetStarted.jsx:248:8" data-dynamic-content="true" className="w-full max-w-[420px]">
          {/* Mobile logo */}
          <div data-source-location="src/pages/GetStarted.jsx:250:10" data-dynamic-content="false" className="lg:hidden flex items-center justify-center gap-2 text-lg font-heading font-bold mb-12 text-foreground">
            <Logo data-source-location="src/pages/GetStarted.jsx:251:12" data-dynamic-content="false" height={28} />
          </div>

          <div data-source-location="src/pages/GetStarted.jsx:254:10" data-dynamic-content="false" className="text-center mb-10">
            <h1 data-source-location="src/pages/GetStarted.jsx:255:12" data-dynamic-content="false" className="text-3xl font-heading font-bold tracking-tight mb-2 text-foreground">Welcome back!</h1>
            <p data-source-location="src/pages/GetStarted.jsx:256:12" data-dynamic-content="false" className="text-muted-foreground text-sm font-body">Please enter your details</p>
          </div>

          <form data-source-location="src/pages/GetStarted.jsx:259:10" data-dynamic-content="true" onSubmit={handleSubmit} className="space-y-5">
            <div data-source-location="src/pages/GetStarted.jsx:260:12" data-dynamic-content="true" className="space-y-2">
              <Label data-source-location="src/pages/GetStarted.jsx:261:14" data-dynamic-content="false" htmlFor="email" className="text-sm font-medium text-foreground">Email</Label>
              <Input data-source-location="src/pages/GetStarted.jsx:262:14" data-dynamic-content="true" id="email" type="email" placeholder="you@example.com" value={email} autoComplete="off"
              onChange={(e) => setEmail(e.target.value)} onFocus={() => setIsTyping(true)} onBlur={() => setIsTyping(false)}
              required className="h-12 border-border focus:border-primary text-foreground bg-muted/50 placeholder:text-muted-foreground/60" />
            </div>

            <div data-source-location="src/pages/GetStarted.jsx:267:12" data-dynamic-content="true" className="space-y-2">
              <Label data-source-location="src/pages/GetStarted.jsx:268:14" data-dynamic-content="false" htmlFor="password" className="text-sm font-medium text-foreground">Password</Label>
              <div data-source-location="src/pages/GetStarted.jsx:269:14" data-dynamic-content="true" className="relative">
                <Input data-source-location="src/pages/GetStarted.jsx:270:16" data-dynamic-content="true" id="password" type={showPassword ? "text" : "password"} placeholder="••••••••" value={password}
                onChange={(e) => setPassword(e.target.value)} required className="h-12 pr-10 border-border focus:border-primary text-foreground bg-muted/50 placeholder:text-muted-foreground/60" />
                <button data-source-location="src/pages/GetStarted.jsx:272:16" data-dynamic-content="true" type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors">
                  {showPassword ? <EyeOff data-source-location="src/pages/GetStarted.jsx:273:34" data-dynamic-content="false" className="size-5" /> : <Eye data-source-location="src/pages/GetStarted.jsx:273:66" data-dynamic-content="false" className="size-5" />}
                </button>
              </div>
            </div>

            <div data-source-location="src/pages/GetStarted.jsx:278:12" data-dynamic-content="false" className="flex justify-end">
              <a data-source-location="src/pages/GetStarted.jsx:279:14" data-dynamic-content="false" href="#" className="text-sm text-muted-foreground hover:text-foreground font-medium transition-colors">Forgot password?</a>
            </div>

            {error &&
            <div data-source-location="src/pages/GetStarted.jsx:283:12" data-dynamic-content="true" className="p-3 text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-lg" data-collection-item-field="error">{error}</div>
            }

            <Button data-source-location="src/pages/GetStarted.jsx:286:12" data-dynamic-content="true" type="submit" className="w-full h-12 text-base font-heading font-semibold bg-primary hover:bg-primary/90 text-primary-foreground" size="lg" disabled={isLoading}>
              {isLoading ? "Signing in..." : "Log in"}
            </Button>
          </form>

          <div data-source-location="src/pages/GetStarted.jsx:291:10" data-dynamic-content="true" className="mt-6">
            <Button data-source-location="src/pages/GetStarted.jsx:292:12" data-dynamic-content="true" variant="outline" className="w-full h-12 border-border hover:bg-muted/50 text-foreground" type="button" onClick={handleGoogle}>
              <FcGoogle data-source-location="src/pages/GetStarted.jsx:293:14" data-dynamic-content="false" className="mr-2 size-5" />
              Log in with Google
            </Button>
          </div>

          <div data-source-location="src/pages/GetStarted.jsx:298:10" data-dynamic-content="false" className="text-center text-sm text-muted-foreground mt-8">
            Don't have an account?{" "}
            <a data-source-location="src/pages/GetStarted.jsx:300:12" data-dynamic-content="false" href="/sign-up" className="text-primary font-medium hover:underline">Create one here</a>
          </div>
        </div>
      </div>
    </div>);
}