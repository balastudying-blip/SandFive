import { useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { ArrowLeft, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import FileUpload from "@/components/ui/file-upload";
import { base44 } from "@/api/base44Client";

export default function AssignHomework() {
  const [params] = useSearchParams();
  const studentName = params.get("student") || "Student";
  const tutorName = JSON.parse(sessionStorage.getItem("onboardingData") || "{}").name || "Tutor";
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await base44.entities.Homework.create({
        title,
        description,
        due_date: dueDate || "—",
        subject: "Assignment",
        student_name: studentName,
        tutor_name: tutorName,
        done: false
      });
      setSubmitted(true);
    } catch (e) {
      console.error("Failed to assign homework:", e);
    }
    setSaving(false);
  };

  if (submitted) {
    return (
      <div data-source-location="src/pages/AssignHomework.jsx:41:6" data-dynamic-content="true" className="min-h-screen flex items-center justify-center p-6 relative z-10">
        <div data-source-location="src/pages/AssignHomework.jsx:42:8" data-dynamic-content="true" className="text-center max-w-sm">
          <div data-source-location="src/pages/AssignHomework.jsx:43:10" data-dynamic-content="false" className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Send data-source-location="src/pages/AssignHomework.jsx:44:12" data-dynamic-content="false" className="w-8 h-8 text-primary" />
          </div>
          <h2 data-source-location="src/pages/AssignHomework.jsx:46:10" data-dynamic-content="false" className="text-2xl font-heading font-bold text-foreground mb-2">Assigned!</h2>
          <p data-source-location="src/pages/AssignHomework.jsx:47:10" data-dynamic-content="true" className="text-muted-foreground mb-6" data-collection-item-field="studentName">Homework sent to {studentName}.</p>
          <Link data-source-location="src/pages/AssignHomework.jsx:48:10" data-dynamic-content="false" to="/tutor-students">
            <Button data-source-location="src/pages/AssignHomework.jsx:49:12" data-dynamic-content="false" className="bg-primary text-primary-foreground">Back to Students</Button>
          </Link>
        </div>
      </div>);

  }

  return (
    <div data-source-location="src/pages/AssignHomework.jsx:57:4" data-dynamic-content="true" className="min-h-screen font-body relative z-10">
      <nav data-source-location="src/pages/AssignHomework.jsx:58:6" data-dynamic-content="true" className="bg-card/80 backdrop-blur-md border-b border-border px-6 py-4 flex items-center gap-4">
        <Link data-source-location="src/pages/AssignHomework.jsx:59:8" data-dynamic-content="false" to="/tutor-students" className="text-muted-foreground hover:text-foreground">
          <ArrowLeft data-source-location="src/pages/AssignHomework.jsx:60:10" data-dynamic-content="false" className="w-5 h-5" />
        </Link>
        <div data-source-location="src/pages/AssignHomework.jsx:62:8" data-dynamic-content="true">
          <h1 data-source-location="src/pages/AssignHomework.jsx:63:10" data-dynamic-content="false" className="font-heading font-bold text-foreground text-lg">Assign Homework</h1>
          <p data-source-location="src/pages/AssignHomework.jsx:64:10" data-dynamic-content="true" className="text-xs text-muted-foreground" data-collection-item-field="studentName">To: {studentName}</p>
        </div>
      </nav>

      <div data-source-location="src/pages/AssignHomework.jsx:68:6" data-dynamic-content="true" className="max-w-2xl mx-auto px-6 py-8">
        <form data-source-location="src/pages/AssignHomework.jsx:69:8" data-dynamic-content="true" onSubmit={handleSubmit} className="space-y-6">
          <div data-source-location="src/pages/AssignHomework.jsx:70:10" data-dynamic-content="true">
            <label data-source-location="src/pages/AssignHomework.jsx:71:12" data-dynamic-content="false" className="block text-sm font-semibold text-foreground mb-2">Assignment Title</label>
            <Input data-source-location="src/pages/AssignHomework.jsx:72:12" data-dynamic-content="true" value={title} onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Chapter 5 Practice Problems" required className="h-11" />
          </div>

          <div data-source-location="src/pages/AssignHomework.jsx:76:10" data-dynamic-content="true">
            <label data-source-location="src/pages/AssignHomework.jsx:77:12" data-dynamic-content="false" className="block text-sm font-semibold text-foreground mb-2">Instructions</label>
            <textarea data-source-location="src/pages/AssignHomework.jsx:78:12" data-dynamic-content="true" value={description} onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe the assignment..."
            rows={4}
            className="w-full px-3 py-2.5 border border-border rounded-lg bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-none" />
          </div>

          <div data-source-location="src/pages/AssignHomework.jsx:84:10" data-dynamic-content="true">
            <label data-source-location="src/pages/AssignHomework.jsx:85:12" data-dynamic-content="false" className="block text-sm font-semibold text-foreground mb-2">Due Date</label>
            <Input data-source-location="src/pages/AssignHomework.jsx:86:12" data-dynamic-content="true" type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className="h-11" />
          </div>

          <div data-source-location="src/pages/AssignHomework.jsx:89:10" data-dynamic-content="false">
            <label data-source-location="src/pages/AssignHomework.jsx:90:12" data-dynamic-content="false" className="block text-sm font-semibold text-foreground mb-2">Attach Files (optional)</label>
            <FileUpload data-source-location="src/pages/AssignHomework.jsx:91:12" data-dynamic-content="false" />
          </div>

          <Button data-source-location="src/pages/AssignHomework.jsx:94:10" data-dynamic-content="true" type="submit" disabled={saving} className="w-full h-11 bg-primary text-primary-foreground text-base font-semibold">
            {saving ? "Sending..." : "Send Assignment"}
          </Button>
        </form>
      </div>
    </div>);

}