import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Search, UserPlus, ArrowLeft, Star, BookOpen, Clock } from "lucide-react";
import { Input } from "@/components/ui/input";
import Logo from "@/components/Logo";
import ReviewsModal from "@/components/ReviewsModal";
import TutorBioModal from "@/components/TutorBioModal";
import { base44 } from "@/api/base44Client";

const GRADES = ["All", "6th–8th", "9th–12th", "College"];
const TUTORED_OPTIONS = ["All", "Yes", "No"];
const TEACH_STYLE_OPTIONS = ["All", "Explain concepts", "Work through problems", "Mixed approach"];

function TutorCard({ tutor, onConnect, connStatus, onReviews, onBio }) {
  const status = connStatus[tutor.name]?.status;
  return (
    <motion.div data-source-location="src/pages/BrowseTutors.jsx:18:4" data-dynamic-content="true" initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
    className="bg-card border border-border rounded-2xl p-5 hover:shadow-md transition-shadow" data-collection-item-field="pricing.flexible" data-collection-item-id={tutor?.id || tutor?._id}>
      <div data-source-location="src/pages/BrowseTutors.jsx:20:6" data-dynamic-content="true" className="flex items-start justify-between mb-3">
        <div data-source-location="src/pages/BrowseTutors.jsx:21:8" data-dynamic-content="true" className="flex items-center gap-3">
          <div data-source-location="src/pages/BrowseTutors.jsx:22:10" data-dynamic-content="true" className="w-11 h-11 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold text-base font-heading">
            {tutor.name.split(" ").map((n) => n[0]).join("")}
          </div>
          <div data-source-location="src/pages/BrowseTutors.jsx:25:10" data-dynamic-content="true">
            <p data-source-location="src/pages/BrowseTutors.jsx:26:12" data-dynamic-content="true" className="font-semibold text-foreground text-sm" data-collection-item-field="name" data-collection-item-id={tutor?.id || tutor?._id}>{tutor.name}</p>
            <p data-source-location="src/pages/BrowseTutors.jsx:27:12" data-dynamic-content="true" className="text-xs text-muted-foreground" data-collection-item-field="grade" data-collection-item-id={tutor?.id || tutor?._id}>{tutor.grade} Grade</p>
          </div>
        </div>
        <span data-source-location="src/pages/BrowseTutors.jsx:30:8" data-dynamic-content="true" className={`text-xs font-medium px-2.5 py-1 rounded-full ${tutor.available ? "bg-green-50 text-green-700" : "bg-muted text-muted-foreground"}`}>
          {tutor.available ? "Available" : "Busy"}
        </span>
      </div>

      <div data-source-location="src/pages/BrowseTutors.jsx:35:6" data-dynamic-content="true" className="flex flex-wrap gap-1.5 mb-3" data-collection-id="tutor" data-collection-item-field="subjects" data-collection-item-id={tutor?.id || tutor?._id}>
        {tutor.subjects.map((s) => <span data-source-location="src/pages/BrowseTutors.jsx:36:33" data-dynamic-content="true" key={s} className="px-2 py-0.5 bg-secondary text-secondary-foreground text-xs rounded-md font-medium" data-collection-item-field="s">{s}</span>)}
      </div>

      <p data-source-location="src/pages/BrowseTutors.jsx:39:6" data-dynamic-content="true" className="text-xs text-muted-foreground leading-relaxed mb-3 line-clamp-2" data-collection-item-field="bio" data-collection-item-id={tutor?.id || tutor?._id}>{tutor.bio}</p>

      {tutor.pricing && !tutor.pricing.flexible && tutor.pricing.price &&
      <p data-source-location="src/pages/BrowseTutors.jsx:42:8" data-dynamic-content="true" className="text-sm font-bold text-green-600 mb-3" data-collection-item-field="pricing.price" data-collection-item-id={tutor?.id || tutor?._id}>${tutor.pricing.price}/hour</p>
      }
      {tutor.pricing?.flexible &&
      <p data-source-location="src/pages/BrowseTutors.jsx:45:8" data-dynamic-content="false" className="text-sm font-bold text-primary mb-3">Flexible rate</p>
      }

      <div data-source-location="src/pages/BrowseTutors.jsx:48:6" data-dynamic-content="true" className="flex gap-2">
        {status === "accepted" ?
        <span data-source-location="src/pages/BrowseTutors.jsx:50:10" data-dynamic-content="false" className="flex-1 text-center py-2 text-xs font-semibold text-green-600 bg-green-50 rounded-xl border border-green-200">✓ Connected</span> :
        status === "pending" ?
        <span data-source-location="src/pages/BrowseTutors.jsx:52:10" data-dynamic-content="false" className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-muted-foreground bg-muted rounded-xl border border-border">
            <Clock data-source-location="src/pages/BrowseTutors.jsx:53:12" data-dynamic-content="false" className="w-3.5 h-3.5" /> Waiting...
          </span> :

        <button data-source-location="src/pages/BrowseTutors.jsx:56:10" data-dynamic-content="true" onClick={() => onConnect(tutor)}
        className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-primary text-primary-foreground rounded-xl text-xs font-semibold hover:bg-primary/90 transition-colors">
            <UserPlus data-source-location="src/pages/BrowseTutors.jsx:58:12" data-dynamic-content="false" className="w-3.5 h-3.5" /> Connect
          </button>
        }
        <button data-source-location="src/pages/BrowseTutors.jsx:61:8" data-dynamic-content="true" onClick={() => onBio(tutor)}
        className="flex items-center justify-center gap-1.5 py-2 px-3 bg-secondary text-secondary-foreground border border-border rounded-xl text-xs font-semibold hover:bg-muted transition-colors">
          <BookOpen data-source-location="src/pages/BrowseTutors.jsx:63:10" data-dynamic-content="false" className="w-3.5 h-3.5" /> Bio
        </button>
        <button data-source-location="src/pages/BrowseTutors.jsx:65:8" data-dynamic-content="true" onClick={() => onReviews(tutor.name)}
        className="flex items-center justify-center gap-1.5 py-2 px-3 bg-primary/10 text-primary border border-primary/20 rounded-xl text-xs font-semibold hover:bg-primary/20 transition-colors">
          <Star data-source-location="src/pages/BrowseTutors.jsx:67:10" data-dynamic-content="false" className="w-3.5 h-3.5" /> Reviews
        </button>
      </div>
    </motion.div>);

}

export default function BrowseTutors() {
  const [search, setSearch] = useState("");
  const [gradeFilter, setGradeFilter] = useState("All");
  const [tutoredFilter, setTutoredFilter] = useState("All");
  const [teachStyleFilter, setTeachStyleFilter] = useState("All");
  const [connStatus, setConnStatus] = useState({});
  const [reviewTutor, setReviewTutor] = useState(null);
  const [bioTutor, setBioTutor] = useState(null);
  const [tutors, setTutors] = useState([]);
  const tutorsRef = useRef([]);
  const myName = JSON.parse(sessionStorage.getItem("onboardingData") || "{}").name || "";

  useEffect(() => {
    const loadTutors = async () => {
      try {
        const profiles = await base44.entities.Profile.filter({ role: "tutor" });
        const realTutors = profiles.
        filter((p) => p.full_name && p.full_name !== myName).
        map((p) => ({
          id: p.id,
          name: p.full_name,
          email: p.email || "",
          grade: p.tutor_grade && p.tutor_grade[0] || "",
          tutorGrade: p.tutor_grade || [],
          subjects: p.tutor_subjects || [],
          bio: p.bio || "",
          available: true,
          teachStyle: p.teach_style || "",
          tutored: p.tutored || "",
          interests: p.interests || [],
          strengths: p.strengths || [],
          pricing: p.pricing || null,
          avatar: p.avatar || null
        }));
        tutorsRef.current = realTutors;
        setTutors(realTutors);
      } catch (e) {/* empty */}
    };
    loadTutors();
    let unsubscribe;
    try {
      unsubscribe = base44.entities.Profile.subscribe((event) => {
        if (event.type === "create" && event.data.role === "tutor") loadTutors();
      });
    } catch (e) {}
    return () => {if (typeof unsubscribe === 'function') unsubscribe();};
  }, [myName]);

  useEffect(() => {
    if (!myName) return;
    const loadConnections = async () => {
      try {
        const [requested, received] = await Promise.all([
        base44.entities.Connection.filter({ requester_name: myName }),
        base44.entities.Connection.filter({ recipient_name: myName })]
        );
        const statusMap = {};
        [...requested, ...received].forEach((c) => {
          const otherName = c.requester_name === myName ? c.recipient_name : c.requester_name;
          statusMap[otherName] = { status: c.status, id: c.id };
          if (c.status === "accepted" && c.requester_name === myName) {
            const existing = JSON.parse(sessionStorage.getItem("myTutors") || "[]");
            if (!existing.find((t) => t.name === otherName)) {
              const tutor = tutorsRef.current.find((t) => t.name === otherName);
              sessionStorage.setItem("myTutors", JSON.stringify([...existing, tutor ? { id: tutor.id, name: tutor.name } : { name: otherName }]));
            }
          }
        });
        setConnStatus(statusMap);
      } catch (e) {/* empty */}
    };
    loadConnections();
    let unsubscribe;
    try {
      unsubscribe = base44.entities.Connection.subscribe((event) => {
        const c = event.data;
        if (!c) return;
        const otherName = c.requester_name === myName ? c.recipient_name : c.recipient_name === myName ? c.requester_name : null;
        if (!otherName) return;
        if (event.type === "create" || event.type === "update") {
          setConnStatus((prev) => ({ ...prev, [otherName]: { status: c.status, id: c.id } }));
          if (c.status === "accepted" && c.requester_name === myName) {
            const existing = JSON.parse(sessionStorage.getItem("myTutors") || "[]");
            if (!existing.find((t) => t.name === otherName)) {
              const tutor = tutorsRef.current.find((t) => t.name === otherName);
              sessionStorage.setItem("myTutors", JSON.stringify([...existing, tutor ? { id: tutor.id, name: tutor.name } : { name: otherName }]));
            }
          }
        }
      });
    } catch (e) {}
    return () => {if (typeof unsubscribe === 'function') unsubscribe();};
  }, [myName]);

  const handleConnect = async (tutor) => {
    if (!myName || myName === "Student" || myName === "Tutor") {
      alert("Please complete your profile in the questionnaire before connecting.");
      return;
    }
    const existing = connStatus[tutor.name];
    setConnStatus((prev) => ({ ...prev, [tutor.name]: { status: "pending", id: existing?.id } }));
    try {
      if (existing?.id) {
        await base44.entities.Connection.update(existing.id, { status: "pending" });
      } else {
        await base44.entities.Connection.create({
          requester_name: myName,
          requester_role: "student",
          recipient_name: tutor.name,
          recipient_role: "tutor",
          status: "pending"
        });
      }
    } catch (e) {
      console.error("Failed to send connection request:", e);
      setConnStatus((prev) => ({ ...prev, [tutor.name]: existing }));
    }
  };

  const filtered = tutors.filter((t) => {
    const matchSearch = !search || t.name.toLowerCase().includes(search.toLowerCase()) || t.subjects.some((s) => s.toLowerCase().includes(search.toLowerCase()));
    const matchGrade = gradeFilter === "All" || gradeFilter === "9th–12th" && ["9th", "10th", "11th", "12th"].some((g) => t.grade.includes(g)) || gradeFilter === "6th–8th" && ["6th", "7th", "8th"].some((g) => t.grade.includes(g)) || gradeFilter === "College" && t.grade === "College";
    const matchTutored = tutoredFilter === "All" || t.tutored === tutoredFilter;
    const matchTeachStyle = teachStyleFilter === "All" || t.teachStyle === teachStyleFilter;
    return matchSearch && matchGrade && matchTutored && matchTeachStyle;
  });

  return (
    <div data-source-location="src/pages/BrowseTutors.jsx:202:4" data-dynamic-content="true" className="min-h-screen font-body relative z-10">
      <nav data-source-location="src/pages/BrowseTutors.jsx:203:6" data-dynamic-content="false" className="bg-card/80 backdrop-blur-md border-b border-border px-6 py-4 flex items-center justify-between">
        <div data-source-location="src/pages/BrowseTutors.jsx:204:8" data-dynamic-content="false" className="flex items-center gap-3">
          <Link data-source-location="src/pages/BrowseTutors.jsx:205:10" data-dynamic-content="false" to="/student-dashboard" className="text-muted-foreground hover:text-foreground"><ArrowLeft data-source-location="src/pages/BrowseTutors.jsx:205:96" data-dynamic-content="false" className="w-5 h-5" /></Link>
          <Link data-source-location="src/pages/BrowseTutors.jsx:206:10" data-dynamic-content="false" to="/"><Logo data-source-location="src/pages/BrowseTutors.jsx:206:23" data-dynamic-content="false" height={24} /></Link>
        </div>
        <div data-source-location="src/pages/BrowseTutors.jsx:208:8" data-dynamic-content="false" className="flex items-center gap-5 text-sm text-muted-foreground">
          <Link data-source-location="src/pages/BrowseTutors.jsx:209:10" data-dynamic-content="false" to="/get-started" className="hover:text-foreground transition-colors">Login</Link>
          <Link data-source-location="src/pages/BrowseTutors.jsx:210:10" data-dynamic-content="false" to="/sign-up" className="bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">Get Started</Link>
        </div>
      </nav>

      <div data-source-location="src/pages/BrowseTutors.jsx:214:6" data-dynamic-content="true" className="max-w-5xl mx-auto px-6 py-8">
        <div data-source-location="src/pages/BrowseTutors.jsx:215:8" data-dynamic-content="false" className="mb-6">
          <h1 data-source-location="src/pages/BrowseTutors.jsx:216:10" data-dynamic-content="false" className="text-3xl font-heading font-bold text-foreground mb-1">Find a Tutor</h1>
          <p data-source-location="src/pages/BrowseTutors.jsx:217:10" data-dynamic-content="false" className="text-muted-foreground text-sm">Browse verified peer tutors on S&5.</p>
        </div>

        <div data-source-location="src/pages/BrowseTutors.jsx:220:8" data-dynamic-content="true" className="bg-card border border-border rounded-2xl p-4 mb-6 space-y-3">
          <div data-source-location="src/pages/BrowseTutors.jsx:221:10" data-dynamic-content="true" className="relative">
            <Search data-source-location="src/pages/BrowseTutors.jsx:222:12" data-dynamic-content="false" className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input data-source-location="src/pages/BrowseTutors.jsx:223:12" data-dynamic-content="true" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by name or subject..." className="pl-9" />
          </div>

          <div data-source-location="src/pages/BrowseTutors.jsx:226:10" data-dynamic-content="true">
            <p data-source-location="src/pages/BrowseTutors.jsx:227:12" data-dynamic-content="false" className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Grade</p>
            <div data-source-location="src/pages/BrowseTutors.jsx:228:12" data-dynamic-content="true" className="flex flex-wrap gap-1.5">
              {GRADES.map((g, __arrIdx__) =>
              <button data-source-location="src/pages/BrowseTutors.jsx:230:16" data-dynamic-content="true" key={g} onClick={() => setGradeFilter(g)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${gradeFilter === g ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:bg-muted"}`} data-arr-index={__arrIdx__} data-arr-variable-name="GRADES">{g}</button>
              )}
            </div>
          </div>

          <div data-source-location="src/pages/BrowseTutors.jsx:236:10" data-dynamic-content="true">
            <p data-source-location="src/pages/BrowseTutors.jsx:237:12" data-dynamic-content="false" className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Have You Tutored Before?</p>
            <div data-source-location="src/pages/BrowseTutors.jsx:238:12" data-dynamic-content="true" className="flex flex-wrap gap-1.5">
              {TUTORED_OPTIONS.map((t, __arrIdx__) =>
              <button data-source-location="src/pages/BrowseTutors.jsx:240:16" data-dynamic-content="true" key={t} onClick={() => setTutoredFilter(t)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${tutoredFilter === t ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:bg-muted"}`} data-arr-index={__arrIdx__} data-arr-variable-name="TUTORED_OPTIONS">{t}</button>
              )}
            </div>
          </div>

          <div data-source-location="src/pages/BrowseTutors.jsx:246:10" data-dynamic-content="true">
            <p data-source-location="src/pages/BrowseTutors.jsx:247:12" data-dynamic-content="false" className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">How Do You Prefer to Teach?</p>
            <div data-source-location="src/pages/BrowseTutors.jsx:248:12" data-dynamic-content="true" className="flex flex-wrap gap-1.5">
              {TEACH_STYLE_OPTIONS.map((t, __arrIdx__) =>
              <button data-source-location="src/pages/BrowseTutors.jsx:250:16" data-dynamic-content="true" key={t} onClick={() => setTeachStyleFilter(t)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${teachStyleFilter === t ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:bg-muted"}`} data-arr-index={__arrIdx__} data-arr-variable-name="TEACH_STYLE_OPTIONS">{t}</button>
              )}
            </div>
          </div>
        </div>

        {filtered.length === 0 ?
        <div data-source-location="src/pages/BrowseTutors.jsx:258:10" data-dynamic-content="false" className="text-center py-16 text-muted-foreground">
            <p data-source-location="src/pages/BrowseTutors.jsx:259:12" data-dynamic-content="false" className="text-lg font-medium">No tutors match your filters</p>
            <p data-source-location="src/pages/BrowseTutors.jsx:260:12" data-dynamic-content="false" className="text-sm mt-1">Try adjusting your search or filters</p>
          </div> :

        <div data-source-location="src/pages/BrowseTutors.jsx:263:10" data-dynamic-content="true" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map((t) => <TutorCard data-source-location="src/pages/BrowseTutors.jsx:264:31" data-dynamic-content="true" key={t.id} tutor={t} onConnect={handleConnect} connStatus={connStatus} onReviews={setReviewTutor} onBio={setBioTutor} data-collection-item-id={t?.id} />)}
          </div>
        }
      </div>
      {reviewTutor && <ReviewsModal data-source-location="src/pages/BrowseTutors.jsx:268:22" data-dynamic-content="true" tutorName={reviewTutor} onClose={() => setReviewTutor(null)} />}
      {bioTutor && <TutorBioModal data-source-location="src/pages/BrowseTutors.jsx:269:19" data-dynamic-content="true" tutor={bioTutor} onClose={() => setBioTutor(null)} />}
    </div>);

}