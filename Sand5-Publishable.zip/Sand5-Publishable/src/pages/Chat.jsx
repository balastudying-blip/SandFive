import { useState, useRef, useEffect } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { ArrowLeft, Send, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { base44 } from "@/api/base44Client";

export default function Chat() {
  const [params] = useSearchParams();
  const withName = params.get("name") || "User";
  const backTo = params.get("back") || "/";

  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(true);
  const endRef = useRef(null);

  const myData = JSON.parse(sessionStorage.getItem("onboardingData") || "{}");
  const [myName, setMyName] = useState(myData.name || "");
  const [isAdmin, setIsAdmin] = useState(false);
  const convId = myName ? [myName, withName].sort().join("_") : "";

  useEffect(() => {
    base44.auth.me().then((me) => {
      if (!myData.name) setMyName(me.full_name || "Me");
      setIsAdmin(me.role === "admin");
    }).catch(() => {if (!myData.name) setMyName("Me");});
  }, []);

  const loadMessages = async () => {
    try {
      const msgs = await base44.entities.Message.filter({ conversation_id: convId }, "created_date");
      setMessages(msgs.map((m) => ({
        id: m.id,
        content: m.content,
        sender: m.sender_name === myName ? "me" : "other",
        is_admin: m.is_admin,
        time: new Date(m.created_date).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", timeZone: "America/New_York" })
      })));
    } catch (e) {
      const local = JSON.parse(sessionStorage.getItem(`chat_${convId}`) || "[]");
      setMessages(local);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadMessages();
    let unsubscribe;
    try {
      unsubscribe = base44.entities.Message.subscribe((event) => {
        if (event.data?.conversation_id === convId) {
          loadMessages();
        }
      });
    } catch (e) {

      // no realtime — messages load on refresh
    }return () => {if (unsubscribe) unsubscribe();};
  }, [convId]);

  useEffect(() => {endRef.current?.scrollIntoView({ behavior: "smooth" });}, [messages]);

  const sendMessage = async () => {
    if (!input.trim()) return;
    const content = input;
    setInput("");

    setMessages((prev) => [...prev, {
      id: Date.now().toString(),
      content,
      sender: "me",
      time: new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", timeZone: "America/New_York" })
    }]);

    try {
      await base44.entities.Message.create({
        conversation_id: convId,
        sender_name: myName,
        recipient_name: withName,
        content,
        sender_role: isAdmin ? "admin" : (myData.role || "student").toLowerCase(),
        is_admin: isAdmin
      });
    } catch (e) {
      const local = JSON.parse(sessionStorage.getItem(`chat_${convId}`) || "[]");
      sessionStorage.setItem(`chat_${convId}`, JSON.stringify([...local, {
        id: Date.now().toString(),
        content,
        sender: "me",
        time: new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", timeZone: "America/New_York" })
      }]));
    }
  };

  const initials = withName.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);

  return (
    <div data-source-location="src/pages/Chat.jsx:99:4" data-dynamic-content="true" className="min-h-screen flex flex-col font-body relative z-10">
      {/* Header */}
      <div data-source-location="src/pages/Chat.jsx:101:6" data-dynamic-content="true" className="bg-card/80 backdrop-blur-md border-b border-border px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        <Link data-source-location="src/pages/Chat.jsx:102:8" data-dynamic-content="true" to={backTo} className="text-muted-foreground hover:text-foreground">
          <ArrowLeft data-source-location="src/pages/Chat.jsx:103:10" data-dynamic-content="false" className="w-5 h-5" />
        </Link>
        <div data-source-location="src/pages/Chat.jsx:105:8" data-dynamic-content="true" className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-sm flex-shrink-0" data-collection-item-field="initials">
          {initials}
        </div>
        <div data-source-location="src/pages/Chat.jsx:108:8" data-dynamic-content="true">
          <p data-source-location="src/pages/Chat.jsx:109:10" data-dynamic-content="true" className="font-semibold text-foreground text-sm" data-collection-item-field="withName">{withName}</p>
          {messages.some((m) => m.is_admin && m.sender === "other") ?
          <p data-source-location="src/pages/Chat.jsx:111:14" data-dynamic-content="false" className="text-xs text-amber-600 flex items-center gap-1"><Shield data-source-location="src/pages/Chat.jsx:111:76" data-dynamic-content="false" className="w-3 h-3" /> S&5 Admin</p> :
          <p data-source-location="src/pages/Chat.jsx:112:14" data-dynamic-content="false" className="text-xs text-green-500">Active now</p>}
        </div>
      </div>

      {/* Messages */}
      <div data-source-location="src/pages/Chat.jsx:117:6" data-dynamic-content="true" className="flex-1 overflow-y-auto px-4 py-5 space-y-4 max-w-2xl w-full mx-auto">
        {loading ?
        <div data-source-location="src/pages/Chat.jsx:119:10" data-dynamic-content="false" className="text-center text-muted-foreground text-sm py-12">
            <div data-source-location="src/pages/Chat.jsx:120:12" data-dynamic-content="false" className="w-6 h-6 border-2 border-muted border-t-primary rounded-full animate-spin mx-auto mb-2" />
            Loading messages...
          </div> :
        messages.length === 0 ?
        <div data-source-location="src/pages/Chat.jsx:124:10" data-dynamic-content="true" className="text-center text-muted-foreground text-sm py-12" data-collection-item-field="withName">
            Start the conversation with {withName}
          </div> :

        messages.map((msg) =>
        <div data-source-location="src/pages/Chat.jsx:129:12" data-dynamic-content="true" key={msg.id} className={`flex items-end gap-2 ${msg.sender === "me" ? "justify-end" : "justify-start"}`} data-collection-item-id={msg?.id}>
              {msg.sender === "other" &&
          <div data-source-location="src/pages/Chat.jsx:131:16" data-dynamic-content="true" className="w-7 h-7 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-xs font-bold flex-shrink-0">
                  {initials[0]}
                </div>
          }
              <div data-source-location="src/pages/Chat.jsx:135:14" data-dynamic-content="true" className={`max-w-xs lg:max-w-sm rounded-2xl px-4 py-2.5 text-sm ${msg.sender === "me" ? "bg-primary text-primary-foreground rounded-br-sm" : msg.is_admin ? "bg-amber-500/15 text-foreground rounded-bl-sm border border-amber-500/40" : "bg-secondary text-foreground rounded-bl-sm"}`}>
                {msg.is_admin && msg.sender === "other" &&
            <span data-source-location="src/pages/Chat.jsx:137:18" data-dynamic-content="false" className="inline-flex items-center gap-1 text-[10px] font-semibold text-amber-600 mb-1"><Shield data-source-location="src/pages/Chat.jsx:137:113" data-dynamic-content="false" className="w-3 h-3" /> Admin</span>
            }
                <p data-source-location="src/pages/Chat.jsx:139:16" data-dynamic-content="true" data-collection-item-field="content" data-collection-item-id={msg?.id}>{msg.content}</p>
                <p data-source-location="src/pages/Chat.jsx:140:16" data-dynamic-content="true" className={`text-[10px] mt-1 ${msg.sender === "me" ? "text-primary-foreground/60" : "text-muted-foreground"}`} data-collection-item-field="time" data-collection-item-id={msg?.id}>{msg.time}</p>
              </div>
            </div>
        )
        }
        <div data-source-location="src/pages/Chat.jsx:145:8" data-dynamic-content="true" ref={endRef} />
      </div>

      {/* Input */}
      <div data-source-location="src/pages/Chat.jsx:149:6" data-dynamic-content="true" className="bg-card/80 backdrop-blur-md border-t border-border px-4 py-3 sticky bottom-0">
        <div data-source-location="src/pages/Chat.jsx:150:8" data-dynamic-content="true" className="max-w-2xl mx-auto flex gap-2 items-center">
          <Input data-source-location="src/pages/Chat.jsx:151:10" data-dynamic-content="true"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {if (e.key === "Enter" && !e.shiftKey) {e.preventDefault();sendMessage();}}}
          placeholder={`Message ${withName}...`}
          className="flex-1 h-11 rounded-xl bg-muted border-0 text-sm" />
          
          <Button data-source-location="src/pages/Chat.jsx:158:10" data-dynamic-content="true" onClick={sendMessage} disabled={!input.trim()} size="icon" className="h-11 w-11 rounded-xl bg-primary hover:bg-primary/90">
            <Send data-source-location="src/pages/Chat.jsx:159:12" data-dynamic-content="false" className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>);

}