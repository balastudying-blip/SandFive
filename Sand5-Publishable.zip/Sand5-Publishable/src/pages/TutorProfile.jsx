import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Star, Clock, Users, BookOpen, ArrowLeft, CheckCircle } from "lucide-react";
import Logo from "@/components/Logo";

const mockTutor = {
  name: "Bala Mudiganti", grade: "12th", subjects: ["AP Calculus BC", "AP Physics C", "Algebra II", "SAT Math"],
  rating: 4.9, sessions: 142, rate: 28, available: true,
  bio: "Passionate about making complex concepts simple. Top 5% scorer who loves helping peers truly understand, not just memorize. I specialize in breaking down problems step-by-step so students feel confident and capable.",
  teaches: ["One-on-one sessions", "Tutor Share groups", "Exam prep bootcamps"],
  reviews: [
  { student: "Emma R.", rating: 5, text: "Aiden explained derivatives in a way my teacher never could. Went from a 64 to an 89 in AP Calc." },
  { student: "Leo M.", rating: 5, text: "Super patient. Helped me understand physics problems step by step. Highly recommend." },
  { student: "Mia T.", rating: 4, text: "Great at math. SAT score went up 80 points after 4 sessions." }]

};

export default function TutorProfile() {
  return (
    <div data-source-location="src/pages/TutorProfile.jsx:20:4" data-dynamic-content="true" className="min-h-screen font-body relative z-10">
      <nav data-source-location="src/pages/TutorProfile.jsx:21:6" data-dynamic-content="false" className="bg-card/80 backdrop-blur-md flex items-center justify-between px-8 py-5 border-b border-border">
        <Link data-source-location="src/pages/TutorProfile.jsx:22:8" data-dynamic-content="false" to="/"><Logo data-source-location="src/pages/TutorProfile.jsx:22:21" data-dynamic-content="false" height={24} /></Link>
        <Link data-source-location="src/pages/TutorProfile.jsx:23:8" data-dynamic-content="false" to="/browse-tutors" className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft data-source-location="src/pages/TutorProfile.jsx:24:10" data-dynamic-content="false" className="w-4 h-4" /> Back to tutors
        </Link>
      </nav>

      <div data-source-location="src/pages/TutorProfile.jsx:28:6" data-dynamic-content="true" className="max-w-3xl mx-auto px-8 py-10 space-y-5">
        {/* Profile card */}
        <motion.div data-source-location="src/pages/TutorProfile.jsx:30:8" data-dynamic-content="true" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="bg-gradient-to-br from-card/50 to-card/20 backdrop-blur-xl border border-border rounded-2xl p-6">
          <div data-source-location="src/pages/TutorProfile.jsx:31:10" data-dynamic-content="true" className="flex items-start justify-between mb-4">
            <div data-source-location="src/pages/TutorProfile.jsx:32:12" data-dynamic-content="true" className="flex items-center gap-4">
              <div data-source-location="src/pages/TutorProfile.jsx:33:14" data-dynamic-content="false" className="w-16 h-16 rounded-full bg-muted flex items-center justify-center text-2xl font-bold font-heading text-muted-foreground">BM</div>
              <div data-source-location="src/pages/TutorProfile.jsx:34:14" data-dynamic-content="true">
                <h1 data-source-location="src/pages/TutorProfile.jsx:35:16" data-dynamic-content="true" className="text-2xl font-heading font-bold text-foreground">{mockTutor.name}</h1>
                <p data-source-location="src/pages/TutorProfile.jsx:36:16" data-dynamic-content="true" className="text-sm text-muted-foreground">{mockTutor.grade} Grade</p>
                <div data-source-location="src/pages/TutorProfile.jsx:37:16" data-dynamic-content="true" className="flex items-center gap-2 mt-1">
                  <span data-source-location="src/pages/TutorProfile.jsx:38:18" data-dynamic-content="true" className="flex items-center gap-1 text-sm"><Star data-source-location="src/pages/TutorProfile.jsx:38:68" data-dynamic-content="false" className="w-4 h-4 text-yellow-400 fill-yellow-400" />{mockTutor.rating}</span>
                  <span data-source-location="src/pages/TutorProfile.jsx:39:18" data-dynamic-content="false" className="text-muted-foreground">·</span>
                  <span data-source-location="src/pages/TutorProfile.jsx:40:18" data-dynamic-content="true" className="text-sm text-muted-foreground">{mockTutor.sessions} sessions</span>
                </div>
              </div>
            </div>
            <div data-source-location="src/pages/TutorProfile.jsx:44:12" data-dynamic-content="true" className="text-right">
              <p data-source-location="src/pages/TutorProfile.jsx:45:14" data-dynamic-content="true" className="text-2xl font-bold text-foreground">${mockTutor.rate}<span data-source-location="src/pages/TutorProfile.jsx:45:81" data-dynamic-content="false" className="text-sm font-normal text-muted-foreground">/hr</span></p>
              <span data-source-location="src/pages/TutorProfile.jsx:46:14" data-dynamic-content="true" className={`text-xs font-medium px-2.5 py-1 rounded-full mt-1 inline-block ${mockTutor.available ? "bg-green-50 text-green-700" : "bg-secondary text-muted-foreground"}`}>
                {mockTutor.available ? "Available" : "Busy"}
              </span>
            </div>
          </div>
          <p data-source-location="src/pages/TutorProfile.jsx:51:10" data-dynamic-content="true" className="text-sm text-muted-foreground leading-relaxed">{mockTutor.bio}</p>
        </motion.div>

        {/* Subjects */}
        <motion.div data-source-location="src/pages/TutorProfile.jsx:55:8" data-dynamic-content="true" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-gradient-to-br from-card/50 to-card/20 backdrop-blur-xl border border-border rounded-2xl p-6">
          <h2 data-source-location="src/pages/TutorProfile.jsx:56:10" data-dynamic-content="false" className="font-heading font-semibold text-foreground mb-3">Subjects</h2>
          <div data-source-location="src/pages/TutorProfile.jsx:57:10" data-dynamic-content="true" className="flex flex-wrap gap-2">
            {mockTutor.subjects.map((s) => <span data-source-location="src/pages/TutorProfile.jsx:58:41" data-dynamic-content="true" key={s} className="px-3 py-1.5 bg-secondary text-foreground text-sm font-medium rounded-lg" data-collection-item-field="s">{s}</span>)}
          </div>
        </motion.div>

        {/* Offers */}
        <motion.div data-source-location="src/pages/TutorProfile.jsx:63:8" data-dynamic-content="true" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="bg-gradient-to-br from-card/50 to-card/20 backdrop-blur-xl border border-border rounded-2xl p-6">
          <h2 data-source-location="src/pages/TutorProfile.jsx:64:10" data-dynamic-content="false" className="font-heading font-semibold text-foreground mb-3">Offers</h2>
          <ul data-source-location="src/pages/TutorProfile.jsx:65:10" data-dynamic-content="true" className="space-y-2">
            {mockTutor.teaches.map((t) =>
            <li data-source-location="src/pages/TutorProfile.jsx:67:14" data-dynamic-content="true" key={t} className="flex items-center gap-2 text-sm text-foreground" data-collection-item-field="t"><CheckCircle data-source-location="src/pages/TutorProfile.jsx:67:86" data-dynamic-content="false" className="w-4 h-4 text-green-500" />{t}</li>
            )}
          </ul>
        </motion.div>

        {/* Reviews */}
        <motion.div data-source-location="src/pages/TutorProfile.jsx:73:8" data-dynamic-content="true" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-gradient-to-br from-card/50 to-card/20 backdrop-blur-xl border border-border rounded-2xl p-6">
          <h2 data-source-location="src/pages/TutorProfile.jsx:74:10" data-dynamic-content="false" className="font-heading font-semibold text-foreground mb-4">Reviews</h2>
          <div data-source-location="src/pages/TutorProfile.jsx:75:10" data-dynamic-content="true" className="space-y-4">
            {mockTutor.reviews.map((r, i) =>
            <div data-source-location="src/pages/TutorProfile.jsx:77:14" data-dynamic-content="true" key={i} className="pb-4 border-b border-border last:border-0 last:pb-0">
                <div data-source-location="src/pages/TutorProfile.jsx:78:16" data-dynamic-content="true" className="flex items-center justify-between mb-1">
                  <p data-source-location="src/pages/TutorProfile.jsx:79:18" data-dynamic-content="true" className="text-sm font-medium text-foreground" data-collection-item-field="student" data-collection-item-id={r?.id || r?._id}>{r.student}</p>
                  <div data-source-location="src/pages/TutorProfile.jsx:80:18" data-dynamic-content="true" className="flex items-center gap-0.5">
                    {Array.from({ length: r.rating }).map((_, j) => <Star data-source-location="src/pages/TutorProfile.jsx:81:68" data-dynamic-content="true" key={j} className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />)}
                  </div>
                </div>
                <p data-source-location="src/pages/TutorProfile.jsx:84:16" data-dynamic-content="true" className="text-sm text-muted-foreground" data-collection-item-field="text" data-collection-item-id={r?.id || r?._id}>{r.text}</p>
              </div>
            )}
          </div>
        </motion.div>


      </div>
    </div>);

}