import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowLeft, CreditCard, Check, Clock, DollarSign, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { base44 } from "@/api/base44Client";

export default function MyPayments() {
  const myData = JSON.parse(sessionStorage.getItem("onboardingData") || "{}");
  const isTutor = myData.role === "Tutor";
  const myName = myData.name || "Me";
  const connections = JSON.parse(sessionStorage.getItem(isTutor ? "myStudents" : "myTutors") || "[]");
  const getRate = (c) => c.pricing && !c.pricing.flexible && c.pricing.price ? parseFloat(c.pricing.price) : 0;
  const [payments, setPayments] = useState(JSON.parse(sessionStorage.getItem("payments") || "[]"));
  const [showPay, setShowPay] = useState(false);

  useEffect(() => {
    const loadPayments = async () => {
      try {
        const filterKey = isTutor ? "payee_name" : "payer_name";
        const entityPayments = await base44.entities.Payment.filter({ [filterKey]: myName }, "-created_date");
        if (entityPayments.length > 0) {
          setPayments(entityPayments.map((p) => ({
            id: p.id,
            name: isTutor ? p.payer_name : p.payee_name,
            subject: p.subject,
            amount: p.amount,
            date: new Date(p.created_date).toLocaleDateString()
          })));
        }
      } catch (e) {

        // keep sessionStorage fallback
      }};
    loadPayments();
  }, []);
  const [payee, setPayee] = useState(null);
  const [card, setCard] = useState({ number: "", expiry: "", cvc: "" });
  const [processing, setProcessing] = useState(false);
  const [done, setDone] = useState(false);

  const upcoming = connections.map((c) => ({
    name: c.name,
    subject: (c.subjects || c.tutorSubjects || ["General"])[0],
    amount: getRate(c)
  }));

  const totalPaid = payments.reduce((s, p) => s + p.amount, 0);
  const totalPending = upcoming.reduce((s, p) => s + p.amount, 0);

  const handlePay = (person) => {
    setPayee(person);
    setShowPay(true);
    setDone(false);
    setCard({ number: "", expiry: "", cvc: "" });
  };

  const submitPayment = (e) => {
    e.preventDefault();
    setProcessing(true);
    setTimeout(async () => {
      try {
        await base44.entities.Payment.create({
          payer_name: myName,
          payee_name: payee.name,
          amount: payee.amount,
          subject: payee.subject,
          status: "completed"
        });
      } catch (e) {

        // fallback to sessionStorage only
      }const newPayment = { id: Date.now(), name: payee.name, subject: payee.subject, amount: payee.amount, date: new Date().toLocaleDateString() };
      const updated = [newPayment, ...payments];
      setPayments(updated);
      sessionStorage.setItem("payments", JSON.stringify(updated));
      setProcessing(false);
      setDone(true);
    }, 1800);
  };

  return (
    <div data-source-location="src/pages/MyPayments.jsx:84:4" data-dynamic-content="true" className="min-h-screen font-body relative z-10">
      <nav data-source-location="src/pages/MyPayments.jsx:85:6" data-dynamic-content="true" className="bg-card/80 backdrop-blur-md border-b border-border px-6 py-4 flex items-center gap-4">
        <Link data-source-location="src/pages/MyPayments.jsx:86:8" data-dynamic-content="true" to={isTutor ? "/tutor-dashboard" : "/student-dashboard"} className="text-muted-foreground hover:text-foreground">
          <ArrowLeft data-source-location="src/pages/MyPayments.jsx:87:10" data-dynamic-content="false" className="w-5 h-5" />
        </Link>
        <h1 data-source-location="src/pages/MyPayments.jsx:89:8" data-dynamic-content="false" className="font-heading font-bold text-foreground text-lg">My Payments</h1>
      </nav>

      <div data-source-location="src/pages/MyPayments.jsx:92:6" data-dynamic-content="true" className="max-w-4xl mx-auto px-6 py-8">
        {/* Summary cards */}
        <div data-source-location="src/pages/MyPayments.jsx:94:8" data-dynamic-content="true" className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <motion.div data-source-location="src/pages/MyPayments.jsx:95:10" data-dynamic-content="true" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
          className="bg-card border border-border rounded-2xl p-5">
            <div data-source-location="src/pages/MyPayments.jsx:97:12" data-dynamic-content="true" className="flex items-center gap-2 mb-2">
              <DollarSign data-source-location="src/pages/MyPayments.jsx:98:14" data-dynamic-content="false" className="w-4 h-4 text-green-600" />
              <p data-source-location="src/pages/MyPayments.jsx:99:14" data-dynamic-content="true" className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Total {isTutor ? "Earned" : "Paid"}</p>
            </div>
            <p data-source-location="src/pages/MyPayments.jsx:101:12" data-dynamic-content="true" className="text-2xl font-heading font-bold text-foreground" data-collection-item-field="totalPaid">${totalPaid}</p>
          </motion.div>
          <motion.div data-source-location="src/pages/MyPayments.jsx:103:10" data-dynamic-content="true" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="bg-card border border-border rounded-2xl p-5">
            <div data-source-location="src/pages/MyPayments.jsx:105:12" data-dynamic-content="false" className="flex items-center gap-2 mb-2">
              <Clock data-source-location="src/pages/MyPayments.jsx:106:14" data-dynamic-content="false" className="w-4 h-4 text-primary" />
              <p data-source-location="src/pages/MyPayments.jsx:107:14" data-dynamic-content="false" className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Pending</p>
            </div>
            <p data-source-location="src/pages/MyPayments.jsx:109:12" data-dynamic-content="true" className="text-2xl font-heading font-bold text-foreground" data-collection-item-field="totalPending">${totalPending}</p>
          </motion.div>
          <motion.div data-source-location="src/pages/MyPayments.jsx:111:10" data-dynamic-content="true" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="bg-card border border-border rounded-2xl p-5">
            <div data-source-location="src/pages/MyPayments.jsx:113:12" data-dynamic-content="false" className="flex items-center gap-2 mb-2">
              <CreditCard data-source-location="src/pages/MyPayments.jsx:114:14" data-dynamic-content="false" className="w-4 h-4 text-muted-foreground" />
              <p data-source-location="src/pages/MyPayments.jsx:115:14" data-dynamic-content="false" className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Avg Rate</p>
            </div>
            <p data-source-location="src/pages/MyPayments.jsx:117:12" data-dynamic-content="true" className="text-2xl font-heading font-bold text-foreground">${upcoming.length > 0 ? Math.round(totalPending / upcoming.length) : "—"}</p>
          </motion.div>
        </div>

        {/* Upcoming payments */}
        <div data-source-location="src/pages/MyPayments.jsx:122:8" data-dynamic-content="true" className="mb-8">
          <h2 data-source-location="src/pages/MyPayments.jsx:123:10" data-dynamic-content="true" className="text-sm font-heading font-bold text-foreground mb-3 uppercase tracking-wide">
            {isTutor ? "Upcoming Session Earnings" : "Upcoming Session Payments"}
          </h2>
          {upcoming.length === 0 ?
          <div data-source-location="src/pages/MyPayments.jsx:127:12" data-dynamic-content="true" className="bg-card border border-dashed border-border rounded-2xl p-8 text-center">
              <p data-source-location="src/pages/MyPayments.jsx:128:14" data-dynamic-content="true" className="text-muted-foreground text-sm">
                {isTutor ? "No connected students yet." : "No connected tutors yet."}
              </p>
              <Link data-source-location="src/pages/MyPayments.jsx:131:14" data-dynamic-content="true" to={isTutor ? "/find-students" : "/browse-tutors"} className="text-primary text-sm font-medium hover:underline mt-2 inline-block">
                {isTutor ? "Find Students" : "Find Tutors"}
              </Link>
            </div> :

          <div data-source-location="src/pages/MyPayments.jsx:136:12" data-dynamic-content="true" className="space-y-3">
              {upcoming.map((p, i) =>
            <motion.div data-source-location="src/pages/MyPayments.jsx:138:16" data-dynamic-content="true" key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
            className="bg-card border border-border rounded-2xl p-4 flex items-center justify-between">
                  <div data-source-location="src/pages/MyPayments.jsx:140:18" data-dynamic-content="true" className="flex items-center gap-3">
                    <div data-source-location="src/pages/MyPayments.jsx:141:20" data-dynamic-content="true" className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs">
                      {p.name.split(" ").map((n) => n[0]).join("")}
                    </div>
                    <div data-source-location="src/pages/MyPayments.jsx:144:20" data-dynamic-content="true">
                      <p data-source-location="src/pages/MyPayments.jsx:145:22" data-dynamic-content="true" className="text-sm font-semibold text-foreground" data-collection-item-field="name" data-collection-item-id={p?.id || p?._id}>{p.name}</p>
                      <p data-source-location="src/pages/MyPayments.jsx:146:22" data-dynamic-content="true" className="text-xs text-muted-foreground" data-collection-item-field="subject" data-collection-item-id={p?.id || p?._id}>{p.subject}</p>
                    </div>
                  </div>
                  <div data-source-location="src/pages/MyPayments.jsx:149:18" data-dynamic-content="true" className="flex items-center gap-4">
                    <span data-source-location="src/pages/MyPayments.jsx:150:20" data-dynamic-content="true" className="text-sm font-bold text-foreground" data-collection-item-field="amount" data-collection-item-id={p?.id || p?._id}>${p.amount}</span>
                    {!isTutor &&
                <Button data-source-location="src/pages/MyPayments.jsx:152:22" data-dynamic-content="true" size="sm" onClick={() => handlePay(p)} className="bg-primary text-primary-foreground">
                        Pay Now
                      </Button>
                }
                  </div>
                </motion.div>
            )}
            </div>
          }
        </div>

        {/* Payment history */}
        <div data-source-location="src/pages/MyPayments.jsx:164:8" data-dynamic-content="true">
          <h2 data-source-location="src/pages/MyPayments.jsx:165:10" data-dynamic-content="false" className="text-sm font-heading font-bold text-foreground mb-3 uppercase tracking-wide">Payment History</h2>
          {payments.length === 0 ?
          <div data-source-location="src/pages/MyPayments.jsx:167:12" data-dynamic-content="false" className="bg-card border border-dashed border-border rounded-2xl p-8 text-center">
              <p data-source-location="src/pages/MyPayments.jsx:168:14" data-dynamic-content="false" className="text-muted-foreground text-sm">No payments yet.</p>
            </div> :

          <div data-source-location="src/pages/MyPayments.jsx:171:12" data-dynamic-content="true" className="bg-card border border-border rounded-2xl divide-y divide-border">
              {payments.map((p) =>
            <div data-source-location="src/pages/MyPayments.jsx:173:16" data-dynamic-content="true" key={p.id} className="p-4 flex items-center justify-between" data-collection-item-id={p?.id}>
                  <div data-source-location="src/pages/MyPayments.jsx:174:18" data-dynamic-content="true" className="flex items-center gap-3">
                    <div data-source-location="src/pages/MyPayments.jsx:175:20" data-dynamic-content="false" className="w-8 h-8 rounded-full bg-green-50 flex items-center justify-center">
                      <Check data-source-location="src/pages/MyPayments.jsx:176:22" data-dynamic-content="false" className="w-4 h-4 text-green-600" />
                    </div>
                    <div data-source-location="src/pages/MyPayments.jsx:178:20" data-dynamic-content="true">
                      <p data-source-location="src/pages/MyPayments.jsx:179:22" data-dynamic-content="true" className="text-sm font-medium text-foreground" data-collection-item-field="name" data-collection-item-id={p?.id}>{p.name} — {p.subject}</p>
                      <p data-source-location="src/pages/MyPayments.jsx:180:22" data-dynamic-content="true" className="text-xs text-muted-foreground" data-collection-item-field="date" data-collection-item-id={p?.id}>{p.date}</p>
                    </div>
                  </div>
                  <span data-source-location="src/pages/MyPayments.jsx:183:18" data-dynamic-content="true" className="text-sm font-bold text-foreground" data-collection-item-field="amount" data-collection-item-id={p?.id}>${p.amount}</span>
                </div>
            )}
            </div>
          }
        </div>

        <p data-source-location="src/pages/MyPayments.jsx:190:8" data-dynamic-content="false" className="text-xs text-muted-foreground mt-6 flex items-center gap-1.5">
          <Lock data-source-location="src/pages/MyPayments.jsx:191:10" data-dynamic-content="false" className="w-3 h-3" /> Payments secured by Stripe. Card details never stored on our servers.
        </p>
      </div>

      {/* Payment modal */}
      {showPay &&
      <div data-source-location="src/pages/MyPayments.jsx:197:8" data-dynamic-content="true" className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => !processing && setShowPay(false)}>
          <motion.div data-source-location="src/pages/MyPayments.jsx:198:10" data-dynamic-content="true" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
        className="bg-card rounded-2xl border border-border p-6 max-w-sm w-full" onClick={(e) => e.stopPropagation()}>
            {done ?
          <div data-source-location="src/pages/MyPayments.jsx:201:14" data-dynamic-content="true" className="text-center py-6">
                <div data-source-location="src/pages/MyPayments.jsx:202:16" data-dynamic-content="false" className="w-14 h-14 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Check data-source-location="src/pages/MyPayments.jsx:203:18" data-dynamic-content="false" className="w-7 h-7 text-green-600" />
                </div>
                <h3 data-source-location="src/pages/MyPayments.jsx:205:16" data-dynamic-content="false" className="text-lg font-heading font-bold text-foreground mb-1">Payment Complete</h3>
                <p data-source-location="src/pages/MyPayments.jsx:206:16" data-dynamic-content="true" className="text-sm text-muted-foreground mb-4" data-collection-item-field="amount" data-collection-item-id={payee?.id || payee?._id}>${payee.amount} paid to {payee.name}</p>
                <Button data-source-location="src/pages/MyPayments.jsx:207:16" data-dynamic-content="true" onClick={() => setShowPay(false)} className="bg-primary text-primary-foreground w-full">Done</Button>
              </div> :

          <form data-source-location="src/pages/MyPayments.jsx:210:14" data-dynamic-content="true" onSubmit={submitPayment}>
                <div data-source-location="src/pages/MyPayments.jsx:211:16" data-dynamic-content="true" className="flex items-center gap-2 mb-4">
                  <div data-source-location="src/pages/MyPayments.jsx:212:18" data-dynamic-content="false" className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                    <CreditCard data-source-location="src/pages/MyPayments.jsx:213:20" data-dynamic-content="false" className="w-4 h-4 text-primary" />
                  </div>
                  <div data-source-location="src/pages/MyPayments.jsx:215:18" data-dynamic-content="true">
                    <h3 data-source-location="src/pages/MyPayments.jsx:216:20" data-dynamic-content="true" className="text-base font-heading font-bold text-foreground" data-collection-item-field="name" data-collection-item-id={payee?.id || payee?._id}>Pay {payee.name}</h3>
                    <p data-source-location="src/pages/MyPayments.jsx:217:20" data-dynamic-content="true" className="text-xs text-muted-foreground" data-collection-item-field="subject" data-collection-item-id={payee?.id || payee?._id}>{payee.subject} · ${payee.amount}</p>
                  </div>
                </div>

                <div data-source-location="src/pages/MyPayments.jsx:221:16" data-dynamic-content="true" className="space-y-3">
                  <div data-source-location="src/pages/MyPayments.jsx:222:18" data-dynamic-content="true">
                    <label data-source-location="src/pages/MyPayments.jsx:223:20" data-dynamic-content="false" className="text-xs font-medium text-muted-foreground block mb-1">Card Number</label>
                    <Input data-source-location="src/pages/MyPayments.jsx:224:20" data-dynamic-content="true" value={card.number} onChange={(e) => setCard({ ...card, number: e.target.value })}
                placeholder="4242 4242 4242 4242" maxLength={19} required disabled={processing} />
                  </div>
                  <div data-source-location="src/pages/MyPayments.jsx:227:18" data-dynamic-content="true" className="grid grid-cols-2 gap-3">
                    <div data-source-location="src/pages/MyPayments.jsx:228:20" data-dynamic-content="true">
                      <label data-source-location="src/pages/MyPayments.jsx:229:22" data-dynamic-content="false" className="text-xs font-medium text-muted-foreground block mb-1">Expiry</label>
                      <Input data-source-location="src/pages/MyPayments.jsx:230:22" data-dynamic-content="true" value={card.expiry} onChange={(e) => setCard({ ...card, expiry: e.target.value })}
                  placeholder="MM/YY" maxLength={5} required disabled={processing} />
                    </div>
                    <div data-source-location="src/pages/MyPayments.jsx:233:20" data-dynamic-content="true">
                      <label data-source-location="src/pages/MyPayments.jsx:234:22" data-dynamic-content="false" className="text-xs font-medium text-muted-foreground block mb-1">CVC</label>
                      <Input data-source-location="src/pages/MyPayments.jsx:235:22" data-dynamic-content="true" value={card.cvc} onChange={(e) => setCard({ ...card, cvc: e.target.value })}
                  placeholder="123" maxLength={4} required disabled={processing} />
                    </div>
                  </div>
                </div>

                <Button data-source-location="src/pages/MyPayments.jsx:241:16" data-dynamic-content="true" type="submit" disabled={processing} className="w-full mt-5 bg-primary text-primary-foreground">
                  {processing ?
              <span data-source-location="src/pages/MyPayments.jsx:243:20" data-dynamic-content="false" className="flex items-center gap-2">
                      <span data-source-location="src/pages/MyPayments.jsx:244:22" data-dynamic-content="false" className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                      Processing...
                    </span> :

              <span data-source-location="src/pages/MyPayments.jsx:248:20" data-dynamic-content="true" className="flex items-center gap-2" data-collection-item-field="amount" data-collection-item-id={payee?.id || payee?._id}>
                      <Lock data-source-location="src/pages/MyPayments.jsx:249:22" data-dynamic-content="false" className="w-4 h-4" /> Pay ${payee.amount}
                    </span>
              }
                </Button>
                <p data-source-location="src/pages/MyPayments.jsx:253:16" data-dynamic-content="false" className="text-xs text-muted-foreground text-center mt-3 flex items-center justify-center gap-1">
                  <Lock data-source-location="src/pages/MyPayments.jsx:254:18" data-dynamic-content="false" className="w-3 h-3" /> Secured by Stripe
                </p>
              </form>
          }
          </motion.div>
        </div>
      }
    </div>);

}