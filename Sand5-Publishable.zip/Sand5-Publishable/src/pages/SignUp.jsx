import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import GoogleIcon from "@/components/GoogleIcon";
import Logo from "@/components/Logo";

export default function SignUp() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [stage, setStage] = useState("signup");
  const [otp, setOtp] = useState("");

  const handleSignUp = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      await base44.auth.register({ email, password });
      setStage("otp");
    } catch (err) {
      setError(err.message || "Sign up failed. Please try again.");
    }
    setLoading(false);
  };

  const handleVerifyOtp = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      await base44.auth.verifyOtp({ email, otpCode: otp });
      await base44.auth.loginViaEmailPassword(email, password);
      window.location.href = "/questionnaire";
    } catch (err) {
      setError(err.message || "Invalid code. Please try again.");
    }
    setLoading(false);
  };

  const handleResendOtp = async () => {
    try {
      await base44.auth.resendOtp(email);
    } catch (err) {}
  };

  const handleGoogle = () => {
    base44.auth.loginWithProvider("google", "/questionnaire");
  };

  return (
    <div data-source-location="src/pages/SignUp.jsx:55:4" data-dynamic-content="true" className="min-h-screen flex items-center justify-center p-4 relative z-10">
      <div data-source-location="src/pages/SignUp.jsx:56:6" data-dynamic-content="true" className="w-full max-w-md">
        <div data-source-location="src/pages/SignUp.jsx:57:8" data-dynamic-content="true" className="text-center mb-8">
          <a data-source-location="src/pages/SignUp.jsx:58:10" data-dynamic-content="false" href="/"><Logo data-source-location="src/pages/SignUp.jsx:58:22" data-dynamic-content="false" height={36} /></a>
          <p data-source-location="src/pages/SignUp.jsx:59:10" data-dynamic-content="true" className="mt-3 text-muted-foreground text-lg">
            {stage === "otp" ? "Verify your email" : "Create your account"}
          </p>
        </div>

        <div data-source-location="src/pages/SignUp.jsx:64:8" data-dynamic-content="true" className="bg-card/60 backdrop-blur-xl border border-border rounded-2xl p-8 shadow-lg">
          {stage === "signup" &&
          <form data-source-location="src/pages/SignUp.jsx:66:12" data-dynamic-content="true" onSubmit={handleSignUp} className="space-y-4">
              <div data-source-location="src/pages/SignUp.jsx:67:14" data-dynamic-content="true">
                <label data-source-location="src/pages/SignUp.jsx:68:16" data-dynamic-content="false" className="block text-sm font-medium text-foreground mb-1.5">Email</label>
                <Input data-source-location="src/pages/SignUp.jsx:69:16" data-dynamic-content="true" type="email" value={email} onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com" required className="h-11 text-foreground bg-muted/50 border-border placeholder:text-muted-foreground/60" />
              </div>
              <div data-source-location="src/pages/SignUp.jsx:72:14" data-dynamic-content="true">
                <label data-source-location="src/pages/SignUp.jsx:73:16" data-dynamic-content="false" className="block text-sm font-medium text-foreground mb-1.5">Password</label>
                <Input data-source-location="src/pages/SignUp.jsx:74:16" data-dynamic-content="true" type="password" value={password} onChange={(e) => setPassword(e.target.value)}
              placeholder="Create a password" required className="h-11 text-foreground bg-muted/50 border-border placeholder:text-muted-foreground/60" />
              </div>

              {error && <p data-source-location="src/pages/SignUp.jsx:78:24" data-dynamic-content="true" className="text-sm text-destructive bg-destructive/10 p-3 rounded-lg" data-collection-item-field="error">{error}</p>}

              <Button data-source-location="src/pages/SignUp.jsx:80:14" data-dynamic-content="true" type="submit" disabled={loading} className="w-full h-11 text-base bg-primary hover:bg-primary/90 text-primary-foreground">
                {loading ? "Creating account..." : "Create Account"}
              </Button>
            </form>
          }

          {stage === "otp" &&
          <form data-source-location="src/pages/SignUp.jsx:87:12" data-dynamic-content="true" onSubmit={handleVerifyOtp} className="space-y-6">
              <p data-source-location="src/pages/SignUp.jsx:88:14" data-dynamic-content="true" className="text-sm text-muted-foreground text-center">
                We sent a verification code to <span data-source-location="src/pages/SignUp.jsx:89:47" data-dynamic-content="true" className="text-foreground font-medium" data-collection-item-field="email">{email}</span>. Enter it below to activate your account.
              </p>
              <div data-source-location="src/pages/SignUp.jsx:91:14" data-dynamic-content="true" className="flex justify-center">
                <InputOTP data-source-location="src/pages/SignUp.jsx:92:16" data-dynamic-content="true" maxLength={6} value={otp} onChange={(v) => setOtp(v)}>
                  <InputOTPGroup data-source-location="src/pages/SignUp.jsx:93:18" data-dynamic-content="false">
                    <InputOTPSlot data-source-location="src/pages/SignUp.jsx:94:20" data-dynamic-content="false" index={0} />
                    <InputOTPSlot data-source-location="src/pages/SignUp.jsx:95:20" data-dynamic-content="false" index={1} />
                    <InputOTPSlot data-source-location="src/pages/SignUp.jsx:96:20" data-dynamic-content="false" index={2} />
                    <InputOTPSlot data-source-location="src/pages/SignUp.jsx:97:20" data-dynamic-content="false" index={3} />
                    <InputOTPSlot data-source-location="src/pages/SignUp.jsx:98:20" data-dynamic-content="false" index={4} />
                    <InputOTPSlot data-source-location="src/pages/SignUp.jsx:99:20" data-dynamic-content="false" index={5} />
                  </InputOTPGroup>
                </InputOTP>
              </div>

              {error && <p data-source-location="src/pages/SignUp.jsx:104:24" data-dynamic-content="true" className="text-sm text-destructive bg-destructive/10 p-3 rounded-lg text-center" data-collection-item-field="error">{error}</p>}

              <Button data-source-location="src/pages/SignUp.jsx:106:14" data-dynamic-content="true" type="submit" disabled={loading || otp.length < 6} className="w-full h-11 text-base bg-primary hover:bg-primary/90 text-primary-foreground">
                {loading ? "Verifying..." : "Verify & Continue"}
              </Button>

              <button data-source-location="src/pages/SignUp.jsx:110:14" data-dynamic-content="true" type="button" onClick={handleResendOtp}
            className="w-full text-sm text-muted-foreground hover:text-foreground transition-colors">
                Didn't get a code? Resend
              </button>
            </form>
          }

          {stage === "signup" &&
          <>
              <div data-source-location="src/pages/SignUp.jsx:119:14" data-dynamic-content="false" className="relative my-5">
                <div data-source-location="src/pages/SignUp.jsx:120:16" data-dynamic-content="false" className="absolute inset-0 flex items-center"><div data-source-location="src/pages/SignUp.jsx:120:68" data-dynamic-content="false" className="w-full border-t border-border" /></div>
                <div data-source-location="src/pages/SignUp.jsx:121:16" data-dynamic-content="false" className="relative flex justify-center"><span data-source-location="src/pages/SignUp.jsx:121:62" data-dynamic-content="false" className="px-3 bg-transparent text-xs text-muted-foreground">or</span></div>
              </div>

              <Button data-source-location="src/pages/SignUp.jsx:124:14" data-dynamic-content="true" variant="outline" onClick={handleGoogle} className="w-full h-11 gap-2 text-sm border-border text-foreground hover:bg-muted/50">
                <GoogleIcon data-source-location="src/pages/SignUp.jsx:125:16" data-dynamic-content="false" className="w-4 h-4" /> Continue with Google
              </Button>
            </>
          }

          <p data-source-location="src/pages/SignUp.jsx:130:10" data-dynamic-content="false" className="mt-5 text-center text-sm text-muted-foreground">
            Already have an account?{" "}
            <a data-source-location="src/pages/SignUp.jsx:132:12" data-dynamic-content="false" href="/get-started" className="text-primary font-medium hover:underline">Sign in</a>
          </p>
        </div>
      </div>
    </div>);

}