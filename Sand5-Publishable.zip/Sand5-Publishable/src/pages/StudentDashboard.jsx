import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { MessageCircle, Video, PhoneOff, Check, Pencil, UserPlus, X } from "lucide-react";
import AvatarBadge from "@/components/AvatarBadge";
import EditProfileModal from "@/components/EditProfileModal";
import QuoteBox from "@/components/QuoteBox";
import HeatmapCalendar from "@/components/ui/heatmap-calendar";
import Logo from "@/components/Logo";
import AdminNotifications from "@/components/AdminNotifications";
import { base44 } from "@/api/base44Client";
import { refreshMyTutors, expireOldCalls, isCallExpired } from "@/lib/loadConnections";

export default function StudentDashboard() {
  const [data, setData] = useState(() => JSON.parse(sessionStorage.getItem("onboardingData") || "{}"));
  const { name = "Student", grade, subjects = [], interests = [], learnStyle, improve = [], avatar, bio } = data;
  const [myTutors, setMyTutors] = useState(() => JSON.parse(sessionStorage.getItem("myTutors") || "[]"));

  const [activeCalls, setActiveCalls] = useState([]);
  const [pendingConns, setPendingConns] = useState([]);
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    const loadProfile = async () => {
      const stored = JSON.parse(sessionStorage.getItem("onboardingData") || "{}");
      try {
        const me = await base44.auth.me();
        if (stored.name && stored.name !== "Student" && stored.email === me.email) {
          setData(stored);
          refreshMyTutors(stored.name).then(setMyTutors);
          return;
        }
        sessionStorage.removeItem("myTutors");
        const profiles = await base44.entities.Profile.filter({ email: me.email });
        if (profiles.length > 0) {
          const p = profiles[0];
          const profileData = {
            name: p.full_name, role: p.role, grade: p.grade, email: me.email,
            subjects: p.subjects || [], interests: p.interests || [],
            bio: p.bio, learnStyle: p.learn_style, improve: p.improve || [],
            avatar: p.avatar
          };
          sessionStorage.setItem("onboardingData", JSON.stringify(profileData));
          setData(profileData);
          refreshMyTutors(p.full_name).then(setMyTutors);
        }
      } catch (e) {console.error("Failed to load profile:", e);}
    };
    loadProfile();
  }, []);

  useEffect(() => {
    if (!name || name === "Student") return;
    const loadCalls = async () => {
      try {
        const calls = await expireOldCalls(name, "student");
        setActiveCalls(calls.filter((c) => !c.is_admin));
      } catch (e) {console.error("Failed to load calls:", e);}
    };
    loadCalls();
    const interval = setInterval(loadCalls, 30000);
    const unsubscribe = base44.entities.Call.subscribe((event) => {
      if (event.type === "create" && event.data.student_name === name && event.data.status === "calling" && !event.data.is_admin) {
        if (!isCallExpired(event.data)) setActiveCalls((prev) => [...prev, event.data]);
      } else if (event.type === "update" && event.data.student_name === name) {
        setActiveCalls((prev) => event.data.status === "calling" ?
        [...prev.filter((c) => c.id !== event.data.id), event.data] :
        prev.filter((c) => c.id !== event.data.id));
      } else if (event.type === "delete") {
        setActiveCalls((prev) => prev.filter((c) => c.id !== event.data.id));
      }
    });
    return () => {clearInterval(interval);if (typeof unsubscribe === 'function') unsubscribe();};
  }, [name]);

  useEffect(() => {
    if (!name || name === "Student") return;
    const loadConns = async () => {
      try {
        const conns = await base44.entities.Connection.filter({ recipient_name: name, status: "pending" });
        setPendingConns(conns.filter((c) => c.requester_name && c.requester_name !== "Student" && c.requester_name !== "Tutor"));
      } catch (e) {console.error("Failed to load connections:", e);}
    };
    loadConns();
    const unsubscribe = base44.entities.Connection.subscribe((event) => {
      if (!event.data || event.data.recipient_name !== name) return;
      if (event.type === "create" && event.data.status === "pending") {
        if (event.data.requester_name && event.data.requester_name !== "Student" && event.data.requester_name !== "Tutor")
        setPendingConns((prev) => [...prev, event.data]);
      } else if (event.type === "update") {
        setPendingConns((prev) => event.data.status === "pending" ?
        [...prev.filter((c) => c.id !== event.data.id), event.data] :
        prev.filter((c) => c.id !== event.data.id));
      } else if (event.type === "delete") {
        setPendingConns((prev) => prev.filter((c) => c.id !== event.data.id));
      }
    });
    return () => {if (typeof unsubscribe === 'function') unsubscribe();};
  }, [name]);

  const handleAcceptCall = async (call) => {
    try {
      await base44.entities.Call.update(call.id, { status: "accepted" });
      setActiveCalls((prev) => prev.filter((c) => c.id !== call.id));
      window.open(call.meeting_link || "https://meet.jit.si/s5-tutoring", "_blank");
    } catch (e) {console.error("Failed to accept call:", e);}
  };

  const handleDeclineCall = async (call) => {
    try {
      await base44.entities.Call.update(call.id, { status: "declined" });
      setActiveCalls((prev) => prev.filter((c) => c.id !== call.id));
    } catch (e) {console.error("Failed to decline call:", e);}
  };

  const handleAcceptConn = async (conn) => {
    try {
      await base44.entities.Connection.update(conn.id, { status: "accepted" });
      setPendingConns((prev) => prev.filter((c) => c.id !== conn.id));
      setMyTutors((prev) => {
        if (prev.find((t) => t.name === conn.requester_name)) return prev;
        const updated = [...prev, { name: conn.requester_name }];
        sessionStorage.setItem("myTutors", JSON.stringify(updated));
        return updated;
      });
    } catch (e) {console.error("Failed to accept connection:", e);}
  };

  const handleDeclineConn = async (conn) => {
    try {
      await base44.entities.Connection.update(conn.id, { status: "declined" });
      setPendingConns((prev) => prev.filter((c) => c.id !== conn.id));
    } catch (e) {console.error("Failed to decline connection:", e);}
  };

  return (
    <div data-source-location="src/pages/StudentDashboard.jsx:137:4" data-dynamic-content="true" className="min-h-screen p-4 md:p-6 font-body relative z-10">
      <div data-source-location="src/pages/StudentDashboard.jsx:138:6" data-dynamic-content="true" className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-5">

        {/* Left col */}
        <div data-source-location="src/pages/StudentDashboard.jsx:141:8" data-dynamic-content="true" className="lg:col-span-2 flex flex-col gap-4">

          <AdminNotifications data-source-location="src/pages/StudentDashboard.jsx:143:10" data-dynamic-content="true" userName={name} />

          {/* Incoming call notification */}
          {activeCalls.length > 0 &&
          <div data-source-location="src/pages/StudentDashboard.jsx:147:12" data-dynamic-content="true" className="space-y-2">
              {activeCalls.map((call) =>
            <motion.div data-source-location="src/pages/StudentDashboard.jsx:149:16" data-dynamic-content="true" key={call.id} initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
            className="bg-primary text-primary-foreground rounded-2xl p-4 flex items-center justify-between" data-collection-item-id={call?.id}>
                  <div data-source-location="src/pages/StudentDashboard.jsx:151:18" data-dynamic-content="true" className="flex items-center gap-3">
                    <div data-source-location="src/pages/StudentDashboard.jsx:152:20" data-dynamic-content="false" className="relative">
                      <div data-source-location="src/pages/StudentDashboard.jsx:153:22" data-dynamic-content="false" className="w-10 h-10 rounded-full bg-primary-foreground/20 flex items-center justify-center">
                        <Video data-source-location="src/pages/StudentDashboard.jsx:154:24" data-dynamic-content="false" className="w-5 h-5" />
                      </div>
                      <span data-source-location="src/pages/StudentDashboard.jsx:156:22" data-dynamic-content="false" className="absolute inset-0 rounded-full animate-ping bg-primary-foreground/30" />
                    </div>
                    <div data-source-location="src/pages/StudentDashboard.jsx:158:20" data-dynamic-content="true">
                      <p data-source-location="src/pages/StudentDashboard.jsx:159:22" data-dynamic-content="true" className="font-semibold text-sm" data-collection-item-field="tutor_name" data-collection-item-id={call?.id}>{call.tutor_name} is calling...</p>
                      <p data-source-location="src/pages/StudentDashboard.jsx:160:22" data-dynamic-content="false" className="text-xs opacity-80">Incoming tutoring session call</p>
                    </div>
                  </div>
                  <div data-source-location="src/pages/StudentDashboard.jsx:163:18" data-dynamic-content="true" className="flex gap-2">
                    <button data-source-location="src/pages/StudentDashboard.jsx:164:20" data-dynamic-content="true" onClick={() => handleAcceptCall(call)}
                className="px-3 py-1.5 rounded-lg bg-green-500 text-white text-xs font-semibold hover:bg-green-600 transition-colors flex items-center gap-1">
                      <Check data-source-location="src/pages/StudentDashboard.jsx:166:22" data-dynamic-content="false" className="w-3.5 h-3.5" /> Accept
                    </button>
                    <button data-source-location="src/pages/StudentDashboard.jsx:168:20" data-dynamic-content="true" onClick={() => handleDeclineCall(call)}
                className="px-3 py-1.5 rounded-lg bg-red-500 text-white text-xs font-semibold hover:bg-red-600 transition-colors flex items-center gap-1">
                      <PhoneOff data-source-location="src/pages/StudentDashboard.jsx:170:22" data-dynamic-content="false" className="w-3.5 h-3.5" /> Decline
                    </button>
                  </div>
                </motion.div>
            )}
            </div>
          }

          {/* Pending connection requests */}
          {pendingConns.length > 0 &&
          <div data-source-location="src/pages/StudentDashboard.jsx:180:12" data-dynamic-content="true" className="space-y-2" data-collection-id="Connection">
              {pendingConns.map((conn) =>
            <motion.div data-source-location="src/pages/StudentDashboard.jsx:182:16" data-dynamic-content="true" key={conn.id} initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
            className="bg-primary text-primary-foreground rounded-2xl p-4 flex items-center justify-between" data-collection-item-id={conn?.id}>
                  <div data-source-location="src/pages/StudentDashboard.jsx:184:18" data-dynamic-content="true" className="flex items-center gap-3">
                    <div data-source-location="src/pages/StudentDashboard.jsx:185:20" data-dynamic-content="false" className="relative">
                      <div data-source-location="src/pages/StudentDashboard.jsx:186:22" data-dynamic-content="false" className="w-10 h-10 rounded-full bg-primary-foreground/20 flex items-center justify-center">
                        <UserPlus data-source-location="src/pages/StudentDashboard.jsx:187:24" data-dynamic-content="false" className="w-5 h-5" />
                      </div>
                      <span data-source-location="src/pages/StudentDashboard.jsx:189:22" data-dynamic-content="false" className="absolute inset-0 rounded-full animate-ping bg-primary-foreground/30" />
                    </div>
                    <div data-source-location="src/pages/StudentDashboard.jsx:191:20" data-dynamic-content="true">
                      <p data-source-location="src/pages/StudentDashboard.jsx:192:22" data-dynamic-content="true" className="font-semibold text-sm" data-collection-item-field="requester_name" data-collection-item-id={conn?.id}>{conn.requester_name} wants to connect</p>
                      <p data-source-location="src/pages/StudentDashboard.jsx:193:22" data-dynamic-content="false" className="text-xs opacity-80">Tutor connection request</p>
                    </div>
                  </div>
                  <div data-source-location="src/pages/StudentDashboard.jsx:196:18" data-dynamic-content="true" className="flex gap-2">
                    <button data-source-location="src/pages/StudentDashboard.jsx:197:20" data-dynamic-content="true" onClick={() => handleAcceptConn(conn)}
                className="px-3 py-1.5 rounded-lg bg-green-500 text-white text-xs font-semibold hover:bg-green-600 transition-colors flex items-center gap-1">
                      <Check data-source-location="src/pages/StudentDashboard.jsx:199:22" data-dynamic-content="false" className="w-3.5 h-3.5" /> Accept
                    </button>
                    <button data-source-location="src/pages/StudentDashboard.jsx:201:20" data-dynamic-content="true" onClick={() => handleDeclineConn(conn)}
                className="px-3 py-1.5 rounded-lg bg-red-500 text-white text-xs font-semibold hover:bg-red-600 transition-colors flex items-center gap-1">
                      <X data-source-location="src/pages/StudentDashboard.jsx:203:22" data-dynamic-content="false" className="w-3.5 h-3.5" /> Decline
                    </button>
                  </div>
                </motion.div>
            )}
            </div>
          }

          {/* Profile card */}
          <motion.div data-source-location="src/pages/StudentDashboard.jsx:212:10" data-dynamic-content="true" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-card/50 to-card/20 backdrop-blur-xl rounded-2xl border border-border shadow-lg overflow-hidden shadow-sm">
            <div data-source-location="src/pages/StudentDashboard.jsx:214:12" data-dynamic-content="true" className="flex items-center justify-between px-5 py-3 border-b border-border bg-gradient-to-r from-primary/10 to-transparent">
              <Logo data-source-location="src/pages/StudentDashboard.jsx:215:14" data-dynamic-content="false" height={24} />
              <div data-source-location="src/pages/StudentDashboard.jsx:216:14" data-dynamic-content="true" className="flex items-center gap-3">
                <span data-source-location="src/pages/StudentDashboard.jsx:217:16" data-dynamic-content="false" className="text-xs font-medium text-primary">Student</span>
                <button data-source-location="src/pages/StudentDashboard.jsx:218:16" data-dynamic-content="true" onClick={() => setEditing(true)} className="flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-primary transition-colors">
                  <Pencil data-source-location="src/pages/StudentDashboard.jsx:219:18" data-dynamic-content="false" className="w-3.5 h-3.5" /> Edit
                </button>
              </div>
            </div>
            <div data-source-location="src/pages/StudentDashboard.jsx:223:12" data-dynamic-content="true" className="flex items-center gap-4 px-5 py-4">
              <AvatarBadge data-source-location="src/pages/StudentDashboard.jsx:224:14" data-dynamic-content="true" avatar={avatar} size={64} />
              <div data-source-location="src/pages/StudentDashboard.jsx:225:14" data-dynamic-content="true">
                <p data-source-location="src/pages/StudentDashboard.jsx:226:16" data-dynamic-content="false" className="text-xs text-muted-foreground">Welcome back</p>
                <h2 data-source-location="src/pages/StudentDashboard.jsx:227:16" data-dynamic-content="true" className="text-xl font-heading font-bold text-foreground" data-collection-item-field="name">{name}</h2>
                {grade && <p data-source-location="src/pages/StudentDashboard.jsx:228:26" data-dynamic-content="true" className="text-xs text-muted-foreground" data-collection-item-field="grade">{grade} Grade</p>}
              </div>
            </div>
            <div data-source-location="src/pages/StudentDashboard.jsx:231:12" data-dynamic-content="true" className="px-5 pb-4 space-y-0">
              {bio &&
              <div data-source-location="src/pages/StudentDashboard.jsx:233:16" data-dynamic-content="true" className="flex items-start gap-3 py-2.5 border-t border-border">
                  <span data-source-location="src/pages/StudentDashboard.jsx:234:18" data-dynamic-content="false" className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide w-28 flex-shrink-0 pt-0.5">Bio</span>
                  <p data-source-location="src/pages/StudentDashboard.jsx:235:18" data-dynamic-content="true" className="text-sm text-foreground leading-relaxed" data-collection-item-field="bio">{bio}</p>
                </div>
              }
              {learnStyle &&
              <div data-source-location="src/pages/StudentDashboard.jsx:239:16" data-dynamic-content="true" className="flex items-start gap-3 py-2.5 border-t border-border">
                  <span data-source-location="src/pages/StudentDashboard.jsx:240:18" data-dynamic-content="false" className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide w-28 flex-shrink-0 pt-0.5">Learning Style</span>
                  <span data-source-location="src/pages/StudentDashboard.jsx:241:18" data-dynamic-content="true" className="text-sm text-foreground font-medium" data-collection-item-field="learnStyle">{learnStyle}</span>
                </div>
              }
              {improve.length > 0 &&
              <div data-source-location="src/pages/StudentDashboard.jsx:245:16" data-dynamic-content="true" className="flex items-start gap-3 py-2.5 border-t border-border">
                  <span data-source-location="src/pages/StudentDashboard.jsx:246:18" data-dynamic-content="false" className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide w-28 flex-shrink-0 pt-0.5">Goals</span>
                  <div data-source-location="src/pages/StudentDashboard.jsx:247:18" data-dynamic-content="true" className="flex flex-wrap gap-1.5">
                    {improve.map((s) => <span data-source-location="src/pages/StudentDashboard.jsx:248:38" data-dynamic-content="true" key={s} className="px-2 py-0.5 bg-secondary text-secondary-foreground text-xs font-medium rounded-md" data-collection-item-field="s">{s}</span>)}
                  </div>
                </div>
              }
              {subjects.length > 0 &&
              <div data-source-location="src/pages/StudentDashboard.jsx:253:16" data-dynamic-content="true" className="flex items-start gap-3 py-2.5 border-t border-border">
                  <span data-source-location="src/pages/StudentDashboard.jsx:254:18" data-dynamic-content="false" className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide w-28 flex-shrink-0 pt-0.5">Subjects</span>
                  <div data-source-location="src/pages/StudentDashboard.jsx:255:18" data-dynamic-content="true" className="flex flex-wrap gap-1.5">
                    {subjects.map((s) => <span data-source-location="src/pages/StudentDashboard.jsx:256:39" data-dynamic-content="true" key={s} className="px-2 py-0.5 bg-primary text-primary-foreground text-xs font-medium rounded-md" data-collection-item-field="s">{s}</span>)}
                  </div>
                </div>
              }
              {interests.length > 0 &&
              <div data-source-location="src/pages/StudentDashboard.jsx:261:16" data-dynamic-content="true" className="flex items-start gap-3 py-2.5 border-t border-border">
                  <span data-source-location="src/pages/StudentDashboard.jsx:262:18" data-dynamic-content="false" className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide w-28 flex-shrink-0 pt-0.5">Interests</span>
                  <div data-source-location="src/pages/StudentDashboard.jsx:263:18" data-dynamic-content="true" className="flex flex-wrap gap-1.5">
                    {interests.map((s) => <span data-source-location="src/pages/StudentDashboard.jsx:264:40" data-dynamic-content="true" key={s} className="px-2 py-0.5 bg-accent text-accent-foreground text-xs font-medium rounded-md" data-collection-item-field="s">{s}</span>)}
                  </div>
                </div>
              }
            </div>
          </motion.div>

          {/* Find Tutors */}
          <Link data-source-location="src/pages/StudentDashboard.jsx:272:10" data-dynamic-content="true" to="/browse-tutors">
            <motion.div data-source-location="src/pages/StudentDashboard.jsx:273:12" data-dynamic-content="true" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
            className="bg-gradient-to-br from-card/50 to-card/20 backdrop-blur-xl rounded-2xl border border-border shadow-lg px-6 py-5 text-center font-semibold text-foreground hover:border-primary/30 hover:shadow-lg transition-all cursor-pointer text-base">
              Find Tutors
            </motion.div>
          </Link>

          {/* My Homework + My Tutors */}
          <div data-source-location="src/pages/StudentDashboard.jsx:280:10" data-dynamic-content="true" className="grid grid-cols-2 gap-4">
            <Link data-source-location="src/pages/StudentDashboard.jsx:281:12" data-dynamic-content="true" to="/my-homework">
              <motion.div data-source-location="src/pages/StudentDashboard.jsx:282:14" data-dynamic-content="true" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
              className="bg-gradient-to-br from-card/50 to-card/20 backdrop-blur-xl rounded-2xl border border-border shadow-lg px-4 py-5 text-center font-semibold text-foreground hover:border-primary/30 hover:shadow-lg transition-all cursor-pointer">
                My Homework
              </motion.div>
            </Link>
            <Link data-source-location="src/pages/StudentDashboard.jsx:287:12" data-dynamic-content="true" to="/my-tutors">
              <motion.div data-source-location="src/pages/StudentDashboard.jsx:288:14" data-dynamic-content="true" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18 }}
              className="bg-gradient-to-br from-card/50 to-card/20 backdrop-blur-xl rounded-2xl border border-border shadow-lg px-4 py-5 text-center font-semibold text-foreground hover:border-primary/30 hover:shadow-lg transition-all cursor-pointer">
                My Tutors {myTutors.length > 0 && <span data-source-location="src/pages/StudentDashboard.jsx:290:50" data-dynamic-content="true" className="ml-1 text-primary">({myTutors.length})</span>}
              </motion.div>
            </Link>
          </div>

          {/* Quick message connected tutors */}
          {myTutors.length > 0 &&
          <motion.div data-source-location="src/pages/StudentDashboard.jsx:297:12" data-dynamic-content="true" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}
          className="bg-gradient-to-br from-card/50 to-card/20 backdrop-blur-xl rounded-2xl border border-border shadow-lg p-4">
              <p data-source-location="src/pages/StudentDashboard.jsx:299:14" data-dynamic-content="false" className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Message Your Tutors</p>
              <div data-source-location="src/pages/StudentDashboard.jsx:300:14" data-dynamic-content="true" className="space-y-2">
                {myTutors.slice(0, 3).map((t, i) =>
              <Link data-source-location="src/pages/StudentDashboard.jsx:302:18" data-dynamic-content="true" key={i} to={`/chat?name=${encodeURIComponent(t.name)}&back=/student-dashboard`}
              className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-muted transition-colors">
                    <div data-source-location="src/pages/StudentDashboard.jsx:304:20" data-dynamic-content="true" className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs">
                      {t.name.split(" ").map((n) => n[0]).join("")}
                    </div>
                    <span data-source-location="src/pages/StudentDashboard.jsx:307:20" data-dynamic-content="true" className="text-sm font-medium text-foreground" data-collection-item-field="name" data-collection-item-id={t?.id || t?._id}>{t.name}</span>
                    <MessageCircle data-source-location="src/pages/StudentDashboard.jsx:308:20" data-dynamic-content="false" className="w-4 h-4 text-muted-foreground ml-auto" />
                  </Link>
              )}
              </div>
            </motion.div>
          }
        </div>

        {/* Right col */}
        <div data-source-location="src/pages/StudentDashboard.jsx:317:8" data-dynamic-content="true" className="flex flex-col gap-4">
          <motion.div data-source-location="src/pages/StudentDashboard.jsx:318:10" data-dynamic-content="true" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="flex-1">
            <HeatmapCalendar data-source-location="src/pages/StudentDashboard.jsx:319:12" data-dynamic-content="false" storageKey="studentCalendarEvents" />
          </motion.div>

          <QuoteBox data-source-location="src/pages/StudentDashboard.jsx:322:10" data-dynamic-content="false" storageKey="studentQuoteBox" />
        </div>
      </div>

      {editing && <EditProfileModal data-source-location="src/pages/StudentDashboard.jsx:326:18" data-dynamic-content="true" data={data} role="student" onClose={() => setEditing(false)} />}
    </div>);

}