import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Search, UserPlus, ArrowLeft, Clock } from "lucide-react";
import { Input } from "@/components/ui/input";
import { base44 } from "@/api/base44Client";

const GRADE_OPTIONS = ["All", "6th", "7th", "8th", "9th", "10th", "11th", "12th", "College"];
const LEARN_STYLE_OPTIONS = ["All", "Step-by-step help", "Practice problems", "Examples first", "Mixed approach"];

function StudentCard({ student, onConnect, connStatus }) {
  const status = connStatus[student.name]?.status;
  return (
    <motion.div data-source-location="src/pages/FindStudents.jsx:14:4" data-dynamic-content="true" initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
    className="bg-card border border-border rounded-2xl p-5 hover:shadow-md transition-shadow" data-collection-item-field="bio" data-collection-item-id={student?.id || student?._id}>
      <div data-source-location="src/pages/FindStudents.jsx:16:6" data-dynamic-content="true" className="flex items-start justify-between mb-3">
        <div data-source-location="src/pages/FindStudents.jsx:17:8" data-dynamic-content="true" className="flex items-center gap-3">
          <div data-source-location="src/pages/FindStudents.jsx:18:10" data-dynamic-content="true" className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-base font-heading">
            {student.name.split(" ").map((n) => n[0]).join("")}
          </div>
          <div data-source-location="src/pages/FindStudents.jsx:21:10" data-dynamic-content="true">
            <p data-source-location="src/pages/FindStudents.jsx:22:12" data-dynamic-content="true" className="font-semibold text-foreground" data-collection-item-field="name" data-collection-item-id={student?.id || student?._id}>{student.name}</p>
            <p data-source-location="src/pages/FindStudents.jsx:23:12" data-dynamic-content="true" className="text-xs text-muted-foreground" data-collection-item-field="grade" data-collection-item-id={student?.id || student?._id}>{student.grade} Grade</p>
          </div>
        </div>
        <span data-source-location="src/pages/FindStudents.jsx:26:8" data-dynamic-content="true" className="text-xs font-medium px-2.5 py-1 rounded-full bg-secondary text-secondary-foreground" data-collection-item-field="learnStyle" data-collection-item-id={student?.id || student?._id}>
          {student.learnStyle}
        </span>
      </div>

      {student.bio &&
      <p data-source-location="src/pages/FindStudents.jsx:32:8" data-dynamic-content="true" className="text-sm text-muted-foreground mb-3 leading-relaxed" data-collection-item-field="bio" data-collection-item-id={student?.id || student?._id}>{student.bio}</p>
      }

      <div data-source-location="src/pages/FindStudents.jsx:35:6" data-dynamic-content="true" className="mb-3">
        <p data-source-location="src/pages/FindStudents.jsx:36:8" data-dynamic-content="false" className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Subjects</p>
        <div data-source-location="src/pages/FindStudents.jsx:37:8" data-dynamic-content="true" className="flex flex-wrap gap-1.5" data-collection-id="student" data-collection-item-field="subjects" data-collection-item-id={student?.id || student?._id}>
          {student.subjects.map((s) => <span data-source-location="src/pages/FindStudents.jsx:38:37" data-dynamic-content="true" key={s} className="px-2 py-0.5 bg-primary/10 text-primary text-xs rounded-md font-medium" data-collection-item-field="s">{s}</span>)}
        </div>
      </div>

      <div data-source-location="src/pages/FindStudents.jsx:42:6" data-dynamic-content="true" className="mb-4">
        <p data-source-location="src/pages/FindStudents.jsx:43:8" data-dynamic-content="false" className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Interests</p>
        <div data-source-location="src/pages/FindStudents.jsx:44:8" data-dynamic-content="true" className="flex flex-wrap gap-1.5" data-collection-id="student" data-collection-item-field="interests" data-collection-item-id={student?.id || student?._id}>
          {student.interests.map((i) => <span data-source-location="src/pages/FindStudents.jsx:45:38" data-dynamic-content="true" key={i} className="px-2 py-0.5 bg-secondary text-secondary-foreground text-xs rounded-md font-medium" data-collection-item-field="i">{i}</span>)}
        </div>
      </div>

      <div data-source-location="src/pages/FindStudents.jsx:49:6" data-dynamic-content="true" className="flex gap-2">
        {status === "accepted" ?
        <span data-source-location="src/pages/FindStudents.jsx:51:10" data-dynamic-content="false" className="flex-1 text-center py-2 text-sm font-semibold text-green-600 bg-green-50 rounded-xl border border-green-200">
            ✓ Connected — Message from Dashboard
          </span> :
        status === "pending" ?
        <span data-source-location="src/pages/FindStudents.jsx:55:10" data-dynamic-content="false" className="flex-1 flex items-center justify-center gap-1.5 py-2 text-sm font-semibold text-muted-foreground bg-muted rounded-xl border border-border">
            <Clock data-source-location="src/pages/FindStudents.jsx:56:12" data-dynamic-content="false" className="w-4 h-4" /> Waiting...
          </span> :

        <button data-source-location="src/pages/FindStudents.jsx:59:10" data-dynamic-content="true" onClick={() => onConnect(student)}
        className="flex-1 flex items-center justify-center gap-2 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:bg-primary/90 transition-colors">
            <UserPlus data-source-location="src/pages/FindStudents.jsx:61:12" data-dynamic-content="false" className="w-4 h-4" /> Connect
          </button>
        }
      </div>
    </motion.div>);

}

export default function FindStudents() {
  const [search, setSearch] = useState("");
  const [grade, setGrade] = useState("All");
  const [subject, setSubject] = useState("");
  const [learnStyle, setLearnStyle] = useState("All");
  const [connStatus, setConnStatus] = useState({});
  const [students, setStudents] = useState([]);
  const studentsRef = useRef([]);
  const myName = JSON.parse(sessionStorage.getItem("onboardingData") || "{}").name || "";

  useEffect(() => {
    const loadStudents = async () => {
      try {
        const profiles = await base44.entities.Profile.filter({ role: "student" });
        const realStudents = profiles.
        filter((p) => p.full_name && p.full_name !== myName).
        map((p) => ({
          id: p.id,
          name: p.full_name,
          email: p.email || "",
          grade: p.grade || "",
          subjects: p.subjects || [],
          interests: p.interests || [],
          learnStyle: p.learn_style || "",
          improve: p.improve || [],
          bio: p.bio || "",
          avatar: p.avatar || null
        }));
        studentsRef.current = realStudents;
        setStudents(realStudents);
      } catch (e) {/* keep empty */}
    };
    loadStudents();
    let unsubscribe;
    try {
      unsubscribe = base44.entities.Profile.subscribe((event) => {
        if (event.type === "create" && event.data.role === "student") loadStudents();
      });
    } catch (e) {}
    return () => {if (typeof unsubscribe === 'function') unsubscribe();};
  }, [myName]);

  useEffect(() => {
    if (!myName) return;
    const loadConnections = async () => {
      try {
        const [requested, received] = await Promise.all([
        base44.entities.Connection.filter({ requester_name: myName }),
        base44.entities.Connection.filter({ recipient_name: myName })]
        );
        const statusMap = {};
        [...requested, ...received].forEach((c) => {
          const otherName = c.requester_name === myName ? c.recipient_name : c.requester_name;
          statusMap[otherName] = { status: c.status, id: c.id };
          if (c.status === "accepted" && c.requester_name === myName) {
            const existing = JSON.parse(sessionStorage.getItem("myStudents") || "[]");
            if (!existing.find((s) => s.name === otherName)) {
              const student = studentsRef.current.find((s) => s.name === otherName);
              sessionStorage.setItem("myStudents", JSON.stringify([...existing, student ? { id: student.id, name: student.name } : { name: otherName }]));
            }
          }
        });
        setConnStatus(statusMap);
      } catch (e) {/* empty */}
    };
    loadConnections();
    let unsubscribe;
    try {
      unsubscribe = base44.entities.Connection.subscribe((event) => {
        const c = event.data;
        if (!c) return;
        const otherName = c.requester_name === myName ? c.recipient_name : c.recipient_name === myName ? c.requester_name : null;
        if (!otherName) return;
        if (event.type === "create" || event.type === "update") {
          setConnStatus((prev) => ({ ...prev, [otherName]: { status: c.status, id: c.id } }));
          if (c.status === "accepted" && c.requester_name === myName) {
            const existing = JSON.parse(sessionStorage.getItem("myStudents") || "[]");
            if (!existing.find((s) => s.name === otherName)) {
              const student = studentsRef.current.find((s) => s.name === otherName);
              sessionStorage.setItem("myStudents", JSON.stringify([...existing, student ? { id: student.id, name: student.name } : { name: otherName }]));
            }
          }
        }
      });
    } catch (e) {}
    return () => {if (typeof unsubscribe === 'function') unsubscribe();};
  }, [myName]);

  const handleConnect = async (student) => {
    if (!myName || myName === "Student" || myName === "Tutor") {
      alert("Please complete your profile in the questionnaire before connecting.");
      return;
    }
    const existing = connStatus[student.name];
    setConnStatus((prev) => ({ ...prev, [student.name]: { status: "pending", id: existing?.id } }));
    try {
      if (existing?.id) {
        await base44.entities.Connection.update(existing.id, { status: "pending" });
      } else {
        await base44.entities.Connection.create({
          requester_name: myName,
          requester_role: "tutor",
          recipient_name: student.name,
          recipient_role: "student",
          status: "pending"
        });
      }
    } catch (e) {
      console.error("Failed to send connection request:", e);
      setConnStatus((prev) => ({ ...prev, [student.name]: existing }));
    }
  };

  const filtered = students.filter((s) => {
    const matchSearch = !search || s.name.toLowerCase().includes(search.toLowerCase()) || s.subjects.some((sub) => sub.toLowerCase().includes(search.toLowerCase()));
    const matchGrade = grade === "All" || s.grade === grade;
    const matchSubject = !subject || s.subjects.some((sub) => sub.toLowerCase().includes(subject.toLowerCase()));
    const matchStyle = learnStyle === "All" || s.learnStyle === learnStyle;
    return matchSearch && matchGrade && matchSubject && matchStyle;
  });

  return (
    <div data-source-location="src/pages/FindStudents.jsx:191:4" data-dynamic-content="true" className="min-h-screen font-body relative z-10">
      <nav data-source-location="src/pages/FindStudents.jsx:192:6" data-dynamic-content="false" className="bg-card/80 backdrop-blur-md border-b border-border px-6 py-4 flex items-center gap-4">
        <Link data-source-location="src/pages/FindStudents.jsx:193:8" data-dynamic-content="false" to="/tutor-dashboard" className="text-muted-foreground hover:text-foreground"><ArrowLeft data-source-location="src/pages/FindStudents.jsx:193:92" data-dynamic-content="false" className="w-5 h-5" /></Link>
        <h1 data-source-location="src/pages/FindStudents.jsx:194:8" data-dynamic-content="false" className="text-xl font-heading font-bold text-foreground">Find Students</h1>
      </nav>

      <div data-source-location="src/pages/FindStudents.jsx:197:6" data-dynamic-content="true" className="max-w-3xl mx-auto px-6 py-8">
        {/* Search */}
        <div data-source-location="src/pages/FindStudents.jsx:199:8" data-dynamic-content="true" className="relative mb-4">
          <Search data-source-location="src/pages/FindStudents.jsx:200:10" data-dynamic-content="false" className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input data-source-location="src/pages/FindStudents.jsx:201:10" data-dynamic-content="true" value={search} onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by name or subject..." className="pl-9 h-11" />
        </div>

        {/* Filters */}
        <div data-source-location="src/pages/FindStudents.jsx:206:8" data-dynamic-content="true" className="bg-card border border-border rounded-2xl p-4 mb-6 space-y-3">
          <div data-source-location="src/pages/FindStudents.jsx:207:10" data-dynamic-content="true">
            <p data-source-location="src/pages/FindStudents.jsx:208:12" data-dynamic-content="false" className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Grade</p>
            <div data-source-location="src/pages/FindStudents.jsx:209:12" data-dynamic-content="true" className="flex flex-wrap gap-1.5">
              {GRADE_OPTIONS.map((g, __arrIdx__) =>
              <button data-source-location="src/pages/FindStudents.jsx:211:16" data-dynamic-content="true" key={g} onClick={() => setGrade(g)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${grade === g ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:bg-muted"}`} data-arr-index={__arrIdx__} data-arr-variable-name="GRADE_OPTIONS">
                  {g}
                </button>
              )}
            </div>
          </div>
          <div data-source-location="src/pages/FindStudents.jsx:218:10" data-dynamic-content="true">
            <p data-source-location="src/pages/FindStudents.jsx:219:12" data-dynamic-content="false" className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Subject Area</p>
            <div data-source-location="src/pages/FindStudents.jsx:220:12" data-dynamic-content="true" className="relative">
              <Search data-source-location="src/pages/FindStudents.jsx:221:14" data-dynamic-content="false" className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input data-source-location="src/pages/FindStudents.jsx:222:14" data-dynamic-content="true" value={subject} onChange={(e) => setSubject(e.target.value)}
              placeholder="Type any subject..." className="pl-9 h-10" />
            </div>
          </div>
          <div data-source-location="src/pages/FindStudents.jsx:226:10" data-dynamic-content="true">
            <p data-source-location="src/pages/FindStudents.jsx:227:12" data-dynamic-content="false" className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Learning Style</p>
            <div data-source-location="src/pages/FindStudents.jsx:228:12" data-dynamic-content="true" className="flex flex-wrap gap-1.5">
              {LEARN_STYLE_OPTIONS.map((l, __arrIdx__) =>
              <button data-source-location="src/pages/FindStudents.jsx:230:16" data-dynamic-content="true" key={l} onClick={() => setLearnStyle(l)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${learnStyle === l ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:bg-muted"}`} data-arr-index={__arrIdx__} data-arr-variable-name="LEARN_STYLE_OPTIONS">
                  {l}
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Results */}
        {filtered.length === 0 ?
        <div data-source-location="src/pages/FindStudents.jsx:241:10" data-dynamic-content="false" className="text-center py-16 text-muted-foreground">
            <p data-source-location="src/pages/FindStudents.jsx:242:12" data-dynamic-content="false" className="text-lg font-medium">No students match your filters</p>
            <p data-source-location="src/pages/FindStudents.jsx:243:12" data-dynamic-content="false" className="text-sm mt-1">Try adjusting your search or filters</p>
          </div> :

        <div data-source-location="src/pages/FindStudents.jsx:246:10" data-dynamic-content="true" className="grid gap-4">
            {filtered.map((s) =>
          <StudentCard data-source-location="src/pages/FindStudents.jsx:248:14" data-dynamic-content="true" key={s.id} student={s} onConnect={handleConnect} connStatus={connStatus} data-collection-item-id={s?.id} />
          )}
          </div>
        }
      </div>
    </div>);

}