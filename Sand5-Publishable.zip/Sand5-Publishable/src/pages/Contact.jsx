import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Logo from "@/components/Logo";

const CSS = `
.s5-page{
  --ink:var(--background); --ink-2:var(--card);
  --paper:var(--foreground); --paper-dim:var(--muted-foreground); --paper-faint:color-mix(in srgb, var(--foreground) 36%, transparent);
  --line:var(--border); --line-strong:color-mix(in srgb, var(--foreground) 28%, transparent);
  --blue:var(--primary); --blue-light:var(--accent-foreground); --blue-deep:var(--chart-4);
  background:var(--ink); color:var(--paper);
  font-family:'Neuton',Georgia,serif; font-weight:400; line-height:1.6;
  overflow-x:hidden; position:relative; min-height:100vh;
}
.s5-page *{margin:0;padding:0;box-sizing:border-box;}
.s5-page .wrap{max-width:860px; margin:0 auto; padding:0 32px;}
.s5-page a{color:inherit; text-decoration:none;}
.s5-page ::selection{background:var(--blue); color:var(--paper);}
.s5-page :focus-visible{outline:2px solid var(--blue-light); outline-offset:3px;}
.s5-page header{
  position:fixed; top:0; left:0; right:0; z-index:100;
  padding:22px 0; transition:background 0.4s ease,border-color 0.4s ease,padding 0.4s ease;
  border-bottom:1px solid transparent;
}
.s5-page header.scrolled{ background:color-mix(in srgb, var(--background) 86%, transparent); backdrop-filter:blur(10px); border-bottom-color:var(--line); padding:14px 0; }
.s5-page header .wrap{display:flex; align-items:center; justify-content:space-between;}
.s5-page .brandmark{display:flex; align-items:center; gap:14px;}
.s5-page .brandmark img{height:48px; width:48px; display:block;}
.s5-page .brandmark span{font-weight:800; font-size:1.55rem; letter-spacing:0.01em;}
.s5-page .brandmark span em{font-style:italic; color:var(--blue-light); font-weight:400; padding:0 1px;}
.s5-page nav.links{display:flex; align-items:center; gap:28px; font-size:0.98rem;}
.s5-page nav.links a{color:var(--paper-dim); position:relative; padding-bottom:2px;}
.s5-page nav.links a::after{content:""; position:absolute; left:0; right:100%; bottom:0; height:1px; background:var(--paper); transition:right 0.35s ease;}
.s5-page nav.links a:hover::after{right:0;}
.s5-page nav.links a.cta{border:1px solid var(--blue); color:var(--paper); padding:9px 22px; font-style:italic; font-size:0.95rem; transition:background 0.3s ease;}
.s5-page nav.links a.cta:hover{background:var(--blue);}
.s5-page nav.links a.cta::after{display:none;}
.s5-page .hero{ position:relative; min-height:60vh; display:flex; align-items:flex-end; padding:160px 0 60px; overflow:hidden;}
.s5-page .hero-amp{ position:absolute; right:-6vw; top:40%; transform:translateY(-50%); font-size:60vw; line-height:1; font-weight:800; font-style:italic;
  background:linear-gradient(160deg,var(--blue) 0%,var(--blue-deep) 78%); -webkit-background-clip:text; background-clip:text; color:transparent;
  opacity:0.4; pointer-events:none; user-select:none; filter:blur(0.5px);}
.s5-page .hero .wrap{position:relative; z-index:2;}
.s5-page .eyebrow{display:flex; align-items:center; gap:10px; font-style:italic; color:var(--paper-dim); font-size:1rem; letter-spacing:0.04em; margin-bottom:24px;}
.s5-page .eyebrow .rule{width:38px; height:1px; background:var(--line-strong);}
.s5-page h1.wordmark{ font-size:clamp(2.8rem,7vw,5rem); font-weight:800; line-height:0.95; letter-spacing:-0.01em;}
.s5-page h1.wordmark em{ font-style:italic; font-weight:400; color:var(--blue-light);}
.s5-page section.body{padding:70px 0 120px; border-top:1px solid var(--line);}
.s5-page .contact-grid{display:grid; grid-template-columns:1fr 1fr; gap:48px; align-items:start;}
.s5-page .contact-info h2{ font-size:1.5rem; font-weight:700; font-style:italic; color:var(--paper); margin-bottom:14px;}
.s5-page .contact-info p{ color:var(--paper-dim); font-size:1.05rem; margin-bottom:28px;}
.s5-page .email-link{ display:inline-flex; align-items:center; gap:10px; font-size:1.2rem; font-style:italic; color:var(--blue-light); border:1px solid var(--line); padding:14px 22px; transition:border-color 0.3s ease, background 0.3s ease;}
.s5-page .email-link:hover{border-color:var(--blue); background:color-mix(in srgb, var(--blue) 8%, transparent);}
.s5-page .social-block{margin-top:32px;}
.s5-page .social-block h3{ font-size:1.2rem; font-weight:700; font-style:italic; color:var(--paper); margin-bottom:14px;}
.s5-page .social-list{display:flex; flex-wrap:wrap; gap:10px;}
.s5-page .social-list a{ border:1px solid var(--line); padding:8px 16px; font-size:0.95rem; color:var(--paper-dim); transition:border-color 0.3s ease, color 0.3s ease;}
.s5-page .social-list a:hover{border-color:var(--blue); color:var(--blue-light);}
.s5-page .contact-form{ border:1px solid var(--line); padding:32px; background:linear-gradient(180deg,rgba(255,255,255,0.02),transparent);}
.s5-page .contact-form h2{ font-size:1.5rem; font-weight:700; font-style:italic; color:var(--paper); margin-bottom:20px;}
.s5-page .contact-form label{display:block; font-size:0.85rem; color:var(--paper-dim); margin-bottom:6px; text-transform:uppercase; letter-spacing:0.04em;}
.s5-page .contact-form input, .s5-page .contact-form textarea{
  width:100%; background:transparent; border:1px solid var(--line); color:var(--paper);
  font-family:'Neuton',serif; font-size:1rem; padding:11px 14px; margin-bottom:18px; transition:border-color 0.3s ease;
}
.s5-page .contact-form input:focus, .s5-page .contact-form textarea:focus{border-color:var(--blue); outline:none;}
.s5-page .contact-form textarea{resize:vertical; min-height:120px;}
.s5-page .contact-form button{
  background:var(--blue); color:#fff; border:1px solid var(--blue); padding:13px 28px;
  font-family:'Neuton',serif; font-size:1rem; font-style:italic; cursor:pointer; transition:background 0.3s ease, transform 0.3s ease;
}
.s5-page .contact-form button:hover{background:#0958d1; transform:translateY(-1px);}
.s5-page .form-note{ font-size:0.85rem; color:var(--paper-dim); margin-top:14px; font-style:italic;}
.s5-page footer{ border-top:1px solid var(--line); padding:40px 0;}
.s5-page footer .wrap{display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:16px;}
.s5-page .foot-brand img{height:40px; width:40px;}
.s5-page footer p{color:var(--paper-dim); font-size:0.9rem; font-style:italic;}
.s5-page footer .foot-links{display:flex; gap:24px; font-size:0.9rem;}
.s5-page footer .foot-links a{color:var(--paper-dim); position:relative; padding-bottom:2px;}
.s5-page footer .foot-links a::after{content:""; position:absolute; left:0; right:100%; bottom:0; height:1px; background:var(--paper); transition:right 0.35s ease;}
.s5-page footer .foot-links a:hover::after{right:0;}
@media(max-width:820px){
  .s5-page .hero{padding:130px 0 50px;}
  .s5-page nav.links{gap:18px;}
  .s5-page .contact-grid{grid-template-columns:1fr; gap:36px;}
}
`;

export default function Contact() {
  const [scrolled, setScrolled] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    const subject = encodeURIComponent(`S&5 contact from ${form.name || "a visitor"}`);
    const body = encodeURIComponent(`${form.message}\n\nFrom: ${form.name} (${form.email})`);
    window.location.href = `mailto:hello@sand5.base44.app?subject=${subject}&body=${body}`;
  };

  return (
    <div data-source-location="src/pages/Contact.jsx:106:4" data-dynamic-content="true" className="s5-page">
      <style data-source-location="src/pages/Contact.jsx:107:6" data-dynamic-content="true" data-collection-item-field="CSS">{CSS}</style>

      <header data-source-location="src/pages/Contact.jsx:109:6" data-dynamic-content="true" className={scrolled ? "scrolled" : ""}>
        <div data-source-location="src/pages/Contact.jsx:110:8" data-dynamic-content="false" className="wrap">
          <Link data-source-location="src/pages/Contact.jsx:111:10" data-dynamic-content="false" to="/" className="brandmark">
            <Logo data-source-location="src/pages/Contact.jsx:112:12" data-dynamic-content="false" height={48} blend />
            <span data-source-location="src/pages/Contact.jsx:113:12" data-dynamic-content="false">S<em data-source-location="src/pages/Contact.jsx:113:19" data-dynamic-content="false">&</em>5</span>
          </Link>
          <nav data-source-location="src/pages/Contact.jsx:115:10" data-dynamic-content="false" className="links">
            <Link data-source-location="src/pages/Contact.jsx:116:12" data-dynamic-content="false" to="/about">About</Link>
            <Link data-source-location="src/pages/Contact.jsx:117:12" data-dynamic-content="false" to="/contact">Contact</Link>
            <Link data-source-location="src/pages/Contact.jsx:118:12" data-dynamic-content="false" to="/get-started" className="cta">Get Started</Link>
          </nav>
        </div>
      </header>

      <section data-source-location="src/pages/Contact.jsx:123:6" data-dynamic-content="false" className="hero">
        <div data-source-location="src/pages/Contact.jsx:124:8" data-dynamic-content="false" className="hero-amp" aria-hidden="true">&amp;</div>
        <div data-source-location="src/pages/Contact.jsx:125:8" data-dynamic-content="false" className="wrap">
          <div data-source-location="src/pages/Contact.jsx:126:10" data-dynamic-content="false" className="eyebrow"><span data-source-location="src/pages/Contact.jsx:126:35" data-dynamic-content="false" className="rule" /> Get in touch</div>
          <h1 data-source-location="src/pages/Contact.jsx:127:10" data-dynamic-content="false" className="wordmark">Contact S<em data-source-location="src/pages/Contact.jsx:127:44" data-dynamic-content="false">&amp;</em>5</h1>
        </div>
      </section>

      <section data-source-location="src/pages/Contact.jsx:131:6" data-dynamic-content="true" className="body">
        <div data-source-location="src/pages/Contact.jsx:132:8" data-dynamic-content="true" className="wrap">
          <div data-source-location="src/pages/Contact.jsx:133:10" data-dynamic-content="true" className="contact-grid">
            <div data-source-location="src/pages/Contact.jsx:134:12" data-dynamic-content="false" className="contact-info">
              <h2 data-source-location="src/pages/Contact.jsx:135:14" data-dynamic-content="false">Say hello.</h2>
              <p data-source-location="src/pages/Contact.jsx:136:14" data-dynamic-content="false">Questions about tutoring, partnerships, or just want to share feedback? We read everything.</p>
              <a data-source-location="src/pages/Contact.jsx:137:14" data-dynamic-content="false" href="mailto:hello@sand5.base44.app" className="email-link">hello@sand5.base44.app</a>

              <div data-source-location="src/pages/Contact.jsx:139:14" data-dynamic-content="false" className="social-block">
                <h3 data-source-location="src/pages/Contact.jsx:140:16" data-dynamic-content="false">Find us online</h3>
                <div data-source-location="src/pages/Contact.jsx:141:16" data-dynamic-content="false" className="social-list">
                  <a data-source-location="src/pages/Contact.jsx:142:18" data-dynamic-content="false" href="https://www.linkedin.com/in/sand-five-27046842a/" target="_blank" rel="noopener noreferrer">LinkedIn</a>
                  <a data-source-location="src/pages/Contact.jsx:143:18" data-dynamic-content="false" href="https://x.com/SandFive618" target="_blank" rel="noopener noreferrer">Twitter</a>
                  <a data-source-location="src/pages/Contact.jsx:144:18" data-dynamic-content="false" href="https://www.facebook.com/share/14rssoLo7rx/?mibextid=wwXIfr" target="_blank" rel="noopener noreferrer">Facebook</a>
                  <a data-source-location="src/pages/Contact.jsx:145:18" data-dynamic-content="false" href="https://youtube.com/@sandfive618?si=iAWIbWkY8mp6Ovr9" target="_blank" rel="noopener noreferrer">YouTube</a>
                  <a data-source-location="src/pages/Contact.jsx:146:18" data-dynamic-content="false" href="https://www.instagram.com/s5tutoring" target="_blank" rel="noopener noreferrer">Instagram</a>
                </div>
              </div>
            </div>

            <form data-source-location="src/pages/Contact.jsx:151:12" data-dynamic-content="true" className="contact-form" onSubmit={handleSubmit}>
              <h2 data-source-location="src/pages/Contact.jsx:152:14" data-dynamic-content="false">Send a message</h2>
              <label data-source-location="src/pages/Contact.jsx:153:14" data-dynamic-content="false" htmlFor="name">Your name</label>
              <input data-source-location="src/pages/Contact.jsx:154:14" data-dynamic-content="true" id="name" type="text" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
              <label data-source-location="src/pages/Contact.jsx:155:14" data-dynamic-content="false" htmlFor="email">Your email</label>
              <input data-source-location="src/pages/Contact.jsx:156:14" data-dynamic-content="true" id="email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
              <label data-source-location="src/pages/Contact.jsx:157:14" data-dynamic-content="false" htmlFor="message">Message</label>
              <textarea data-source-location="src/pages/Contact.jsx:158:14" data-dynamic-content="true" id="message" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} required />
              <button data-source-location="src/pages/Contact.jsx:159:14" data-dynamic-content="false" type="submit">Send Message</button>
              <p data-source-location="src/pages/Contact.jsx:160:14" data-dynamic-content="false" className="form-note">Opens your email app with the message pre-filled.</p>
            </form>
          </div>
        </div>
      </section>

      <footer data-source-location="src/pages/Contact.jsx:166:6" data-dynamic-content="false">
        <div data-source-location="src/pages/Contact.jsx:167:8" data-dynamic-content="false" className="wrap">
          <Link data-source-location="src/pages/Contact.jsx:168:10" data-dynamic-content="false" to="/" className="foot-brand">
            <Logo data-source-location="src/pages/Contact.jsx:169:12" data-dynamic-content="false" height={40} blend />
          </Link>
          <div data-source-location="src/pages/Contact.jsx:171:10" data-dynamic-content="false" className="foot-links">
            <Link data-source-location="src/pages/Contact.jsx:172:12" data-dynamic-content="false" to="/about">About</Link>
            <Link data-source-location="src/pages/Contact.jsx:173:12" data-dynamic-content="false" to="/contact">Contact</Link>
            <Link data-source-location="src/pages/Contact.jsx:174:12" data-dynamic-content="false" to="/get-started">Login</Link>
            <Link data-source-location="src/pages/Contact.jsx:175:12" data-dynamic-content="false" to="/sign-up">Get Started</Link>
          </div>
          <p data-source-location="src/pages/Contact.jsx:177:10" data-dynamic-content="false">© 2025 S&amp;5 — Earn Today, Build Tomorrow.</p>
        </div>
      </footer>
    </div>);

}