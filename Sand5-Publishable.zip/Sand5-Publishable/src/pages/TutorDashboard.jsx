import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { MessageCircle, Pencil, UserPlus, Check, X, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import AvatarBadge from "@/components/AvatarBadge";
import EditProfileModal from "@/components/EditProfileModal";
import QuoteBox from "@/components/QuoteBox";
import HeatmapCalendar from "@/components/ui/heatmap-calendar";
import Logo from "@/components/Logo";
import AdminNotifications from "@/components/AdminNotifications";
import { base44 } from "@/api/base44Client";
import { refreshMyStudents } from "@/lib/loadConnections";

export default function TutorDashboard() {
  const [data, setData] = useState(() => JSON.parse(sessionStorage.getItem("onboardingData") || "{}"));
  const [editing, setEditing] = useState(false);
  const [pendingConns, setPendingConns] = useState([]);
  const [myStudents, setMyStudents] = useState(() => JSON.parse(sessionStorage.getItem("myStudents") || "[]"));
  const [activeCall, setActiveCall] = useState(null);

  useEffect(() => {
    const loadProfile = async () => {
      const stored = JSON.parse(sessionStorage.getItem("onboardingData") || "{}");
      try {
        const me = await base44.auth.me();
        if (stored.name && stored.name !== "Tutor" && stored.email === me.email) {
          setData(stored);
          refreshMyStudents(stored.name).then(setMyStudents);
          return;
        }
        sessionStorage.removeItem("myStudents");
        const profiles = await base44.entities.Profile.filter({ email: me.email });
        if (profiles.length > 0) {
          const p = profiles[0];
          const profileData = {
            name: p.full_name, role: p.role, grade: p.grade, email: me.email,
            interests: p.interests || [], bio: p.bio,
            teachStyle: p.teach_style, strengths: p.strengths || [],
            tutorGrade: p.tutor_grade || [], tutorSubjects: p.tutor_subjects || [],
            tutored: p.tutored, pricing: p.pricing, avatar: p.avatar
          };
          sessionStorage.setItem("onboardingData", JSON.stringify(profileData));
          setData(profileData);
          refreshMyStudents(p.full_name).then(setMyStudents);
        }
      } catch (e) {console.error("Failed to load profile:", e);}
    };
    loadProfile();
  }, []);

  const { name = "Tutor", tutorGrade = [], tutorSubjects = [], interests = [], teachStyle, strengths = [], avatar, bio } = data;

  const pricing = data.pricing || { flexible: false, price: "" };

  useEffect(() => {
    if (!name || name === "Tutor") return;
    const loadConns = async () => {
      try {
        const conns = await base44.entities.Connection.filter({ recipient_name: name, status: "pending" });
        setPendingConns(conns.filter((c) => c.requester_name && c.requester_name !== "Student" && c.requester_name !== "Tutor"));
      } catch (e) {console.error("Failed to load connections:", e);}
    };
    loadConns();
    const unsubscribe = base44.entities.Connection.subscribe((event) => {
      if (!event.data || event.data.recipient_name !== name) return;
      if (event.type === "create" && event.data.status === "pending") {
        if (event.data.requester_name && event.data.requester_name !== "Student" && event.data.requester_name !== "Tutor")
        setPendingConns((prev) => [...prev, event.data]);
      } else if (event.type === "update") {
        setPendingConns((prev) => event.data.status === "pending" ?
        [...prev.filter((c) => c.id !== event.data.id), event.data] :
        prev.filter((c) => c.id !== event.data.id));
      } else if (event.type === "delete") {
        setPendingConns((prev) => prev.filter((c) => c.id !== event.data.id));
      }
    });
    return () => {if (typeof unsubscribe === 'function') unsubscribe();};
  }, [name]);

  useEffect(() => {
    if (!name || name === "Tutor") return;
    const loadCalls = async () => {
      try {
        const accepted = (await base44.entities.Call.filter({ tutor_name: name, status: "accepted" })).filter((c) => !c.is_admin);
        if (accepted.length > 0) setActiveCall(accepted[0]);
      } catch (e) {}
    };
    loadCalls();
    const unsubscribe = base44.entities.Call.subscribe((event) => {
      if (!event.data || event.data.tutor_name !== name) return;
      if (event.data.is_admin) return;
      if (event.type === "update" && event.data.status === "accepted") {
        setActiveCall(event.data);
      } else if (event.type === "update" && event.data.status === "declined") {
        setActiveCall(null);
      } else if (event.type === "delete") {
        setActiveCall(null);
      }
    });
    return () => {if (typeof unsubscribe === 'function') unsubscribe();};
  }, [name]);

  const handleAcceptConn = async (conn) => {
    try {
      await base44.entities.Connection.update(conn.id, { status: "accepted" });
      setPendingConns((prev) => prev.filter((c) => c.id !== conn.id));
      setMyStudents((prev) => {
        if (prev.find((s) => s.name === conn.requester_name)) return prev;
        const updated = [...prev, { name: conn.requester_name }];
        sessionStorage.setItem("myStudents", JSON.stringify(updated));
        return updated;
      });
    } catch (e) {console.error("Failed to accept connection:", e);}
  };

  const handleDeclineConn = async (conn) => {
    try {
      await base44.entities.Connection.update(conn.id, { status: "declined" });
      setPendingConns((prev) => prev.filter((c) => c.id !== conn.id));
    } catch (e) {console.error("Failed to decline connection:", e);}
  };

  const handleJoinMeeting = () => {
    if (activeCall?.meeting_link) {
      window.open(activeCall.meeting_link, "_blank");
      setActiveCall(null);
    }
  };

  return (
    <div data-source-location="src/pages/TutorDashboard.jsx:132:4" data-dynamic-content="true" className="min-h-screen p-4 md:p-6 font-body relative z-10">
      <div data-source-location="src/pages/TutorDashboard.jsx:133:6" data-dynamic-content="true" className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-5">

        {/* Left col */}
        <div data-source-location="src/pages/TutorDashboard.jsx:136:8" data-dynamic-content="true" className="lg:col-span-2 flex flex-col gap-4">

          <AdminNotifications data-source-location="src/pages/TutorDashboard.jsx:138:10" data-dynamic-content="true" userName={name} />

          {/* Call accepted notification */}
          {activeCall &&
          <motion.div data-source-location="src/pages/TutorDashboard.jsx:142:12" data-dynamic-content="true" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
          className="bg-green-600 text-white rounded-2xl p-4 flex items-center justify-between">
              <div data-source-location="src/pages/TutorDashboard.jsx:144:14" data-dynamic-content="true" className="flex items-center gap-3">
                <div data-source-location="src/pages/TutorDashboard.jsx:145:16" data-dynamic-content="false" className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                  <Video data-source-location="src/pages/TutorDashboard.jsx:146:18" data-dynamic-content="false" className="w-5 h-5" />
                </div>
                <div data-source-location="src/pages/TutorDashboard.jsx:148:16" data-dynamic-content="true">
                  <p data-source-location="src/pages/TutorDashboard.jsx:149:18" data-dynamic-content="true" className="font-semibold text-sm" data-collection-item-field="student_name" data-collection-item-id={activeCall?.id || activeCall?._id}>{activeCall.student_name} accepted your call</p>
                  <p data-source-location="src/pages/TutorDashboard.jsx:150:18" data-dynamic-content="false" className="text-xs opacity-80">Join the Google Meet now</p>
                </div>
              </div>
              <button data-source-location="src/pages/TutorDashboard.jsx:153:14" data-dynamic-content="true" onClick={handleJoinMeeting}
            className="px-3 py-1.5 rounded-lg bg-white text-green-600 text-xs font-semibold hover:bg-white/90 transition-colors flex items-center gap-1">
                <Video data-source-location="src/pages/TutorDashboard.jsx:155:16" data-dynamic-content="false" className="w-3.5 h-3.5" /> Join Meeting
              </button>
            </motion.div>
          }

          {/* Pending connection requests */}
          {pendingConns.length > 0 &&
          <div data-source-location="src/pages/TutorDashboard.jsx:162:12" data-dynamic-content="true" className="space-y-2" data-collection-id="Connection">
              {pendingConns.map((conn) =>
            <motion.div data-source-location="src/pages/TutorDashboard.jsx:164:16" data-dynamic-content="true" key={conn.id} initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
            className="bg-primary text-primary-foreground rounded-2xl p-4 flex items-center justify-between" data-collection-item-id={conn?.id}>
                  <div data-source-location="src/pages/TutorDashboard.jsx:166:18" data-dynamic-content="true" className="flex items-center gap-3">
                    <div data-source-location="src/pages/TutorDashboard.jsx:167:20" data-dynamic-content="false" className="relative">
                      <div data-source-location="src/pages/TutorDashboard.jsx:168:22" data-dynamic-content="false" className="w-10 h-10 rounded-full bg-primary-foreground/20 flex items-center justify-center">
                        <UserPlus data-source-location="src/pages/TutorDashboard.jsx:169:24" data-dynamic-content="false" className="w-5 h-5" />
                      </div>
                      <span data-source-location="src/pages/TutorDashboard.jsx:171:22" data-dynamic-content="false" className="absolute inset-0 rounded-full animate-ping bg-primary-foreground/30" />
                    </div>
                    <div data-source-location="src/pages/TutorDashboard.jsx:173:20" data-dynamic-content="true">
                      <p data-source-location="src/pages/TutorDashboard.jsx:174:22" data-dynamic-content="true" className="font-semibold text-sm" data-collection-item-field="requester_name" data-collection-item-id={conn?.id}>{conn.requester_name} wants to connect</p>
                      <p data-source-location="src/pages/TutorDashboard.jsx:175:22" data-dynamic-content="false" className="text-xs opacity-80">Student connection request</p>
                    </div>
                  </div>
                  <div data-source-location="src/pages/TutorDashboard.jsx:178:18" data-dynamic-content="true" className="flex gap-2">
                    <button data-source-location="src/pages/TutorDashboard.jsx:179:20" data-dynamic-content="true" onClick={() => handleAcceptConn(conn)}
                className="px-3 py-1.5 rounded-lg bg-green-500 text-white text-xs font-semibold hover:bg-green-600 transition-colors flex items-center gap-1">
                      <Check data-source-location="src/pages/TutorDashboard.jsx:181:22" data-dynamic-content="false" className="w-3.5 h-3.5" /> Accept
                    </button>
                    <button data-source-location="src/pages/TutorDashboard.jsx:183:20" data-dynamic-content="true" onClick={() => handleDeclineConn(conn)}
                className="px-3 py-1.5 rounded-lg bg-red-500 text-white text-xs font-semibold hover:bg-red-600 transition-colors flex items-center gap-1">
                      <X data-source-location="src/pages/TutorDashboard.jsx:185:22" data-dynamic-content="false" className="w-3.5 h-3.5" /> Decline
                    </button>
                  </div>
                </motion.div>
            )}
            </div>
          }

          {/* Profile card */}
          <motion.div data-source-location="src/pages/TutorDashboard.jsx:194:10" data-dynamic-content="true" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-card/50 to-card/20 backdrop-blur-xl rounded-2xl border border-border shadow-lg overflow-hidden shadow-sm">
            <div data-source-location="src/pages/TutorDashboard.jsx:196:12" data-dynamic-content="true" className="flex items-center justify-between px-5 py-3 border-b border-border bg-gradient-to-r from-primary/10 to-transparent">
              <Logo data-source-location="src/pages/TutorDashboard.jsx:197:14" data-dynamic-content="false" height={24} />
              <div data-source-location="src/pages/TutorDashboard.jsx:198:14" data-dynamic-content="true" className="flex items-center gap-3">
                <span data-source-location="src/pages/TutorDashboard.jsx:199:16" data-dynamic-content="false" className="text-xs font-medium text-primary">Tutor</span>
                <button data-source-location="src/pages/TutorDashboard.jsx:200:16" data-dynamic-content="true" onClick={() => setEditing(true)} className="flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-primary transition-colors">
                  <Pencil data-source-location="src/pages/TutorDashboard.jsx:201:18" data-dynamic-content="false" className="w-3.5 h-3.5" /> Edit
                </button>
              </div>
            </div>
            <div data-source-location="src/pages/TutorDashboard.jsx:205:12" data-dynamic-content="true" className="flex items-center gap-4 px-5 py-4">
              <AvatarBadge data-source-location="src/pages/TutorDashboard.jsx:206:14" data-dynamic-content="true" avatar={avatar} size={64} />
              <div data-source-location="src/pages/TutorDashboard.jsx:207:14" data-dynamic-content="true">
                <p data-source-location="src/pages/TutorDashboard.jsx:208:16" data-dynamic-content="false" className="text-xs text-muted-foreground">Welcome back</p>
                <h2 data-source-location="src/pages/TutorDashboard.jsx:209:16" data-dynamic-content="true" className="text-xl font-heading font-bold text-foreground" data-collection-item-field="name">{name}</h2>
                {tutorGrade.length > 0 && <p data-source-location="src/pages/TutorDashboard.jsx:210:42" data-dynamic-content="true" className="text-xs text-muted-foreground">Teaches {tutorGrade.join(", ")} Grade</p>}
              </div>
            </div>
            <div data-source-location="src/pages/TutorDashboard.jsx:213:12" data-dynamic-content="true" className="px-5 pb-4 space-y-0">
              {bio &&
              <div data-source-location="src/pages/TutorDashboard.jsx:215:16" data-dynamic-content="true" className="flex items-start gap-3 py-2.5 border-t border-border">
                  <span data-source-location="src/pages/TutorDashboard.jsx:216:18" data-dynamic-content="false" className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide w-28 flex-shrink-0 pt-0.5">Bio</span>
                  <p data-source-location="src/pages/TutorDashboard.jsx:217:18" data-dynamic-content="true" className="text-sm text-foreground leading-relaxed" data-collection-item-field="bio">{bio}</p>
                </div>
              }
              {teachStyle &&
              <div data-source-location="src/pages/TutorDashboard.jsx:221:16" data-dynamic-content="true" className="flex items-start gap-3 py-2.5 border-t border-border">
                  <span data-source-location="src/pages/TutorDashboard.jsx:222:18" data-dynamic-content="false" className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide w-28 flex-shrink-0 pt-0.5">Teaching Style</span>
                  <span data-source-location="src/pages/TutorDashboard.jsx:223:18" data-dynamic-content="true" className="text-sm text-foreground font-medium" data-collection-item-field="teachStyle">{teachStyle}</span>
                </div>
              }
              {strengths.length > 0 &&
              <div data-source-location="src/pages/TutorDashboard.jsx:227:16" data-dynamic-content="true" className="flex items-start gap-3 py-2.5 border-t border-border">
                  <span data-source-location="src/pages/TutorDashboard.jsx:228:18" data-dynamic-content="false" className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide w-28 flex-shrink-0 pt-0.5">Strengths</span>
                  <div data-source-location="src/pages/TutorDashboard.jsx:229:18" data-dynamic-content="true" className="flex flex-wrap gap-1.5">
                    {strengths.map((s) => <span data-source-location="src/pages/TutorDashboard.jsx:230:40" data-dynamic-content="true" key={s} className="px-2 py-0.5 bg-secondary text-secondary-foreground text-xs font-medium rounded-md" data-collection-item-field="s">{s}</span>)}
                  </div>
                </div>
              }
              {tutorSubjects.length > 0 &&
              <div data-source-location="src/pages/TutorDashboard.jsx:235:16" data-dynamic-content="true" className="flex items-start gap-3 py-2.5 border-t border-border">
                  <span data-source-location="src/pages/TutorDashboard.jsx:236:18" data-dynamic-content="false" className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide w-28 flex-shrink-0 pt-0.5">Subjects</span>
                  <div data-source-location="src/pages/TutorDashboard.jsx:237:18" data-dynamic-content="true" className="flex flex-wrap gap-1.5">
                    {tutorSubjects.map((s) => <span data-source-location="src/pages/TutorDashboard.jsx:238:44" data-dynamic-content="true" key={s} className="px-2 py-0.5 bg-primary text-primary-foreground text-xs font-medium rounded-md" data-collection-item-field="s">{s}</span>)}
                  </div>
                </div>
              }
              {interests.length > 0 &&
              <div data-source-location="src/pages/TutorDashboard.jsx:243:16" data-dynamic-content="true" className="flex items-start gap-3 py-2.5 border-t border-border">
                  <span data-source-location="src/pages/TutorDashboard.jsx:244:18" data-dynamic-content="false" className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide w-28 flex-shrink-0 pt-0.5">Interests</span>
                  <div data-source-location="src/pages/TutorDashboard.jsx:245:18" data-dynamic-content="true" className="flex flex-wrap gap-1.5">
                    {interests.map((s) => <span data-source-location="src/pages/TutorDashboard.jsx:246:40" data-dynamic-content="true" key={s} className="px-2 py-0.5 bg-accent text-accent-foreground text-xs font-medium rounded-md" data-collection-item-field="s">{s}</span>)}
                  </div>
                </div>
              }
            </div>
          </motion.div>

          {/* Hourly Rate — read only, set during onboarding */}
          <motion.div data-source-location="src/pages/TutorDashboard.jsx:254:10" data-dynamic-content="true" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}
          className="bg-gradient-to-br from-card/50 to-card/20 backdrop-blur-xl rounded-2xl border border-border shadow-lg p-5">
            <p data-source-location="src/pages/TutorDashboard.jsx:256:12" data-dynamic-content="false" className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Hourly Rate</p>
            {pricing?.flexible ?
            <p data-source-location="src/pages/TutorDashboard.jsx:258:14" data-dynamic-content="true" className="text-sm text-foreground leading-relaxed">{pricing.flexibleNote || "Flexible pricing"}</p> :

            <p data-source-location="src/pages/TutorDashboard.jsx:260:14" data-dynamic-content="true" className="text-2xl font-heading font-bold text-primary">${pricing?.price || "—"}<span data-source-location="src/pages/TutorDashboard.jsx:260:98" data-dynamic-content="false" className="text-sm text-muted-foreground font-normal">/hr</span></p>
            }
          </motion.div>

          {/* Find Students */}
          <Link data-source-location="src/pages/TutorDashboard.jsx:265:10" data-dynamic-content="true" to="/find-students">
            <motion.div data-source-location="src/pages/TutorDashboard.jsx:266:12" data-dynamic-content="true" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
            className="bg-gradient-to-br from-card/50 to-card/20 backdrop-blur-xl rounded-2xl border border-border shadow-lg px-6 py-5 text-center font-semibold text-foreground hover:border-primary/30 hover:shadow-lg transition-all cursor-pointer text-base">
              Find Students
            </motion.div>
          </Link>

          {/* Create New Program */}
          <Link data-source-location="src/pages/TutorDashboard.jsx:273:10" data-dynamic-content="true" to="/create-program">
            <motion.div data-source-location="src/pages/TutorDashboard.jsx:274:12" data-dynamic-content="true" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.12 }}
            className="bg-gradient-to-br from-card/50 to-card/20 backdrop-blur-xl rounded-2xl border border-border shadow-lg px-6 py-5 text-center font-semibold text-foreground hover:border-primary/30 hover:shadow-lg transition-all cursor-pointer text-base">
              Create New Program
            </motion.div>
          </Link>

          {/* Toolbox */}
          <Link data-source-location="src/pages/TutorDashboard.jsx:281:10" data-dynamic-content="true" to="/toolbox">
            <motion.div data-source-location="src/pages/TutorDashboard.jsx:282:12" data-dynamic-content="true" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.13 }}
            className="bg-gradient-to-br from-card/50 to-card/20 backdrop-blur-xl rounded-2xl border border-border shadow-lg px-6 py-5 text-center font-semibold text-foreground hover:border-primary/30 hover:shadow-lg transition-all cursor-pointer text-base">
              Toolbox
            </motion.div>
          </Link>

          <div data-source-location="src/pages/TutorDashboard.jsx:288:10" data-dynamic-content="true" className="grid grid-cols-2 gap-4">
            <Link data-source-location="src/pages/TutorDashboard.jsx:289:12" data-dynamic-content="true" to="/tutor-students">
              <motion.div data-source-location="src/pages/TutorDashboard.jsx:290:14" data-dynamic-content="true" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
              className="bg-gradient-to-br from-card/50 to-card/20 backdrop-blur-xl rounded-2xl border border-border shadow-lg px-6 py-5 text-center font-semibold text-foreground hover:border-primary/30 hover:shadow-lg transition-all cursor-pointer">
                My Students {myStudents.length > 0 && <span data-source-location="src/pages/TutorDashboard.jsx:292:54" data-dynamic-content="true" className="text-primary">({myStudents.length})</span>}
              </motion.div>
            </Link>
            <Link data-source-location="src/pages/TutorDashboard.jsx:295:12" data-dynamic-content="true" to="/my-payments">
              <motion.div data-source-location="src/pages/TutorDashboard.jsx:296:14" data-dynamic-content="true" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18 }}
              className="bg-gradient-to-br from-card/50 to-card/20 backdrop-blur-xl rounded-2xl border border-border shadow-lg px-6 py-5 text-center font-semibold text-foreground hover:border-primary/30 hover:shadow-lg transition-all cursor-pointer">
                My Payments
              </motion.div>
            </Link>
          </div>

          {/* Quick message connected students */}
          {myStudents.length > 0 &&
          <motion.div data-source-location="src/pages/TutorDashboard.jsx:305:12" data-dynamic-content="true" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}
          className="bg-gradient-to-br from-card/50 to-card/20 backdrop-blur-xl rounded-2xl border border-border shadow-lg p-4">
              <p data-source-location="src/pages/TutorDashboard.jsx:307:14" data-dynamic-content="false" className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Message Your Students</p>
              <div data-source-location="src/pages/TutorDashboard.jsx:308:14" data-dynamic-content="true" className="space-y-2">
                {myStudents.slice(0, 3).map((s, i) =>
              <Link data-source-location="src/pages/TutorDashboard.jsx:310:18" data-dynamic-content="true" key={i} to={`/chat?name=${encodeURIComponent(s.name)}&back=/tutor-dashboard`}
              className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-muted transition-colors">
                    <div data-source-location="src/pages/TutorDashboard.jsx:312:20" data-dynamic-content="true" className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs">
                      {s.name.split(" ").map((n) => n[0]).join("")}
                    </div>
                    <span data-source-location="src/pages/TutorDashboard.jsx:315:20" data-dynamic-content="true" className="text-sm font-medium text-foreground" data-collection-item-field="name" data-collection-item-id={s?.id || s?._id}>{s.name}</span>
                    <MessageCircle data-source-location="src/pages/TutorDashboard.jsx:316:20" data-dynamic-content="false" className="w-4 h-4 text-muted-foreground ml-auto" />
                  </Link>
              )}
              </div>
            </motion.div>
          }
        </div>

        {/* Right col */}
        <div data-source-location="src/pages/TutorDashboard.jsx:325:8" data-dynamic-content="true" className="flex flex-col gap-4">
          <motion.div data-source-location="src/pages/TutorDashboard.jsx:326:10" data-dynamic-content="true" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="flex-1">
            <HeatmapCalendar data-source-location="src/pages/TutorDashboard.jsx:327:12" data-dynamic-content="false" storageKey="tutorCalendarEvents" />
          </motion.div>

          <QuoteBox data-source-location="src/pages/TutorDashboard.jsx:330:10" data-dynamic-content="false" storageKey="tutorQuoteBox" />
        </div>
      </div>

      {editing && <EditProfileModal data-source-location="src/pages/TutorDashboard.jsx:334:18" data-dynamic-content="true" data={data} role="tutor" onClose={() => setEditing(false)} />}
    </div>);

}