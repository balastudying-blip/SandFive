# Sand5

Publishable Vite + React project recovered from the Base44 export.

## Run locally

```bash
npm install
npm run dev
```

## Build for production

```bash
npm run build
npm run preview
```

The app uses the Base44 SDK/backend for its connected functionality.
